/****************************************
需要的图片列表:
ios_back.png -- 退出家园按钮
gb.png       -- 关闭按钮
loading.gif  -- 正在加载图标
diary404.png -- 没有日记
line.png     -- 日记的线条
line_first.png -- 日记的第一个线条
line_last.png  -- 日记的最后一个线条
photo404.png -- 没有图片
loader.gif   -- Swipe正在加载
error.gif    -- Swipe加载出错
icons.gif    -- Swipe样式图标
icons@2x.gif -- Swipe+IOS
associated.png -- 已关联
defaultpotrait.png -- 默认头像
potrait80.png  -- 80像素的默认头像


images/familys.png  -- 家谱
images/photos.png   -- 图片
images/books.png    -- 书本
images/outtohall.png-- 外景进入客厅
images/halltoout.png-- 客厅进入外景
images/bedtohall.png-- 卧室进入客厅
images/halltobed.png-- 客厅进入卧室
 
****************************************/

/****************************************
需要的JS-CSS列表:
ieternal_player.js  -- 3D播放器
ieternal_skin.js    -- 界面皮肤
jquery-1.8.0.min.js -- JQ1.8版本
photoswipe.js       -- 相册库
jgestures.js        -- 手势库
turn.js             -- 翻书库
toast.js            -- 提醒库
familytree.js       -- 家谱
ieternalconfig.js   -- this


style.css           -- 样式文件
photoswipe.css      -- Swipe样式
turnstyle.css       -- 翻页样式
familytree.css      -- 家谱样式
 
****************************************/

// 需要jquery的支持.版本1.8.0
// 文档结构加载之后执行
$(function(){
    /////////////////////////////////////////////////////////////////////
    // XXX 性能优化
    // 页面文档对象
    var document = window.document;
    // 浏览器地址
    var url = window.location.href || "";
    // 浏览器标识
    var useragent = navigator.userAgent;
    // 封装 body 对象
    var $body = $("body");
    
    
    /////////////////////////////////////////////////////////////////////
    // XXX 全局外部配置
    // 不能使用var定义为闭包变量,否则会被定义提前.
    serverBase = calculateServerBase(window["serverBase"], url); // 外部配置
    config_xml = calculateStyleConfigXML(window["config_xml"], url, "out");
    isOffline =  calculateOfflineStatus(window["isOffline"], false);
    
    /////////////////////////////////////////////////////////////////////
    // XXX pano2vr原始信息
    // 使用id为 container，创建一个播放器对象
    window.pano=new pano2vrPlayer("container");
    // 问号?表示到当前路径下加载资源
    window.skin=new pano2vrSkin(window.pano,'?');
    // 载入配置文件
    window.pano.readConfigUrl(config_xml);
    
    /////////////////////////////////////////////////////////////////////
    // XXX 运行共享变量
    // 共享数据保存
    var mydata = window.mydata = {
            isVideoPauseMusic: false// 是否video停止的音乐
            ,isManualPauseMusic: false// 是否手动停止音乐
			,isPhotoPauseMusic:false//是否照片停止的音乐
            ,hasEnteredRoom: false// 是否进入过卧室，第一次进入是在外景
            ,isInRoom: false// 是否在卧室
            ,isGardenPauseMusic: false// 是否花园停止的音乐
            ,isLikeS4Badly:false// 是否像S4手机一样badly.android注入
            ,musics:[]
            ,blogs:[]
            ,dairygroups:[]
            ,families:[]
			,appendfamily:{}
            ,photos:[]
			,one_photos:[]//一生记忆相册（排序相册）
			,voices:[]
            ,videos:[]
            ,myAudioClassName: "ieternalaudio"
			,hideClass : "hide"
			,swipe : null
			,myId : ""
			,ownerName : "我"
			,myoptions : undefined
        };
    //
	var isTouch = 'ontouchstart' in window;// 判断是否支持触摸模式
	// 根据触摸模式决定事件
	var events = (isTouch) ? {click: 'touchend click'|| 'tapone' || 'touchstart click',start: 'touchstart', move: 'touchmove', end: 'touchend'}
			: {click: 'click',start: 'mousedown', move: 'mousemove', end: 'mouseup'};

    var event_timeout = 500;// 200ms.预防多次事件触发
    // 阻止短时间内连续事件
    var multiClickPrevent = false;
    // 是否自动播放音乐
    var auto_playing_music = true;
    var hasFirstPlayed = false;
    var hasFirstPlayedVideo = false;
    var hasFirstClicked = false;
    // 触发加载事件计数器
    var triggleLoadCounter = 0;
    //
	var useGesture = true;
	var hasLaunchedTurn = false;
	var $offlinebook = null;
    // 适配浏览器
    var likeIOS = useragent.match(/iPad|iPhone|iPod/i);
    var likeAndroid = useragent.match(/android/i);
    var _click = "click";
    if(likeIOS || likeAndroid){
        _click = "touchstart click";
    }
	//跳转家园路径
	var redirectFamily = serverBase+"home/redirectfamily";
	var switchSceneTriggerUrl = serverBase+"home/switchscene.js.cache";
    
    // 浏览器DOM过渡样式,用于音乐播放的样式切换
    var domTransition='transition';
    var prefixes='Webkit,Moz,O,ms,Ms'.split(',');
    var i;
    for(i=0;i<prefixes.length;i++) {
        if (typeof document.body.style[prefixes[i] + 'Transform'] !== 'undefined') {
            domTransition=prefixes[i] + 'Transition';
        }
    }
    //本人有无家谱
	var nofamilytree=0;//0：初始状态 1：有家谱  -1：无家谱
	//第几级家谱关联-----当为离线状态且为第一级关联家谱的时候，就不允许点击家谱了
	var familylevel=0;//0:自己的家谱 1:第一级关联家谱 2:第二级关联家谱     以此类推
	//是否已经打开过自己的家谱
	var hasOpenedMyFamily=false;
	//当前播放的音乐索引
	var musicindex=0;
    
    /////////////////////////////////////////////////////////////////////
    // XXX 事件绑定处理
    
    // 从外景到客厅
    $(
    	".outtohall_wrapper"
    	+ ",.outtohall"
    ).live(_click,function(){
		if(preventMultiClick()){
        	delay(outtoinner,200);
        }
		loadJSTrigerAPP(switchSceneTriggerUrl);
    });
    // 内景到外景
    $(
    	".halltoout_wrapper"
    	+ ",.halltoout"
    	+ ",.dinningtoout"
    	+ ",.kitchentoout"
    ).live(_click,function(){
    	
        loadJSTrigerAPP(switchSceneTriggerUrl);
        if(preventMultiClick()){
        	delay(innertoout,200);
        }
    });
    
    // 客厅到内景
    $(
    	".halltobed_wrapper"
    	+ ",.halltobed"
    	+ ",.halltodining"
    ).live(_click,function(){
    	
        loadJSTrigerAPP(switchSceneTriggerUrl);
        if(preventMultiClick()){
        	delay(halltoinner,200);
        }
    });
    // 内景到客厅
    $(
    	".bedtohall_wrapper"
    	+ ",.bedtohall"
    	+ ",.kitchentohall"
    	+ ",.dinningtohall"
    	+ ",.toilettohall"
    	+ ",.attachtohall"
    ).live(_click,function(){
        //
        loadJSTrigerAPP(switchSceneTriggerUrl);
        if(preventMultiClick()){
        	// 修正 audio视图状态; 延迟执行
        	delay(innertohall, 200);
        }
    });
    
    // 其他场景切换
    $(
    	".toilettobed"
    	+ ",.dinningtobedattach"
    	+ ",.dinningtokitchen"
    	+ ",.diningtobed"
    	+ ",.maintodinning"
    	+ ",.maintobed"
    	+ ",.bedtomain"
    	+ ",.bedtotoilet"
    	+ ",.bedtodinning"
    	+ ",.bedtotoilet"
    	+ ",.kitchentodining"
    	+ ",.kitchentobed"
    ).live(_click,function(){
        //
        loadJSTrigerAPP(switchSceneTriggerUrl);
    });
    
    
    // @deprecate 切换内景与外景
    $(".gogogo").live(_click,function(){
    	
        loadJSTrigerAPP(switchSceneTriggerUrl);
        if(preventMultiClick()){
        	delay(gogogo_click,200);
        }
    });
    // @deprecate 切换客厅与卧室 
    $(".t_right").live(_click,function(){
    	
        loadJSTrigerAPP(switchSceneTriggerUrl);
        if(preventMultiClick()){
        	// 修正 audio视图状态
        	fixAudioStatusView();
        }
    });
    
    // 上一首音乐
    $(".audio_pre").live(_click,function(){
        if(preventMultiClick()){
            preMusic();
        }
    });
    // 下一首音乐
    $(".audio_next").live(_click,function(){
        if(preventMultiClick()){
            nextMusic();
        }
    });
    // 暂停音乐
    $(".audio_off").live(_click,function(){
        if(preventMultiClick()){
            // 暂停音乐
            pauseMyMusic();
        }
    });
    // 开始音乐
    $(".audio_on").live(_click,function(){
        if(preventMultiClick()){
            // 开始音乐
            playMyMusic();
        }
    });

    // 图片事件
    $(".photo").live(_click,function(){
        
        if(!preventMultiClick()){
        	return false;
        };
		//由于增加了照片语音，所以暂停播放音乐
		photoToPauseMusic();
		
		if(window["usePhotoCache"]){
			//隐藏相册提示信息--因为有时候不隐藏，所以强制隐藏
			$(".phototext").css("visibility","hidden");
			if(likeAndroid){
				//如果是客户端则拦截，有客户端处理
				$.getScript(serverBase+"home/photo.js.cache");
			}else{
				if(window.$photoframe){
	        		window.$photoframe.remove();
	        		window.$photoframe = null;
	        	}
	        	if(!window.$photoframe){
	        		var pfs = '<iframe id="p_iframe" class="hide" src="'+serverBase +'home/photo.js.cache"></iframe>'; 
	            	window.$photoframe = $(pfs);
	            	window.$photoframe.appendTo(".video2");
	        	}
			}
			return false;
        }
        if(true || isOffline){
        	openOfflinePhoto();
        } else {
        	openPhoto();
        }
    });
    // 留言事件
    $(".messages").live(_click,function(e){
        if(!preventMultiClick()){
        	return false;
        };
        //
		if(window["userHadLocked"]){
	        //
	        if(likeAndroid){
	        	try{
	        		$.getScript(serverBase+"home/leavemessage.js");
	        	} catch(ex){
	        		// 加载异常，不进行处理
	        	}
	        }
	        else {
	        	
	        	if(window.$messageframe){
	        		window.$messageframe.remove();
	        		window.$messageframe = null;
	        	}
	        	if(!window.$messageframe){
	        		var mfs = '<iframe id="m_iframe" class="hide" src="'+serverBase +'home/leavemessage.js"></iframe>'; 
	            	window.$messageframe = $(mfs);
	            	window.$messageframe.appendTo(".video2");
	        	}
	        }
	        e.preventDefault();
	        return false;
	    } else {
	    	window.toast("该用户未申请封存.暂时不能留言!");
	    }
    });
    
    // 图片,关闭按钮
    $(".photo2 .close").live(_click,function(event){
        if(preventMultiClick()){
        	//
        };
        closePhotos(event);
    });
    // 离线图片关闭
    $(".photoclose.close").live(_click,function(event){
        if(preventMultiClick()){
        	//
        };
        closePhotos(event);
    });
    // 离线图片关闭
    $(".photo_offline .close").live(_click,function(event){
        if(preventMultiClick()){
        	//
        };
        closePhotos(event);
    });
    
    
    // 家谱事件
    $(".familys").live(_click,function(){
		if(!preventMultiClick()){
			return false;
		}
		if(window["useFamilyCache"]){
			//如果是客户端则拦截，有客户端处理
			$.getScript(serverBase+"home/family.js.cache");
			return false;
        }
        if(true || isOffline){
        	openFamilyOffline();
        } else {
        	openFamily();
        }
    });
    // 家谱,关闭事件
    $(".family2 .close").live(_click,function(event){
        preventMultiClick();
        closeFamily(event);
    });
    $(".family_offline .close").live(_click,function(event){
        preventMultiClick();
        closeFamily(event);
    });
    
    
    // XXX 图书事件
    $(".books").live(_click,function(){
        if(!preventMultiClick()){
        	return false;
        };
		if(window["useBookCache"]){
			//如果是客户端则拦截，有客户端处理
			$.getScript(serverBase+"home/book.js.cache");
			return false;
        }
        if(true || isOffline){
        	openBookOffline();
        } else {
        	openBook();
        }
        // 
    });
    // 图书,关闭事件
    $(".diary2 .close").live(_click,function(event){
        preventMultiClick();
        closeBook(event);
    });
    // 图书关闭
    $(".diary_offline .close").live(_click,function(event){
        preventMultiClick();
        closeBook(event);
    });
    
    // XXX 视频事件
    $(".video").live(_click,function(){
        if(preventMultiClick()){
            // 暂停音乐
            videoToPauseMusic();
            //
            if(window["useVideoCache"]){
                $.getScript(serverBase+"home/video.js.cache");
                return false;
            } else if(window["iosUseVideoCache"]){
                removeIFrames();
                $("."+mydata.myAudioClassName).remove();
                showAudioPausedView();
  
                window.$videoframe = $(
                        '<iframe id="v_iframe" class="hide" src="'+serverBase +'home/video.js.cache"></iframe>'
                        );
                window.$videoframe.appendTo(".video2");
                  return false;
            }
            //
            $(".video2").removeClass(mydata.hideClass);
            // iOS 移除控制部分
            if(likeIOS) {
                //$("video").css("position","absolute").css("top",'1000px');
                //$(".bg_pause_start").remove();
                $(".video2 .videocontrol").remove();
             }
             if(!hasFirstPlayedVideo){
                 hasFirstPlayedVideo = true;
                 var vdo = $("video")[0];
                 if(vdo){
                  vdo.play();
                 }
             }
             //
             //$(document).bind(_click,function(e){
                 //
             //    $(".alert_info").text(e.target.className);
             //});
        }
    });
    // 视频,关闭事件
    $(".video2 .close").live(_click,function(){
        preventMultiClick();
        //
        $(".poplayer").addClass(mydata.hideClass);
        //
        $(".videocontrol").removeClass(mydata.hideClass);
        //removeIFrames();
        // 暂停播放
        $(".video2 video").each(function(){
            this.pause();
            //
        });
        // 继续播放音乐
        videoToContinueMusic();
    });
    // 视频,切换视频事件
    $(".video2 .ios_switchvideo").live(_click,function(){
        if(preventMultiClick()){
            var $video = $(".video2 video");
            if(0 == $video.length){
                return ;
            }
            $(".videocontrol").addClass(mydata.hideClass);
            // 下一个
            var nextVideo = getNextVideo();
            if(nextVideo){
                var thumb = nextVideo.thumbnail;
                var attachURL = nextVideo.attachURL;
                var title = nextVideo.title;
                if(!!thumb){
                    $video.attr("poster",thumb);
                }
                if(!!attachURL){
                    $(".video2 .video_title .video_intro").text(title);
                    
                    var vdo = $video[0];
                    if(vdo){
                    vdo.pause();
                    $video.attr('src',attachURL);
                    vdo.pause();
                    vdo.play();
                    }
                }
            }
        }
        //
        //e.preventDefault();
        return false;
    });
    // 视频,前一个;事件
    $(".videocontrol .bg_prev").live(_click,function(){
        if(preventMultiClick()){
            var $video = $(".video2 video");
            if(0 == $video.length){
                return ;
            }
            $(".videocontrol").addClass(mydata.hideClass);
            // 上一个
            var prevVideo = getPrevVideo();
            if(prevVideo){
                var thumb = prevVideo.thumbnail;
                var attachURL = prevVideo.attachURL;
                var title = prevVideo.title;
                if(!!thumb){
                    $video.attr("poster",thumb);
                }
                if(!!attachURL){
                    $(".video2 .video_title .video_intro").text(title);
                    
                    var vdo = $video[0];
                    if(vdo){
	                    vdo.pause();
	                    $video.attr('src',attachURL);
	                    vdo.pause();
	                    vdo.play();
                    }
                }
            }
        }
        //
        //e.preventDefault();
        return false;
    });
    // 视频,下一个;事件
    $(".videocontrol .bg_next").live(_click,function(){
        if(preventMultiClick()){
            var $video = $(".video2 video");
            if(0 == $video.length){
                return ;
            }
            $(".videocontrol").addClass(mydata.hideClass);
            // 下一个
            var nextVideo = getNextVideo();
            if(nextVideo){
                var thumb = nextVideo.thumbnail;
                var attachURL = nextVideo.attachURL;
                var title = nextVideo.title;
                if(!!thumb){
                    $video.attr("poster",thumb);
                }
                if(!!attachURL){
                    $(".video2 .video_title .video_intro").text(title);
                    var vdo = $video[0];
                    if(vdo){
	                    vdo.pause();
	                    $video.attr('src',attachURL);
	                    vdo.pause();
	                    vdo.play();
                    }
                }
            }
        }
        //
        //e.preventDefault();
        return false;
    });
    
    // 视频,控制层
    //$(".videocontrol .bg_pause_start").live(_click,function(){
    $(".videocontrol").live(_click,function(){
        if(preventMultiClick()){
            //
            $(".videocontrol").addClass(mydata.hideClass);
            var video = $(".video2 video")[0];
            
            var isPlaying = !video.paused && !video.ended;
            if(isPlaying){
                video.pause();
            }else {
                video.play();
            }
        }
        //
        //e.preventDefault();
        return false;
    });
    
    // 在视频video元素上的点击事件
    var videoClickTime = 0;
    $("video").bind(_click,function(e){
        if(preventMultiClick()){
            var isPlaying = !this.paused && !this.ended;
            if(!likeIOS || true){
                if(isPlaying){
                    this.pause();
                    //
                    $(".videocontrol").removeClass(mydata.hideClass);
                } else {
                    this.paly();
                    //
                    $(".videocontrol").addClass(mydata.hideClass);
                }
            } else {
                //
                if((++videoClickTime)%2 == 1){
                    $(".videocontrol").removeClass(mydata.hideClass);
                }else {
                    $(".videocontrol").addClass(mydata.hideClass);
                }
            }
        }
        //
        //e.preventDefault();
        //return false;
    });
    
    $("video").unbind('ended');
    $("video").bind('ended',function(){
        $(".videocontrol").removeClass(mydata.hideClass);
    });
    $("video").unbind('pause');
    $("video").bind('pause',function(){
        $(".videocontrol").removeClass(mydata.hideClass);
    });
    $("video").unbind('play');
    $("video").bind('play',function(){
        $(".videocontrol").addClass(mydata.hideClass);
    });
    

    
    
    /////////////////////////////////////////////////////////////////////
    // XXX 内部使用的依赖函数
    
    ///////////////////////////////
    // XXX 音乐相关
    /**
     * 修正 audio视图状态,根据停止还是播放. 
     */
    function fixAudioStatusView(){
        if(isAudioPlaying()){
            showAudioPlayingView();
        } else {
            showAudioPausedView();
        }
    };
    /**
     * 显示audio为正在播放状态 
     */
    function showAudioPlayingView(){
        var audio_on = $(".audio_on")[0];
        var audio_off = $(".audio_off")[0];
        switchShowing(audio_off,audio_on);
    };
    /**
     * 显示audio为暂停状态 
     */
    function showAudioPausedView(){
        var audio_on = $(".audio_on")[0];
        var audio_off = $(".audio_off")[0];
        switchShowing(audio_on,audio_off);
    };
    /**
     * 切换2个dom的显示状态;主要用于音乐播放开关的切换显示
     * @param showE 要显示的DOM元素
     * @param hideE 要隐藏的DOM元素
     */  
    function switchShowing(showE,hideE){
        // 修改样式
        if(hideE){
            hideE.style[domTransition]='none';
            hideE.style.visibility='hidden';
            hideE.ggVisible=false;
        }
        if(showE){
            showE.style[domTransition]='none';
            showE.style.visibility='inherit';
            showE.ggVisible=true;
        }
    };
    /**
     * 暂停音乐 
     */
    function pauseMyMusic(){
        //var $ieternalaudio = getMyAudio();
		var $ieternalaudio = getAllMyAudios();
		if($ieternalaudio.length>0){
			for(var i=0;i<$ieternalaudio.length;i++){
				$ieternalaudio[i].pause();
			}
		}
        showAudioPausedView();
    };
    /**
     * (继续/开始)播放音乐
     */
    function playMyMusic(){
        var $ieternalaudio = getMyAudio();
        var src = $ieternalaudio.attr("src");
        if(!src /*|| src.indexOf(".mp3")<0*/){
            var musics = getAudiosrcs();
            if(!musics || musics.length < 1){
				window.toast("您没有设置音乐!");
            	return false;
            }
            var playSRC = musics[musicindex].fullURL;
            $ieternalaudio.attr("src",playSRC);
        }
        $ieternalaudio[0].play();
        showAudioPlayingView();
    };
    
    /**
     * 播放前一首歌
     */
    function preMusic(){
        // 当前的音乐，索引
        var curindex = getCurrentAudioIndex();
        var prev = curindex-1;
        //
        playMusicByIndex(prev);
    };
    /**
     * 播放后一首歌
     */
    function nextMusic(){
        // 当前的音乐，索引
        var curindex = getCurrentAudioIndex();
        var next = curindex+1;
        //
        playMusicByIndex(next);
    };
    /**
     * 播放音乐,传入index参数
     */ 
    function playMusicByIndex(index){
        pauseMyMusic();
        var musics = getAudiosrcs();
        var len = musics.length;
        if(0 == len){
			window.toast("您没有设置音乐!");
            return false;
        }
        if(index >= len){
            index = 0;
        } else if(index < 0){
            index = len-1;
        }
		musicindex = index;
        var $audio = getMyAudio();
		
        var playSRC = musics[index].fullURL;
		if($audio.attr("id")=='mp3audio'){
			var audiosrc = $audio.attr("src");
			if(audiosrc != playSRC){
				$audio.attr("src",playSRC);
			}
		}else{
			//不是mp3的音乐播放器
		}
        playMyMusic();
        showAudioPlayingView();
    };
    
    /**
     * 获取当前(播放/暂停)的音乐的索引,返回值是数字; 如果没有,则返回0
     */
    function getCurrentAudioIndex(){
        return musicindex;
    };
	function getCurrentAudioIndex2(){
        //
        var $audio = getMyAudio();
        var asrc = $audio.attr("src");
        var musics = getAudiosrcs();
        //
        var len = musics.length;
        if(len < 1){
            return 0;
        }
        // 当前的音乐，索引
        var curindex = 0;
        //
        $(musics).each(function(i,v){
            var src = v.fullURL;
            if(src == asrc){
                curindex = i;
            }
        });
        return curindex;
    };
    
    // 创建自身的audio
    function createMyAudio(){
        var myAudioClassName = mydata.myAudioClassName || "ieternalaudio";
        // 移除其他的audio 元素
        // var $audios = $("audio");
        // $audios.each(function(i,v){
            // var $v = $(v);
            // if(!$v.hasClass(myAudioClassName)){
                // $v.remove();
            // };
        // });
        // 判断是否有自己的元素
        var $ieternalaudio = $('.'+myAudioClassName);
        if(0 == $ieternalaudio.length){
            // 创建
			//先创建一个用于切换MP3格式音乐的元素
			$ieternalaudio = $("<audio id='mp3audio' class='"+myAudioClassName+"'></audio>");
            $ieternalaudio.appendTo('body');
            //
            // 自动播放下一首
            $ieternalaudio.unbind('ended');
            $ieternalaudio.bind('ended',function(){
                var ct = this.currentTime;
                var du = this.duration;
                if(ct == du){
                    nextMusic();
                }
            });
			
			var musics = getAudiosrcs();//获取所有的音频
			$(musics).each(function(i,v){
				var src = v.fullURL;
				if(src && src.indexOf(".mp3")>=0){
					//mp3格式的，可以切换src路径
				}else if(src){
					//不是mp3格式，不可以切换src路径
					//var audioid = src.substr(src.lastIndexOf("/")+1).replace(new RegExp(/(\.)/g),"");
					var audioid = window.md5(src.substr(src.lastIndexOf("/")+1));
					$ieternalaudio = $("<audio id='"+audioid+"' src='"+src+"' class='"+myAudioClassName+"'></audio>");
					$ieternalaudio.appendTo('body');
					//
					// 自动播放下一首
					$ieternalaudio.unbind('ended');
					$ieternalaudio.bind('ended',function(){
						var ct = this.currentTime;
						var du = this.duration;
						if(ct == du){
							nextMusic();
						}
					});
				}
			});
        }
        //
		$ieternalaudio = $('.'+myAudioClassName);
        return $ieternalaudio;
    };
    // 获取自身的audio--当前正在播放的音乐播放器
    function getMyAudio(){
        var myAudioClassName = mydata.myAudioClassName;
        // 判断是否有自己的元素
        var $ieternalaudio = $('.'+myAudioClassName);
        if(0 == $ieternalaudio.length){
            // 创建
            $ieternalaudio = createMyAudio();
        }
		//
		var musics = getAudiosrcs();
		if(musics && musics.length>0){
			var music = musics[musicindex];
			var src = music.fullURL;
			if(src && src.indexOf(".mp3")>=0){
				//是mp3文件，使用第一个播放器元素播放
				$ieternalaudio = $('#mp3audio');
			}else if(src){
				//不是mp3格式的音乐文件
				//var audioid = src.substr(src.lastIndexOf("/")+1).replace(new RegExp(/(\.)/g),"");
				var audioid = window.md5(src.substr(src.lastIndexOf("/")+1));
				$ieternalaudio = $('#'+audioid);
			}else{
				$ieternalaudio = $('#mp3audio');
			}
		}else{
			$ieternalaudio = $('#mp3audio');
		}
        //
        return $ieternalaudio;
    };
	//获取所有的音乐播放器
	function getAllMyAudios(){
        var myAudioClassName = mydata.myAudioClassName;
        // 判断是否有自己的元素
        var $ieternalaudio = $('.'+myAudioClassName);
        return $ieternalaudio;
    };
    // 音频是否在播放
    function isAudioPlaying(){
        var $ieternalaudio = getMyAudio();
        var audio = $ieternalaudio[0];
        if(audio){
            return !audio.ended && !audio.paused;
        } else {
            return false;
        }
    };
    // 获取音频
    function getAudiosrcs(){
        return mydata.musics;
    };
    
    // 导入音乐
    window.loadmusic = function (musics){
        if(!Array.isArray(musics)){
            if(window.console){
                console.log("loadmusic,failure,no music");
                return;
            }
        }
        mydata.musics = musics;
        
        // 移除旧元素
        $("audio source").remove();
        // 如果没有则创建
        var $myAudio = getMyAudio();
        
        $.each(musics,function(i,v){
            var fullURL = v.fullURL;
            var mId = v.mId;
            var $source = $('<source src="'+fullURL+'"/>');
            $myAudio.append($source);
            if(0 == i){
                $myAudio.attr('src',fullURL);
            }
        });
        // 播放第0首音乐, "s5".length > 100 屏蔽状态
        if(auto_playing_music && "s5".length > 100){
            playMusicByIndex(0);
            // 以下的代码，是用于第一次不自动触发播放的。
            // 是否应该全局?
            $("body").unbind(_click);
            $("body").bind(_click,function(){
                // 如果
                if(hasFirstPlayed){
                    return;
                }
                hasFirstPlayed = true;
                // 停止自动旋转
                window.pano.stopAutorotate();
                //
                //var isPlaying = isAudioPlaying();
                if(auto_playing_music && !isAudioPlaying()){
                    //
                    playMusicByIndex(0);
                }
            });
            
        }
    };
    
    
    
    ///////////////////////////////
    // XXX 家谱相关函数
    // 打开家谱
    function openFamily(){
    	
        //
        $(".family2").removeClass(mydata.hideClass);
        $(".family2 .loading").removeClass(mydata.hideClass);
        //removeIFrames();
        
        // 
        var width = getWindowWidth();
        var height = getWindowHeight();

        //
        var frameStr = '<iframe id="family_iframe"  style="width: '+width+'px;height: '+height+'px;border: 0;overflow: hidden;"></iframe>'
        var likes4 = false;
        // 针对S4
        if(likeAndroid && useragent.match(/4.2.2/i)){
            likes4 = true;
            //frameStr = '<iframe id="family_iframe" style="width:100%;height: 900px;border: 0;overflow-y:auto;"></iframe>'
            //frameStr = '<iframe id="family_iframe" style="width:100%;height: 1900px;border: 0;overflow-y:auto;"></iframe>'
            frameStr = '<iframe id="family_iframe" style="width:100%;height: 100%;border: 0;overflow-y:auto;"></iframe>'
            $(".family2").css("overflow-y","auto").css("min-height","900px");
            $(".family2").height(1900);
            $(".family2").css("overflow-y","auto").css("min-height",height+"px");
        } else {
            //removeIFrames();
        }
        
        var src = serverBase+"home/family";
        
        window.$familyframe = window.$familyframe || $(frameStr);
        window.$familyframe.bind('load',function(){
            //var frameheight = $familyframe.height();
            //frameheight = frameheight + 50;
            $(".poplayer .loading").addClass(mydata.hideClass);
            if(likes4){
                // 设置 poplayer 的大小
                //$(".family2").css("height",frameheight+"px");
                $(".family2")[0].scrollTop = 0;
            }
        });
        window.$familyframe.attr('src', src);
        //
            //'<iframe id="family_iframe" src="'+serverBase +'home/family" style="width: '+width+'px;height: '+height+'px;border: 0;overflow: hidden;"></iframe>'
            //'<iframe id="family_iframe" src="'+serverBase +'home/family" style="width:100%;height: 100%;border: 0;overflow: hidden;"></iframe>'
             
        window.$familyframe.appendTo(".family2");
    };
    
    // 打开离线家谱
    function openFamilyOffline(){
        //
        $(".family_offline").removeClass(mydata.hideClass);
		//如果已经打开过家谱了则不显示加载页面
		if(!hasOpenedMyFamily){
			$(".family_offline .loading").removeClass(mydata.hideClass);
        }
		if(hasOpenedMyFamily && nofamilytree==1 && window["treex"]!=undefined && window["treey"]!=undefined){
		//打开过自己的家谱且存在家谱的时候，重新将自己置为家谱中心位置
			$(".family_offline #tree .tree_container").scrollLeft(treex).scrollTop(treey);
		}
		var options = {
			data : mydata.families
			,onNodeClick : onFamilyNodeClick
			,onComplete : onFamilyComplete
			,force : false	// 强制刷新
		};
		mydata.myoptions = options;
        $(".family_offline #tree").familytree(options)
				.removeClass("hide");
		if(nofamilytree==-1){
			$(".nofamily").removeClass(mydata.hideClass);
		}
    };
    
    function onFamilyComplete(tree){
    	//
		var ownerName = "我";
		var data = tree.data;
		$.each(data,function(i,v){
			var level = v.level;
			var directLine = v.directLine;
			var name = v.name || v.nickName || "??";
			var memberId = v.memberId;
			if(!mydata.myId || mydata.myId==''){
				mydata.myId = v.userId;
			}
			if((0 == level) && (1 == directLine)){
				ownerName = name;
				if(!mydata.ownerName || mydata.ownerName=='' || mydata.ownerName=='我'){
					mydata.ownerName = name;
				}
			}
		});
		$(".familytitle .title").text(ownerName+"的家谱");
		//
		var screenheight = window.screen.availHeight;
		
		var scrollHeight = document.body.scrollHeight;
		var topdivHeight = 37;//家谱标题处的div高度
		var domHeight = scrollHeight-topdivHeight;
		
		var width = tree.dom.width();
		var height = tree.dom[0].scrollHeight;
		
		if(likeIOS){
			domHeight = screenheight-topdivHeight;
		}else if(likeAndroid){
			domHeight = screenheight/2;
		}
		if(height>domHeight){
			tree.dom.height(domHeight).width(width);
			tree.target.css("min-height",(domHeight+topdivHeight)+"px").width(width);
		}
		var lv0 = tree.getLevel(0);
		if(lv0){
			if(nofamilytree==0){
				nofamilytree=1;
			}
			//防止显示没有家谱信息，所以进行隐藏操作
			$(".nofamily").addClass(mydata.hideClass);
			//
			var center = lv0.center;
			if(center){
				var x = center.x;
				var y = center.y;
				var clientWidth = document.body.clientWidth;//屏幕宽度
				var clientHeight = document.body.clientHeight;//屏幕高度
				x = x - clientWidth/2;
				y = y - clientHeight/2;
				if(x<0){
					x=0;
				}
				if(y<0){
					y=0;
				}
				treex=x;
				treey=y;
				tree.dom.scrollLeft(x);
				tree.dom.scrollTop(y);
			}
		}else{
			//alert("没有家谱信息吗");
			if(nofamilytree==0){
				nofamilytree=-1;
			}
			$(".nofamily").removeClass(mydata.hideClass);
		}
		
		$(".familytitle").stop().fadeIn(800).removeClass("hide");
    	//
        $(".poplayer .loading").addClass(mydata.hideClass);
		//代表打开过家谱了
		if(!hasOpenedMyFamily){
			hasOpenedMyFamily=true;
		}
    };
	function onFamilyNodeClick(data,tree,e){
		if(!preventMultiClick()){
			return false;
		}
		if(!data){
			return ;
		}
		var associated = data.associated;
		var userId = data.userId;
		var memberId = data.memberId;
		//需要判断是否是离线状态且为第一级关联家谱
		if(isOffline && url.indexOf("http") < 0 && familylevel>=1){
			//离线状态且是第一级关联家谱则返回false
			window.toast("离线状态下不能在继续访问关联家谱");
			return false;
		}
		if(memberId && memberId==userId){
			// 显示信息
			showMemberInfo(data,tree);
		} else if(1 == associated){
			// 跳转
			//console.log("跳转到别人的家谱");
			//var params = {
			//};
			//showOtherTree(params);
			showMemberInfo(data,tree);
		} else {
			// 显示信息
			showMemberInfo(data,tree);
		}
		return false;
	};
	
	// 显示家谱成员信息
	function showMemberInfo(data,tree){
		if(!data){
			return;
		}
		//
		var name = data.name || "";
		var sex = (2 == data.sex)? "♀" : "♂";
		var birthDate = date2String(data.birthDate,{
			yearsep : "."
				,monsep : "."
				,daysep : ""
			});
		if(data.birthDateStr!=undefined && data.birthDateStr!=null && data.birthDateStr!="" && data.birthDateStr!="null"){
			birthDate = data.birthDateStr;
		}
		var deathDate = date2String(data.deathDate,{
			yearsep : "."
				,monsep : "."
				,daysep : ""
			});
		if(data.deathDateStr!=undefined && data.deathDateStr!=null && data.deathDateStr!="" && data.deathDateStr!="null"){
			deathDate=data.deathDateStr;
		}
		var now = new Date().getFullYear();
		var bYear = new Date(data.birthDate).getFullYear();
		var age = (now - bYear);
		var isDead = data.isDead;
		if(isDead < 1){
			deathDate = "";
		} else {
			deathDate = " - "+ deathDate;
			var dYear = new Date(data.deathDate).getFullYear();
		}
		if(age < 1){
			age = 1;
		}
		var mother = "未知";
		var motherId = data.motherId;
		if(motherId){
			var allData = tree.data || [];
			$.each(allData,function(i,v){
				if(!v){
					return;
				}
				//
				var memberId = v.memberId;
				var name = v.name;
				if(memberId == motherId){
					mother = name;
				}
			});
		}

		
		var associated = data.associated || 0;
		var headPortrait = data.headPortrait || "";
		var intro = data.intro || "";
		var nickName = data.nickName || " ";
		var subTitle = data.subTitle || "未知";
		var address = data.address || "";
		var userId = data.userId || "";
		var memberId = data.memberId || "";
		var name = data.name || data.nickName || "?";
		var associateUserId = data.associateUserId || "";
		var associateKey = data.associateKey || "";
		var associateValue = data.associateValue || "";
		var associateAuthCode = data.associateAuthCode || "";
		var eternalCode = data.eternalCode || "";
		var eternalnum = data.eternalnum || "";
		//
		if(name.length > 7){
			name = name.substr(0,7);
		}
		var $memberinfo = $(".memberinfo");
		$(".name",$memberinfo).text(name);
		$(".mother",$memberinfo).text("母亲: "+mother);
		$(".subTitle",$memberinfo).text("身份: "+subTitle);
		$(".sex",$memberinfo).text(sex);
		$(".age",$memberinfo).text(age+"岁");
		$(".birthDate",$memberinfo).text(birthDate+ deathDate);
		$(".nickName",$memberinfo).text("称呼:"+nickName);

		// 移除事件
		$(".visitarea").unbind("click").addClass("hide");
		$(".visitarea2").unbind("click").addClass("hide");
		if(memberId && (userId == memberId) ){
			if(userId && userId!="" && userId!=mydata.myId){
				$(".visitarea2").removeClass("hide");
				$(".visitbutton2").html("访问"+name+"的家园");
				$(".visitarea2").bind("click", function(e){
					var ps = window.currentParams; 
					//
					var url = redirectFamily;
					url += "?";
					url += "associatekey="+ps.associatekey;
					url += "&";
					url += "associatevalue="+ps.associatevalue;
					url += "&";
					url += "associateauthcode="+ps.associateauthcode;
					url += "&";
					url += "eternalcode="+ps.eternalcode;
					url += "&";
					url += "associateuserid="+ps.associateuserid;
					url = encodeURI(url);
					window.location.replace(url);
					//console.dir(url);
					//console.dir(ps);
				});

				$(".memberinfo_bg").removeClass("hide");
				$memberinfo.removeClass("hide").unbind("click").bind("click",function(){
					return hideMemberInfo(false);
				});;
			} else {
				//
			}
		} else if(1 == associated){
			$(".visitbutton",$memberinfo).removeClass("hide");
			$(".visitbutton").html("查看"+name+"的家谱");
			//
			$(".visitarea").removeClass("hide");
			$(".visitarea").unbind("click");
			$(".visitarea").bind("click", function(e){
				// 显示其他人的家谱
				showOtherTree({
					associateuserid : associateUserId
					,associatekey : associateKey
					,associatevalue : associateValue
					,associateauthcode : associateAuthCode
					,eternalcode : eternalCode
					,eternalnum : eternalnum
					,requesttype : "json"
				});
			});
			
			$(".visitarea2").removeClass("hide");
			$(".visitbutton2").html("访问"+name+"的家园");
			$(".visitarea2").bind("click", function(e){
				//var ps = window.currentParams; 
				//
				var url = redirectFamily;
				url += "?";
				url += "associatekey="+associateKey;
				url += "&";
				url += "associatevalue="+associateValue;
				url += "&";
				url += "associateauthcode="+associateAuthCode;
				url += "&";
				url += "eternalcode="+eternalCode;
				url += "&";
				url += "associateuserid="+associateUserId;
				url = encodeURI(url);
				window.location.replace(url);
				//console.dir(url);
				//console.dir(ps);
			});
			
			
			
			$(".memberinfo_bg").removeClass("hide");
			$memberinfo.removeClass("hide").unbind("click").bind("click",function(){
				return hideMemberInfo(false);
			});;
		}
		if(headPortrait.length > 5){
			$(".portrait",$memberinfo).attr("src",headPortrait);
		} else {
			$(".portrait",$memberinfo).attr("src","");
		}
		//如果加上如下代码，所有页面元素的点击事件都会失效，所以注释掉
		//$("body").unbind("click").bind("click",function(){
		//	return hideMemberInfo(false);
		//});
	};
	// 显示别人的家谱
	function showOtherTree(params){
	
	//
	var eternalcode = params["eternalcode"];
	var data = window.mydata.appendfamily[eternalcode];
	//
		window.currentParams=params;
		var options = {
			data : data
			,onNodeClick : onFamilyNodeClick
			,onComplete : onFamilyComplete
			,url: serverBase+"home/family"
			,method: "POST"
			,params: params
			,force : true	// 强制刷新
		};
		$("#tree").addClass("hide");
		$(".backmyfamily").removeClass("hide");
		$("#othertree").html("<div class=\"loading\" style=\"z-index:1; position: absolute; left: 40%; top: 30%; width: 104px; height: 104px;opacity: 0.5;background: #000000;border: 0px solid #000000;border-radius: 10px;-webkit-border-radius: 10px;\"><img src=\"loading.gif\" alt=\"\" style=\"position:absolute; left:26px; top:10px;width: 50px;height: 50px;border-radius: 10px;-webkit-border-radius: 10px;\"><div class=\"loadingtext\" style=\"position:absolute;left: 12px;top:  76px;color: #ffffff;\">正在加载...</div></div>");
		$("#othertree").removeClass("hide");
		$(".familytitle").stop().fadeOut(100,function(){
			$("#othertree").familytree(options)
			.removeClass("hide");
		}).addClass("hide");
		familylevel=familylevel+1;
	};
	function hideMemberInfo(returnVal){
		var $memberinfo = $(".memberinfo");
		$memberinfo.addClass("hide");
		$(".memberinfo_bg").addClass("hide");
		return !!returnVal;
	};
	
    // 关闭家谱
    function closeFamily(){
        //removeIFrames();
		//
		familylevel=0;
        //
        $(".poplayer").addClass(mydata.hideClass);
        $(".poplayer .loading").addClass(mydata.hideClass);
        $(".family_offline").addClass(mydata.hideClass);
        $(".family_offline .loading").addClass(mydata.hideClass);
		backMyFamily();
		hideMemberInfo(false);
		//如果提供了事件对象，则这是一个非IE浏览器
		if (e && e.stopPropagation ){
			//因此它支持W3C的stopPropagation()方法
			e.stopPropagation(); 
		}else{
			//否则，我们需要使用IE的方式来取消事件冒泡 
			window.event.cancelBubble = true;
		}
		//如果提供了事件对象，则这是一个非IE浏览器 
		if (e && e.preventDefault ){
			//阻止默认浏览器动作(W3C) 
			e.preventDefault(); 
		}else{
			//IE中阻止函数器默认动作的方式 
			window.event.returnValue = false;
		}
		return false;
    };
	$(".backmyfamily").bind(events.click,backMyFamily);
    function backMyFamily(){
		//
		familylevel=0;
		//
		$(".nofamily").addClass(mydata.hideClass);
		//
		$(".familytitle .title").text(mydata.ownerName+"的家谱");
		$(".familytitle").stop().fadeIn(800).removeClass("hide");
		$("#othertree").addClass("hide");
		$(".backmyfamily").addClass("hide");
		$("#tree").familytree(mydata.myoptions)
		.removeClass("hide");
	};
    

    
    
    ///////////////////////////////
    // XXX 书本相关函数
    
    // 
    function openBook(){
        //
        $(".diary2").removeClass(mydata.hideClass);
        $(".diary2 .loading").removeClass(mydata.hideClass);
        //removeIFrames();
        
        // 
        var width = getWindowWidth();
        var height = getWindowHeight();

        //
        var frameStr = '<iframe id="blog_iframe"  style="width: '+width+'px;height: '+height+'px;border: 0;overflow: hidden;"></iframe>'
        var likes4 = false;
        // 针对S4
        if(likeAndroid && useragent.match(/4.2.2/i)){
            likes4 = true;
            //frameStr = '<iframe id="blog_iframe" style="width:100%;height: 900px;border: 0;overflow-y:auto;"></iframe>'
            //frameStr = '<iframe id="blog_iframe" style="width:100%;height: 1900px;border: 0;overflow-y:auto;"></iframe>'
            frameStr = '<iframe id="blog_iframe" style="width:100%;height: 100%;border: 0;overflow-y:auto;"></iframe>'
            $(".diary2").css("overflow-y","auto").css("min-height","900px");
            $(".diary2").height(1900);
            $(".diary2").css("overflow-y","auto").css("min-height",height+"px");
        } else {
            //removeIFrames();
        }
        
        var src = serverBase+"home/blog";
        
        window.$blogframe = window.$blogframe || $(frameStr);
        window.$blogframe.bind('load',function(){
            //var frameheight = $blogframe.height();
            //frameheight = frameheight + 50;
            $(".poplayer .loading").addClass(mydata.hideClass);
            if(likes4){
                // 设置 poplayer 的大小
                //$(".diary2").css("height",frameheight+"px");
                $(".diary2")[0].scrollTop = 0;
            }
        });
        window.$blogframe.attr('src', src);
        //
            //'<iframe id="blog_iframe" src="'+serverBase +'home/blog" style="width: '+width+'px;height: '+height+'px;border: 0;overflow: hidden;"></iframe>'
            //'<iframe id="blog_iframe" src="'+serverBase +'home/blog" style="width:100%;height: 100%;border: 0;overflow: hidden;"></iframe>'
             
        window.$blogframe.appendTo(".diary2");
    };
    // 打开离线书本
    function openBookOffline(){
    	//
        $(".diary_offline").removeClass(mydata.hideClass);
        $(".diary_offline .loading").removeClass(mydata.hideClass);
        //
        if(!mydata.blogs){
        	mydata.blogs = window["blogs"];
        }
        if(!mydata.blogs || mydata.blogs.length < 1){
        	showNoBookOffline();
        } else {
        	showOfflineBook();
        }
        $(".diary_offline .loading").addClass(mydata.hideClass);
    };
    // 显示没有 book
    function showNoBookOffline(){
    	$(".NoBookOffline").removeClass(mydata.hideClass);
    	//
    	console.info("showNoBookOffline");
    };
    function showOfflineBook(){
    	// 获取直接子元素; 必须在显示之前获取
    	var $offlinebook = $(".offlinebook");
    	$offlinebook.removeClass(mydata.hideClass);
    	var $page = $offlinebook.children("div");
    	blogSize = $page.size();
    	if(!hasLaunchedTurn){
			// 
			launchTurn();
    		hasLaunchedTurn = true;
    	} else {
    		//window.toast("你好");
    	}
    };
    // 跳到前一页
	function previousPage($offlinebook){
		
		var cur = $offlinebook.turn('page');
		if(cur <= 1){
			window.toast("目录不能继续往前");
		} else {
			$offlinebook.turn('previous');
		}
	};
	// 跳到下一页
	function nextPage($offlinebook){
		var cur = $offlinebook.turn('page');
		if(cur >= blogSize){
			window.toast("已经是最后一篇");
		} else {
			$offlinebook.turn('next');
		};
	};
	// 回到目录
	function goCatalog($offlinebook){
		$offlinebook.turn('page',1);
	};
	
	// 滑动
	function toScrollFrame(){
		if(!likeIOS) {
			return false; //do nothing if not iOS devie
		}
		if(useGesture){
			scrollByGesture();
		}

		return true;
	};

	function launchTurn(){
		// 阻止多次launch
		if(hasLaunchedTurn){
			return false;
		} else {
			hasLaunchedTurn = true;
		}
		// 书本对象。
		var $offlinebook = $('.offlinebook');
		var turnConfig = {
			display: 'single',
			acceleration: true,
			page: 1,
			//pages: blogSize+1,
			width: getWindowWidth(),
			height: getWindowHeight(),
			elevation: 25,
			gradients: !$.isTouch,
			autoCenter: false,
			when: {
				turning: function(e, page, view) {
					//
					$(".diary1.hide").removeClass("hide");
					$(".catalog.hide").removeClass("hide");
					// 获取需要的页码。数组
					var range = $(this).turn('range', page);
					// 添加页面
					for (page = range[0]; page<=range[1]; page++) {
						//addPage(page, $(this));
						// 有这个页面
						if($offlinebook.turn('hasPage', page)){}
					}
				},
				turned: function(e, page) {
					//
					$(".diary1.hide").removeClass("hide");
					$(".catalog.hide").removeClass("hide");
				},
				start: function(event, pageObject, corner) {
					if (pageObject.next==1) {
						//event.preventDefault();
					}
				}
			}
		};
		// 启动效果
		$offlinebook.turn(turnConfig);
		//
		$(".diary1.hide").removeClass("hide");


		//绑定跳转
		//$(document).delegate(".catalist a","click",function(e){
		$(document).delegate(".catalist span",events.click,function(e){
			//
			var id = $(this).attr("id");
			if(id){
				// 页码
				var index = id.replace("a_","") || "0";
				index = parseInt(index);
				index = index +1;
				//
				$offlinebook.turn('page',index);
			}
			//
			return false;
		});

		// 绑定左右键;翻页键
		$(window).bind('keydown', function(e){
			if (e.keyCode==37){
				previousPage($offlinebook);
			} else if (e.keyCode==39){
				nextPage($offlinebook);
			}
		});
		//
		/*
		$(document).delegate("a.prev_blog",events.click,function(e){
			previousPage($offlinebook);
		});
		$(document).delegate("a.next_blog",events.click,function(e){
			nextPage($offlinebook);
		});
		$(document).delegate("a.goto_catalog",events.click,function(e){
			//alert("a.goto_catalog");
			goCatalog($offlinebook);
		});
		$(document).delegate("a.backtocatalog",events.click,function(e){
			window.location.href = $("a.backtocatalog").attr("href");
		});
		*/
		// offlinebook 下的所有 a 标签
		$(document).delegate(".offlinebook a",events.click,function(e){
			//
			var clz = $(this).attr("class");
			if(!clz){
				return false;
			} else {
				// 使用空白分隔
				var clsList = clz.split(/\s/); // TODO 1180
				var cur = $offlinebook.turn('page');
				var index = -1;
				// 返回全部书本目录页
				if(clz.indexOf("goto_catalog") > -1){
					index = 1;
				} else if(clz.indexOf("tobook_") > -1){
					// 跳转到某本书的目录页
					// 第几本书index,从 0 开始计数
					var bkIdx = findClazzNumber(clsList, "tobook_");
					// 计算实际页码
					index = getBookPage(bkIdx) + 1 + 1;
				}  else if(clz.indexOf("fwdpage_") > -1){
					// 向前跳多少页 -- > 
					var fwdpg = findClazzNumber(clsList, "fwdpage_");
					// 计算实际页码
					index = (parseInt(fwdpg)) + cur;
				} else if(clz.indexOf("next_blog") > -1){
					return nextPage($offlinebook);
				} else if(clz.indexOf("prev_blog") > -1){
					return previousPage($offlinebook);
				}
				//
				if(index < 1){
					index = 1;
				}
				// 执行翻页
				$offlinebook.turn('page',index);
			}
			//
			return false;
		});
		
		// 传入书本编号,返回前面还有多少页(只计算book的), bkIdx 从 0 开始
		function getBookPage(bkIdx){
			var result = 0;
			var groups = mydata.blogs;
			if(!groups){
				return result;
			}
			$.each(mydata.blogs,function(i,v){
				if(v && v.blogcount && (i < bkIdx) ){
					//
					result += parseInt(v.blogcount) || 0;
					result += 1; // 加上该分组的目录页
				} else {
					return false;
				}
			});
			//
			return result;
		}
		
		function findClazzNumber(arr, clzPre, fltV){
			var n = ("undefined"=== typeof fltV)? -1 : fltV;
			$.each(arr,function(i,v){
				if(v && v.indexOf(clzPre) > -1){
					// 命中
					n = v.replace(clzPre,"");
					return false;
				}
			});
			//
			return n;
		};

		// 向左滑动
		function swipeLeft(e){
			previousPage($offlinebook);
		};
		// 向右滑动
		function swipeRight(e){
			nextPage($offlinebook);
		};
		// 向上滑动
		function swipeUp(e){};
		// 向下滑动
		function swipeDown(e){};
		// 少写几个字母
		function abs(num){
			return Math.abs(num);
		};
		
		// 点击一次
		function tapOne(e,tapEvent){
			//console.dir(tapEvent);
			//
			var delta = tapEvent.delta ? tapEvent.delta[0] : {};
			var duration = tapEvent.duration;
			//
			var lastX = delta.lastX;
			var lastY = delta.lastY;

			//alert("lastX="+lastX+",lastY="+lastY);

			// 最大移动
			var maxMove = 15;
			// 横向移动
			if((abs(lastX) < maxMove) && (abs(lastY) < maxMove)){
				//$onlinebook.trigger("");
			}
			//
		};
		// 滑动一次
		function swipeOne(e,swipeEvent){
			//
			var delta = swipeEvent.delta ? swipeEvent.delta[0] : {};
			var duration = swipeEvent.duration;
			//
			var lastX = delta.lastX;
			var lastY = delta.lastY;
			// 是否向右
			var right = (lastX>0);
			// 是否向下
			var down = (lastY>0);
			
			var tt = "lastX=" + lastX + ",lastY=" + lastY;
			//window.toast(tt);
			//alert(tt);

			// 要求，纵横比例是5倍以上才处理
			var ratio = 3;
			// 最小移动,50像素才处理
			var minMove = 50;
			// 横向移动
			if(abs(lastX/ratio) > abs(lastY)){
				if(abs(lastX) > minMove){
					//
					if(right){
						swipeLeft(e);
					} else {
						swipeRight(e);
					}
				}
			} else if(abs(lastY/ratio) > abs(lastX)){
				// 竖向移动
				if(abs(lastY) > minMove){
					//
					if(down){
						swipeDown(e);
					} else {
						swipeUp(e);
					}
				}
			}
		};
		//绑定手势
		$offlinebook.bind("swipeone",swipeOne);
		$offlinebook.bind("tapone",tapOne);
	};
	
    // 关闭图书
    function closeBook(e){
        //removeIFrames();
        //
        $(".poplayer").addClass(mydata.hideClass);
        $(".poplayer .loading").addClass(mydata.hideClass);
        //
    	$(".NoBookOffline").addClass(mydata.hideClass);
		//如果提供了事件对象，则这是一个非IE浏览器
		if (e && e.stopPropagation ){
			//因此它支持W3C的stopPropagation()方法
			e.stopPropagation(); 
		}else{
			//否则，我们需要使用IE的方式来取消事件冒泡 
			window.event.cancelBubble = true;
		}
		//如果提供了事件对象，则这是一个非IE浏览器 
		if (e && e.preventDefault ){
			//阻止默认浏览器动作(W3C) 
			e.preventDefault(); 
		}else{
			//IE中阻止函数器默认动作的方式 
			window.event.returnValue = false;
		}
		return false;
    };
    
    
    
    ///////////////////////////////
    // XXX 图片相关函数
    // 打开离线图片
    function openOfflinePhoto(){
        showOfflinePhoto();
		//if(mydata.swipe){
			//因为关闭按钮先出现，会出现问题，所以延迟显示
			//setTimeout('$(".photoclose").removeClass(mydata.hideClass);',1000);
		//}
    };
    //监听展示图片事件执行的方法---用于获取当前图片的语音播放语音
	function onDisplayImageMethod(obj){
		var imgobj = obj.carousel.contentEl.childNodes[1];
		if(imgobj==undefined){
			imgobj = obj.carousel.contentEl.childNodes[0];
		}
		var imgurl = imgobj.firstChild.src;
        var imgname = imgurl.substr(imgurl.lastIndexOf("/")+1);
		if(window["mydata"] && mydata.voices){
			var voiceurl = mydata.voices[imgname];
			//alert(voiceurl);
			var voiceobj = document.getElementById("voiceid");
			if(voiceobj!=null && voiceobj!=undefined){
				if(voiceurl=="null" || voiceurl=="" || voiceurl==null || voiceurl==undefined){
					voiceobj.pause();
					voiceobj.src="";
				}else{
					var name1=voiceobj.src.substr(voiceobj.src.lastIndexOf("/")+1);
					var name2=voiceurl.substr(voiceurl.lastIndexOf("/")+1);
					if(name1==name2){
						//是当前音乐，不做操作
					}else{
						voiceobj.pause();
						voiceobj.src=voiceurl;
						voiceobj.play();
					}
				}
			}
		}
	}
	//播放一生记忆相册的语音
	function playGroupOneVoice(){
		var voiceobj = document.getElementById("one_voiceid");
		if(voiceobj!=null && voiceobj!=undefined){
			voiceobj.play();
		}
	}
	//停止播放一生记忆相册的语音
	function pauseGroupOneVoice(){
		var voiceobj = document.getElementById("one_voiceid");
		if(voiceobj!=null && voiceobj!=undefined){
			voiceobj.pause();
		}
	}
	
	var chooseStatus=0;//选择状态，选择的哪一个按钮 0代表为选择，1代表一生记忆，2代表所有
	function instanceGallery(){
	    var PhotoSwipe = window.Code.PhotoSwipe;
	    // 渲染目标
	    var swipe_target = $(".swipe_target")[0] || window;
	    // 显示相关信息
	    //
	    if(window !== swipe_target){
	    	$(".photo_offline")
	    	.css("height",getWindowHeight()+"px")
	    	.removeClass(mydata.hideClass);
	    	//
	    	$(".swipe_target")
	    	.css("height",getWindowHeight()+"px")
	    	.removeClass(mydata.hideClass);
	    }
	    // 默认选项
	    var options = {
	        preventHide: false,               // 阻止用户关闭画廊
	        zIndex : 2000,                    // z-index
	        allowUserZoom : true,             // 允许双击放大
	        allowRotationOnUserZoom : true,   // 允许IOS旋转
	        autoStartSlideshow : false,       // 自动播放
	        captionAndToolbarAutoHideDelay:0, // 自动隐藏延时毫秒,0表示不隐藏
	        backButtonHideEnabled : true,     // 安卓,返回键取消画廊
	        doubleTapZoomLevel : 2,           // 双击放大倍数,浮点
	        captionAndToolbarFlipPosition: false,//标题放到底部
	        captionAndToolbarOpacity:0.7,     // 透明度
	        target : swipe_target,
	        captionAndToolbarHide : false     // 隐藏标题和工具栏
	    };
	    //
		try{
			if(chooseStatus==0){
				chooseStatus=1;
			}
			if(chooseStatus==1){
				mydata.swipe = $(".photo_offline .one_photo_li a").photoSwipe(options);
				//播放一生记忆相册的语音
				playGroupOneVoice();
			}else if(chooseStatus==2){
				mydata.swipe = $(".photo_offline .photo_li a").photoSwipe(options);
				//监听图片展示事件，用于播放语音
				mydata.swipe.addEventHandler(PhotoSwipe.EventTypes.onDisplayImage,  
					function(e) {
						onDisplayImageMethod(this);
					});
			}
		}catch(ex){
			
		}
	};
	function showGallery(){
		mydata.swipe.show(0);
		//$(".photo_offline .photo_li a:first").trigger("click");
		//$(".ps-toolbar").css("display","none !important;");
		$(".ps-toolbar").addClass(mydata.hideClass);
	};
	// 显示离线图片
	var showOfflinePhoto = window.showOfflinePhoto = function (){
		//$(".photo_offline").removeClass(mydata.hideClass);
		//
		generateGroupOnePhotoDOM();//第一次未初始化成功
		instanceGallery();
		showGallery();
		if(chooseStatus==1){
			$("#showone_photosspan").removeClass("current");
			$("#showallphotosspan").addClass("current");
		}else if(chooseStatus==2){
			$("#showone_photosspan").addClass("current");
			$("#showallphotosspan").removeClass("current");
		}
	};
	$("#showone_photos").live(_click,chooseOnePhotos);
	$("#showallphotos").live(_click,chooseAllPhotos);
	//点击切换一生记忆按钮
	function chooseOnePhotos(){
		if(chooseStatus!=1){
			chooseStatus=1;
			if(mydata.swipe){
				mydata.swipe.hide();
			}
			//停止播放照片语音
			var voiceobj = document.getElementById("voiceid");
			if(voiceobj){
				voiceobj.pause();
			}
			showOfflinePhoto();
		}
	}
	//点击切换所有照片按钮
	function chooseAllPhotos(){
		if(chooseStatus!=2){
			chooseStatus=2;
			if(mydata.swipe){
				mydata.swipe.hide();
			}
			//停止播放照片语音
			pauseGroupOneVoice();
			showOfflinePhoto();
		}
	}
    
    // 打开图片
    function openPhoto(){
        $(".photo2 .loading").removeClass(mydata.hideClass);
        removeIFrames();
        var width = getWindowWidth();
        var height = getWindowHeight();
        
        //
        var frameStr = '<iframe id="photo_iframe"  style="width: '+width+'px;height: '+height+'px;border: 0;overflow: hidden;"></iframe>'
        var src = serverBase+"home/photo";
        
        window.$photoframe = $(frameStr);
        window.$photoframe.bind('load',function(){
            $(".poplayer .loading").addClass(mydata.hideClass);
        });
        window.$photoframe.attr('src', src);
        window.$photoframe.appendTo(".photo2");
        // 加入延时。
        delay(function(){
            // android 注入
            //if(window.mydata.isLikeS4Badly){
            if(window.isLikeS4Badly){
                //
                window.$photoframe.remove();
                window.$photoframe = null;
            } else {
                //
                $(".photo2").removeClass(mydata.hideClass);
            }
        },100);
    };
    // 仅仅显示图片
    function showExistsPhotos(){
    	
    };
    
    
    // 关闭相册
    function closePhotos(e){
    	//
        removeIFrames();
        //
        $(".poplayer").addClass(mydata.hideClass);
        $(".poplayer .loading").addClass(mydata.hideClass);
        $(".photoclose.close").addClass(mydata.hideClass);
        //
        if(mydata.swipe){
	    	mydata.swipe.hide();
        }
		chooseStatus=0;//置为选择初始状态
		//停止播放照片语音
		var voiceobj = document.getElementById("voiceid");
		if(voiceobj){
			voiceobj.pause();
		}
		pauseGroupOneVoice();
		//播放音乐
		photoToContinueMusic();
		//如果提供了事件对象，则这是一个非IE浏览器
		if (e && e.stopPropagation ){
			//因此它支持W3C的stopPropagation()方法
			e.stopPropagation(); 
		}else{
			//否则，我们需要使用IE的方式来取消事件冒泡 
			window.event.cancelBubble = true;
		}
		//如果提供了事件对象，则这是一个非IE浏览器 
		if (e && e.preventDefault ){
			//阻止默认浏览器动作(W3C) 
			e.preventDefault(); 
		}else{
			//IE中阻止函数器默认动作的方式 
			window.event.returnValue = false;
		}
		return false;
    };
    
    ///////////////////////////////
    // XXX 视频相关函数

    
    
    function getCurVideoSrc(){
        var $video = $(".video2 video");
        if(0 == $video.length){
            return "";
        } else {
            return $video.attr("src");
        }
    };
    // 前一个视频src
    function getPrevVideo(){
        var videos = mydata.videos;
        if(!videos || videos.length < 2){
            return "";
        }
        var curSrc = getCurVideoSrc();
        var cur_index = 0;
        //
        $.each(videos, function(i,v){
            var attachURL = v.attachURL;
            if(attachURL == curSrc){
                cur_index = i;
            }
        });
        var pre_index = cur_index-1;
        if(pre_index < 0){
            pre_index = videos.length-1;
        }
        return videos[pre_index];
    };
    // 后一个视频src
    function getNextVideo(){
        var videos = mydata.videos;
        if(!videos || videos.length < 2){
            return "";
        }
        var curSrc = getCurVideoSrc();
        var cur_index = 0;
        //
        $.each(videos, function(i,v){
            var attachURL = v.attachURL;
            if(attachURL == curSrc){
                cur_index = i;
            }
        });
        var next_index = cur_index+1;
        if(next_index >= videos.length){
            next_index = 0;
        }
        return videos[next_index];
    };
    
    
    

    // 视频暂停播放音乐
    function videoToPauseMusic(){
        // 是否正在播放
        var isPlaying = isAudioPlaying();
        if(isPlaying){
            mydata.isVideoPauseMusic = true;
            //
            pauseMyMusic();
            showAudioPausedView();
        }
    };
    // 继续播放音乐
    window.videoToContinueMusic = function videoToContinueMusic(){
        if(!mydata.isVideoPauseMusic){
            return;
        } else {
            playMyMusic();
            showAudioPlayingView();
            //
            window.mydata.isVideoPauseMusic = false;
        }
    };
	
	// 照片暂停播放音乐
    function photoToPauseMusic(){
        // 是否正在播放
        var isPlaying = isAudioPlaying();
        if(isPlaying){
            mydata.isPhotoPauseMusic = true;
            //
            pauseMyMusic();
            showAudioPausedView();
        }
    };
    // 关闭相册继续播放音乐
    window.photoToContinueMusic = function photoToContinueMusic(){
		//隐藏相册提示信息--因为有时候不隐藏，所以强制隐藏
		$(".phototext").css("visibility","hidden");
        if(!mydata.isPhotoPauseMusic){
            return;
        } else {
            playMyMusic();
            showAudioPlayingView();
            //
            window.mydata.isPhotoPauseMusic = false;
        }
    };
	//退出家园到九宫格时候停止播放音乐
	window.stopPlayMusic = function stopPlayMusic(){
        pauseMyMusic();
    };
    /////////////////////////////////////////////////////////////////////
    // XXX 客厅与外景-场景切换
    // outtoinner
    function gogogo_click(){
        preventMultiClick();
        // 如果没有进入过卧室
        if(!mydata.hasEnteredRoom){
            mydata.hasEnteredRoom = true;
            mydata.isInRoom = true;
            // 第一次，播放
            if(auto_playing_music && !hasFirstPlayed){
                //
                hasFirstPlayed = true;
                playMusicByIndex(0);
            }
            $("body").unbind(_click);
            $("body").bind(_click,function(){
                // 如果
                if(!hasFirstPlayed){
                    hasFirstPlayed = true;
                    //
                    var isPlaying = isAudioPlaying();
                    if(!isPlaying){
                        //
                        playMusicByIndex(0);
                    }
                    return;
                }
                if(!hasFirstClicked){
                    //
                    hasFirstClicked = true;
                    // 停止自动旋转
                    window.pano.stopAutorotate();
                    
                    if(isAudioPlaying()){
                        showAudioPlayingView();
                    } else {
                        showAudioPausedView();
                    }
                }
            });
            // 不再继续执行
            return;
        }
        
        // 如果从卧室出去
        if(mydata.isInRoom){
            // 暂停音乐
            if(isAudioPlaying()){
                pauseMyMusic();
                showAudioPausedView();
                //
                mydata.isGardenPauseMusic = true;
            }
            //
            mydata.isInRoom = false;
        } else {
            // 如果是出去花园暂停的音乐，那么继续播放
            if(mydata.isGardenPauseMusic){
                playMyMusic();
                showAudioPlayingView();
                //
                mydata.isGardenPauseMusic = false;
            }
            //
            mydata.isInRoom = true;
        }
    };
    
    // 从外景进入内景
    function outtoinner(){
    	//console.info("outtoinner");
        // 如果没有进入过卧室
        if(!mydata.hasEnteredRoom){
            mydata.hasEnteredRoom = true;
            mydata.isInRoom = true;
            // 第一次，播放
            if(auto_playing_music && !hasFirstPlayed){
                //
                hasFirstPlayed = true;
                playMusicByIndex(0);
            }
            $("body").unbind(_click);
            $("body").bind(_click,function(){
                // 如果
                if(!hasFirstPlayed){
                    hasFirstPlayed = true;
                    //
                    var isPlaying = isAudioPlaying();
                    if(!isPlaying){
                        //
                        playMusicByIndex(0);
                    }
                    return;
                }
                if(!hasFirstClicked){
                    //
                    hasFirstClicked = true;
                    // 停止自动旋转
                    window.pano.stopAutorotate();
                    
                    if(isAudioPlaying()){
                        showAudioPlayingView();
                    } else {
                        showAudioPausedView();
                    }
                }
            });
            // 不再继续执行
            return;
        }
        //
        // 如果是出去花园暂停的音乐，那么继续播放
        if(mydata.isGardenPauseMusic){
            playMyMusic();
            showAudioPlayingView();
            //
            mydata.isGardenPauseMusic = false;
        }
        //
        mydata.isInRoom = true;
    };
    //
    function innertoout(){
        // 如果从卧室出去
        if(mydata.isInRoom){
            // 暂停音乐
            if(isAudioPlaying()){
                pauseMyMusic();
                showAudioPausedView();
                //
                mydata.isGardenPauseMusic = true;
            }
            //
            mydata.isInRoom = false;
        } 
    };
    
    // 客厅到内部其他房间
    function halltoinner(){
    	// 不需要特殊处理
        // 修正 audio视图状态
        //fixAudioStatusView();
    };
    
    // 内景到客厅
    function innertohall(){
        // 修正 audio视图状态
        fixAudioStatusView();
    };
    
    
    
    /////////////////////////////////////////////////////////////////////
    // XXX 工具函数
    /**
     * 工具函数;
     * 传入URL,判断应该加载的配置文件; 不依赖于闭包环境
     * @param config_xml 全局值,如果没有则传入undefined;
     * @param url 为浏览器地址,如果不传入,则自己获取
     * @param scene 可用参数: "out"(默认);"hall";"bed";
     */ 
    function calculateStyleConfigXML(config_xml, url, scene){
        //
        if(config_xml){
            return config_xml;
        }
        // 参数默认值
        // location.pathname 只包含路径
        // location.hash #xx 部分
        //url = url || window.location.href; 
        url = url || window.location.pathname; // pathname 就是路径
        scene = scene || "out";
        if(!url){
            return "";
        }
        //
        var lastSlash = url.lastIndexOf("/");
        var styleName = url.substr(lastSlash+1);
        var no = styleName.match("\\d+");
        no = no || styleName.replace(".html","").replace("style","").replace("_direct","").replace("_offline","");
        if(/^\d+$/.test(no)){
            // 符合数字
            var result = "style" + no + "_" + scene + ".xml";
            return result;
        } else {
            return "";
        }
    };
    /**
     * 工具函数;
     * 传入URL,判断ServerBase; 不依赖于闭包环境
     * @param serverBase 全局值,如果没有则传入undefined;
     * @param url 为浏览器地址,如果不传入,则自己获取
     * @param faultVal 失败值,默认是 "http://m.iyhjy.com/"
     */ 
    function calculateServerBase(serverBase, url, faultVal){
        //
        if(serverBase){
            return serverBase;
        }
        // 参数默认值
        url = url || window.location.href;
        //url = url || window.location.host; // host 加上前缀就是基本路径
        //faultVal = faultVal || "http://m.ieternal.com/";
		faultVal = faultVal || "http://m.iyhjy.com/";
		//faultVal = faultVal || "http://test.iyhjy.com/";
        if(!url){
            return "";
        }
        //
        var httpIndex = url.indexOf("http:");
		/*if(httpIndex < 0 && window["localserverbase"]){
		   //alert(localserverbase);
		   if(localserverbase.indexOf("http:")>-1){
				return localserverbase;
		   }
        }*/
        if(httpIndex < 0){
            return faultVal;
        }
        var nextSlash = url.indexOf("/",httpIndex + 7);
        var result = url.substr(0,nextSlash+1);
        
        if(/\/$/.test(result)){
            return result;
        } else {
            return faultVal;
        }
    };
    
    /**
     * 工具函数;
     * 判断是否是离线状态
     * @param config_xml 全局值,如果没有则传入undefined;
     * @param url 为浏览器地址,如果不传入,则自己获取
     * @param scene 可用参数: "out"(默认);"hall";"bed";
     */ 
    function calculateOfflineStatus(isOffline, faultVal){
        //
        if(isOffline){
            return !!isOffline;
        }
        // 参数默认值
        var hash = window.location.hash;
        var pathname = window.location.pathname;
        faultVal = faultVal || false;
        // 含有 字符串 #offline
        if(/#offline/.test(hash)){
            return true;
        }  else if(/_offline/.test(pathname)){
        	return true;
        }
        //
        
        return faultVal;
    }
    
    /**
     * 阻止短时间内连续事件; 如果短时间内应该阻止用户操作,
     * 如果返回false,则事件处理函数应该不执行操作.
     * 如果返回 true,则事件处理函数可以继续执行处理
     */
    function preventMultiClick(){
        if(multiClickPrevent){
          return false;
        }
        multiClickPrevent = true;
        delay(function(){
            multiClickPrevent = false;
        },event_timeout);
        return true;
    };
    
    // 移除所有的 iFrame
    function removeIFrames(){
        window.$photoframe = null;
        window.$blogframe = null;
        $(".poplayer iframe").remove();
    };
    
    // 重置frame的宽高
    function resizeFrame(){
        //
        var width = getWindowWidth();
        var height = getWindowHeight();
        
        $("iframe").each(function(i,v){
            //
            $(v).css('width',width+"px");
            $(v).css('height',height+"px");
        });
        
        
        // 修正 正在加载的位置。
        var loading_left = (width-104)/2;
        var loading_top = (height-104)/2;
        $(".poplayer .loading").css("left", loading_left+"px").css("top", loading_top+"px");
    };
    // 延迟执行
    function delay(fn, millis){
    	millis = millis || 1 * 1000;
        window.setTimeout(fn, millis);
    };
    // 简单的 debug 函数
    function debug(info){
    	if(window["console"]){
    		window["console"].dir(info);
    	}
    };
    // 
    function getWindowWidth(){
        //
        var clientWidth = document.documentElement.clientWidth;
        var clientHeight = document.documentElement.clientHeight;
        
        var offsetWidth = document.documentElement.offsetWidth;
        var offsetHeight = document.documentElement.offsetHeight;
        //
        var bodyclientWidth = document.body.clientWidth;
        var bodyclientHeight = document.body.clientHeight;
        
        var bodyoffsetWidth = document.body.offsetWidth;
        var bodyoffsetHeight = document.body.offsetHeight;
        //
        var windowInnerWidth = window.innerWidth;
        var windowInnerHeight = window.innerHeight;
        
        var url = window.location.href || "";
        var width = clientWidth;
        var height = clientHeight;
        if(useragent.match(/iPhone|iPod/i) && url.indexOf("ieternal") > -1){
            width = windowInnerWidth;
            height = windowInnerHeight;
        }
        //
        return width;
    };
    //
    function getWindowHeight(){
        //
        var clientWidth = document.documentElement.clientWidth;
        var clientHeight = document.documentElement.clientHeight;
        
        var offsetWidth = document.documentElement.offsetWidth;
        var offsetHeight = document.documentElement.offsetHeight;
        //
        var bodyclientWidth = document.body.clientWidth;
        var bodyclientHeight = document.body.clientHeight;
        
        var bodyoffsetWidth = document.body.offsetWidth;
        var bodyoffsetHeight = document.body.offsetHeight;
        //
        var windowInnerWidth = window.innerWidth;
        var windowInnerHeight = window.innerHeight;
        
        var url = window.location.href || "";
        var width = clientWidth;
        var height = clientHeight;
        if(useragent.match(/iPhone|iPod/i) && url.indexOf("ieternal") > -1){
            width = windowInnerWidth;
            height = windowInnerHeight;
            $(".poplayer").css('width',width+'px').css('height',height+'px');
        }
        //
        return height;
    };
    
    /**
     * 工具函数,加载JavaScript
     * 参数: jsURL ; JS 的完全URL
     * 参数: reallyNeed ; true 则会真实加载,否则是虚拟加载(采用隐藏的 iframe 进行加载)
     * 执行: 根据IOS，或者android,执行不同的加载
     */ 
    function loadJavaScript(jsURL, reallyNeed){
    	if(!jsURL){
    		return ;
    	}
    	//
    	if(!reallyNeed){
    		//
    		return triggerLoad(jsURL);
    	} else {
    	}
    };
    // 触发加载,与app拦截交互
    function triggerLoad(jsURL){
    	if(!jsURL){
    		return false;
    	}
		//
		if(false && likeAndroid){
        	try{
        		//$.getScript(jsURL);
        	} catch(ex){
        		// 加载异常，不进行处理
        	}
        }
        else {
        	var lfs = '<iframe id="l_iframe_'+ (triggleLoadCounter++) + '" class="hide" src="'+ jsURL +'"></iframe>'; 
            var $loadframe = $(lfs);
            $loadframe.appendTo(".video2");
        }
    };
    // 
    function loadJSTrigerAPP(url, iframe_id, targetSelector){
    	if(!url){
    		return false;
    	}
    	if(likeAndroid){
			//如果是客户端则拦截，由客户端处理
			$.getScript(url);
		}else if(likeIOS){
			$iframe = $iframe || $("#"+iframe_id);
			if($iframe){
        		$iframe.remove();
        		$iframe = null;
        	}
        	targetSelector = targetSelector || ".video2";
        	//var $target = $(targetSelector);
        	if(!$iframe){
        		var lfs = '<iframe id="'+iframe_id+'" class="hide" src="'+ url +'"></iframe>'; 
            	$iframe = $(lfs);
            	$iframe.appendTo(targetSelector);
        	}
		} else {
			//console.info("url="+url);
		}
    };
    
    
	// 加载器执行完成
	function onPlayerLoaded(value){
		//
		value = value || window["percentLoaded"];
		// 
		if(1 === value){
		} else {
			// 继续延迟执行,20毫秒
			delay(onPlayerLoaded, 20);
			return false;
		}
		//
		var triggerURL = serverBase+"home/loaded.js.cache";
		loadJSTrigerAPP(triggerURL);
		/*
		if(likeAndroid){
			//如果是客户端则拦截，有客户端处理
			$.getScript(triggerURL);
		}else if(likeIOS){
			if(window.$loadframe){
        		window.$loadframe.remove();
        		window.$loadframe = null;
        	}
        	if(!window.$loadframe){
        		var lfs = '<iframe id="p_iframe" class="hide" src="'+ triggerURL +'"></iframe>'; 
            	window.$loadframe = $(lfs);
            	window.$loadframe.appendTo(".video2");
        	}
		} else {
			//console.info("triggerURL="+triggerURL);
		}
		*/
	};
	// 执行
	onPlayerLoaded(0);
    
    /////////////////////////////////////////////////////////////////////
    // XXX 末尾执行的代码
    resizeFrame();
    
    window.addEventListener("resize", resizeFrame);
    window.addEventListener("orientationchange", resizeFrame);
        
    // 显示 返回按钮
    if(likeIOS || true){
        $('.ios_back').removeClass(mydata.hideClass);
        //
        var $ios_back= $(".ios_back .anchor_back");
        $ios_back.attr('href',serverBase+"wap/user/home");
        
        $ios_back.bind(_click,function(e){
	        if(!preventMultiClick()){
	        	//
	        	return false;
	        };
        	//
        	if(window["userHadLocked"]){
                e.preventDefault();
                removeIFrames();
                //$("."+mydata.myAudioClassName).remove();
                showAudioPausedView();
                //
                if(likeAndroid){
                	try{
                		$.getScript(serverBase+"home/leavemessage.js");
                	} catch(ex){
                		// 加载异常，不进行处理
                	}
                }
                else {
		        	if(window.$messageframe){
		        		window.$messageframe.remove();
		        		window.$messageframe = null;
		        	}
		        	if(!window.$messageframe){
		        		var mfs = '<iframe id="m_iframe" class="hide" src="'+serverBase +'home/leavemessage.js"></iframe>'; 
		            	window.$messageframe = $(mfs);
		            	window.$messageframe.appendTo(".video2");
		        	}
                }
                e.preventDefault();
                return false;
            } else {
            	window.location.href = serverBase+"wap/user/home";
            }
	        
	    });
    }
    
    // 加载JS。跨域。也可以使用 < sc ript > 元素
    if(isOffline && url.indexOf("http") < 0){
    	// 不执行加载
    } else {
		//android和ios客户端加载本地模板，不拦截音乐，都网络请求音乐
	    try{
	    	$.getScript(serverBase+"home/music.js?callback=loadmusic");
	    } catch (ex){
	    	// 加载音乐信息
	    	debug("加载音乐出错");
	    }
		if(url.indexOf("http") < 0){
			//当android和ios客户端加载本地模板的时候，照片、视频是客户端拦截的，都不需要加载网络
			//donothing
		}else{
			try{
				$.getScript(serverBase+"home/photo.js?callback=loadphoto");
			} catch (ex){
				// 加载图片信息
				debug("加载图片出错");
			}
			try{
				$.getScript(serverBase+"home/video.js?callback=loadvideo");
			} catch (ex){
				// 加载视频信息
				debug("加载视频出错");
			}
		}
		if(url.indexOf("http") < 0 && likeAndroid){
			//当android客户端加载本地模板的时候，日记、家谱是客户端拦截的，都不需要加载网络
			//donothing
		}else{
			/*try{
				$.getScript(serverBase+"home/photo.js?callback=loadphoto");
			} catch (ex){
				// 加载图片信息
				debug("加载图片出错");
			}*/
			try{
				$.getScript(serverBase+"home/blog.js?callback=loadblog");
			} catch (ex){
				// 加载日记信息
				debug("加载日记出错");
			}
			try{
				$.getScript(serverBase+"home/family.js?callback=loadfamily");
			} catch (ex){
				// 加载家谱信息
				debug("加载家谱出错");
			}
		}
    }
});

/////////////////////////////////////////////////////////////////////
// XXX 全局加载函数

//从单个照片里处理出语音信息加入到语音数组
function generateVoices(photo){
	var imgurl = photo.attachURL;
	var voiceurl = photo.voiceURL;
	if(imgurl=="" || imgurl=="null" || imgurl==null || imgurl==undefined){
		return false;
	}
	if(voiceurl=="" || voiceurl=="null" || voiceurl==null || voiceurl==undefined){
		return false;
	}
	var key = imgurl.substr(imgurl.lastIndexOf("/")+1);
	if(window["mydata"]){
		if(mydata.voices==undefined){
			mydata.voices = new Array();
		}
    	mydata.voices[key]=voiceurl;
    }
}

// 载入照片
function loadphoto(photos){
    if(!Array.isArray(photos) || photos.length  < 1){
        if(window.console){
            console.log("loadphoto,failure,no photo");
            return;
        }
    }
    
    // 嵌套的情况
    var tempPhotos = [];
    $.each(photos,function(i,v){
    	if(v && v.photos){
    		var p = v.photos;
    		if(p && p.length){
    			tempPhotos = tempPhotos.concat(p);
				//需要取出照片中的语音信息存入另一个数组
				$.each(p,function(j,onephoto){
					generateVoices(onephoto);//处理语音
				});
				//需要判断当前分组是否是一生记忆的分组
				if(v.status==1){
					window["one_photos"] = p;
					if(window["mydata"]){
						mydata.one_photos = window["one_photos"];//赋值一生记忆的照片数据
						mydata["one_group"]=v;//赋值一生记忆相册数据
					}
				}
    		}
    	} else if(v && v.attachURL){
    		tempPhotos.push(v);
			//需要取出照片中的语音信息存入另一个数组
			generateVoices(v);//处理语音
    	}
    });
    
    //
    photos = tempPhotos;
    window["photos"] = tempPhotos;
    if(window["mydata"]){
    	mydata.photos = tempPhotos;
    }
    generatePhotoDOM(photos);
	generateGroupOnePhotoDOM();
};
// 生成PhotoDOM
var hasGeneratePhotoDOM = false;
function generatePhotoDOM(photos){
	if(hasGeneratePhotoDOM){
		return true;
	}
	//
	photos = photos || window["photos"];
	if(!photos){
		mydata = window["mydata"];
		if(mydata){
			photos = mydata.photos;
		}
	}
	//
	if(!photos){
		return false;
	}
    // 构造元素
    var $photo_ul = $(".photo_offline .photo_ul");
    if(photos.length>0){
		// 清空旧元素
		$photo_ul.empty();
		$.each(photos,function(i,v){
			var attachURL = v.attachURL || "";
			var content = v.content || "";
			var domStr = ""
				+ "<li class=\"photo_li\">"
				+ "  <a href=\""+ attachURL +"\" title=\""+content+"\">"
				+ "    <img alt=\""+content+"\" />"
				+ "  </a>"
				+ "</li>"
			;
			if(attachURL){
				var $photo_li = $(domStr);
				$photo_ul.append($photo_li);
			}
		});
		var voiceobj = document.getElementById("voiceid");
		if(voiceobj==undefined || voiceobj==null){
			//增加隐藏的语音播放器
			var $photodiv = $(".photo_offline");
			$photodiv.append("<div class=\"hide\"><audio hidden=\"true\" id=\"voiceid\" src=\"\" preload=\"none\"></audio></div>");
		}
	}else{
		//$photo_ul.html("<li class=\"photo_li\" style=\"vertical-align:middle;text-align:center;padding-top:100px;\"><a href=\"photo404.png\" title=\"没有图片\"><img alt=\"没有图片\"/></a></li>");
	}
    hasGeneratePhotoDOM = true;
};
//生成一生记忆photodom
var hasGenerateGroupOnePhotoDOM = false;
function generateGroupOnePhotoDOM(){
	if(hasGenerateGroupOnePhotoDOM){
		return true;
	}
	//构造一生记忆相册元素
	var $one_photo_ul = $(".photo_offline .one_photo_ul");
    if(mydata && mydata.one_photos && mydata.one_photos.length>0){
		// 清空旧元素
		$one_photo_ul.empty();
		//生成一生记忆的元素
		var one_photos=mydata.one_photos;
		$.each(one_photos,function(i,v){
			var attachURL = v.attachURL || "";
			var content = v.content || "";
			var domStr = ""
				+ "<li class=\"one_photo_li\">"
				+ "  <a href=\""+ attachURL +"\" title=\""+content+"\">"
				+ "    <img alt=\""+content+"\" />"
				+ "  </a>"
				+ "</li>"
			;
			if(attachURL){
				var $photo_li = $(domStr);
				$one_photo_ul.append($photo_li);
			}
		});
		var one_voiceobj = document.getElementById("one_voiceid");
		if(one_voiceobj==undefined || one_voiceobj==null){
			//增加一生记忆隐藏的语音播放器
			var $photodiv = $(".photo_offline");
			var voiceurl="";
			if(mydata && mydata.one_group){
				voiceurl=mydata.one_group.voiceURL;
			}
			$photodiv.append("<div class=\"hide\"><audio hidden=\"true\" id=\"one_voiceid\" src=\""+voiceurl+"\" preload=\"none\"></audio></div>");
		}
	}else{
	}
    hasGenerateGroupOnePhotoDOM = true;
};

// 导入家谱
var hasLoadFamilies = false;
function loadfamily(families){
    if(!Array.isArray(families)){
        if(window.console){
            console.log("loadfamily,failure,no families");
            return;
        }
    }
	if(hasLoadFamilies){
		return true;
	}
    if(window["mydata"]){
    	mydata.families = families;
    }
    window["families"] = families;
};

//
function appendfamily(f){
  $.extend(mydata.appendfamily,f);
};

// 导入视频地址
function loadvideo(videos){
    if(!Array.isArray(videos)){
        if(window.console){
            console.log("loadvideo,has no video");
        }
        return;
    }
    
    if(window["mydata"]){
    	mydata.videos = videos;
    }
    window["videos"] = videos;
    generateVideoDOM(videos);
};

// 生成
var hasGenerateVideoDOM = false;
function generateVideoDOM(videos){
	if(hasGenerateVideoDOM){
		return true;
	}
	//
	videos = videos || window["videos"];
	if(!videos){
		mydata = window["mydata"];
		if(mydata){
			videos = mydata.videos;
		}
	}
	//
	if(!videos){
		return false;
	}
	
	
    //
    var $video = $(".poplayer video");
    //
    if(videos.length < 1){
        //移除
        $(".video2 .videocontrol").remove();
        $(".video2 video").remove();
        // 显示 没有视频
        $(".video2 .nopic").removeClass(mydata.hideClass);
        //
        return false;
    } else if(navigator.userAgent.match(/iPad|iPhone|iPod/i) && videos.length > 1){
        // 多个，则显示
        $(".video2 .ios_switchvideo").removeClass(mydata.hideClass);
        $(".video2 .videocontrol").remove();
    }
    
    // 移除旧的source元素
    $("source",$video).remove();
    
    var sources = ""; 
    // 遍历，处理
    $.each(videos,function(i,v){
        var thumb = v.thumbnail;
        var attachURL = v.attachURL;
        var title =v.content || ("我的视频"+i) ||  v.title;
        if(title.length>10){
            title = title.substr(0,10);
        }
        v.title = title;
        if(0 == i){
            //
            $video.attr('src',attachURL);
            if(!!thumb){
                $video.attr("poster",thumb);
            }
            $(".video2 .video_title .video_intro").text(title);
        }
        // 
        sources +='<source src="'+attachURL+'"/>';
    });
    // 加入video下面
    $video.append(sources);
	
	//
	hasGenerateVideoDOM = true;
}; 

// 解析处理注入的分组数据,
// 屏蔽掉空的分组.
// 返回 处理好的分组,如果没有任何数据，则返回[]
function parseBlogToGroup(groups){
    // 临时
    var tempBlogs = [];
    // 可用分类
    var availableGroups = [];
    // 
    $.each(groups,function(i,v){
    	if(!v){
    		return;
    	}
    	// 传入的是分组的情况,分组 内部有 blogs字段
    	var blogs = v.blogs || [];
    	var blogcount = blogs.length;
    	if(blogcount > 0){
			// 数组连接
			//Array.prototype.push.apply(tempBlogs,p);
			//tempBlogs = tempBlogs.concat(p);
			// 合法的分组
			availableGroups.push(v);
    	}
    	// 传入的是 单个分组里面的所有日记,每个 v 就是一条记录
    	else if(v.blogId){
    		tempBlogs.push(v);
    	}
    });
    // hack
    if(availableGroups.length < 1){
    	var temp = {
    		blogType: 0
			,blogcount: 0
			,blogs: []
			,groupId: -1
			,remark: ""
			,theorder: 0
			,title: "默认分类"
    	};
    	//
    	if(tempBlogs.length > 0){
    		temp.blogs = tempBlogs;
    		temp.blogcount = tempBlogs.length;
    	}
    	//
    	if(temp.blogcount > 0){
    		availableGroups.push(temp);
    	}
    }
	//
	return availableGroups;
};
// 导入日记
function loadblog(blogs){
    if(!Array.isArray(blogs)){
        if(window.console){
            console.log("loadblog,failure,no blogs");
            return;
        }
    }
    var availableGroups = parseBlogToGroup(blogs);
    //
    if(window["mydata"]){
    	mydata.blogs = availableGroups;
    }
    window["blogs"] = availableGroups;
    generateBlogDOM(availableGroups);
    // 进行处理
};

// 生成 Blog DOM
function generateBlogDOM(availableGroups){
	//
	if(!availableGroups){
		availableGroups = window["blogs"];
		if(!availableGroups && window["mydata"]){
    		availableGroups = mydata.blogs;
    	}
	}
	//
	var $offlineBook = $(".offlinebook");
	//
	var $groupHTML = generateGroupList(availableGroups);
	var $CatalogHTML = generateAllCatalogs(availableGroups);
	// 情况
	$offlineBook.empty();
	$offlineBook.append($groupHTML);
	$offlineBook.append($CatalogHTML);
	
	//
	function generateGroupList(groups){
		var groupHTML = "" 
		+'<div class="group_container">'
		+'  <div class="group_catalog_header"> <span>个人图书馆</span> </div>'
		+'  <div class="group_catalog_content">'
		+'      <ul class="bcc_ul">';
		
	    // 
	    $.each(groups,function(i,v){
	    	if(!v){
	    		return;
	    	}
	    	// 传入的是分组的情况,分组 内部有 blogs字段
	    	var title = v.title || "第 "+(i+1)+" 本书";
	    	title = toHTML(title);
	    	var blogcount = v.blogcount;
	    	if(blogcount > 0){
				groupHTML = groupHTML
				+ '        <li class="bcc_type_li"> <a href="javascript:void(0)" class="tobook_' + i +'">' + title +' ['+ blogcount +']</a> </li>';
	    	}
	    });//
		groupHTML += ''
		+'      </ul>'
		+'  </div>'
		+'</div>';
		//
		return $(groupHTML);
	};
	
	// 生成所有
	function generateAllCatalogs(groups){
		var allHTML = '';
		// 遍历分组 
	    $.each(groups,function(i,g){
	    	if(!g){
	    		return;
	    	}
	    	var curHTML = '';
	    	// 先生成单本书的目录
	    	curHTML += generateOnlyCatalogHTML(g,i);
	    	//
	    	curHTML += '\n';
	    	// 再生成对应的单篇文章集合
	    	curHTML += generateOnlyBlogHTML(g,i);
	    	//
	    	allHTML += curHTML;
	    });//
	    
	    //
	    return $(allHTML);
	};
	
	// 仅仅生成目录的HTML
	function generateOnlyCatalogHTML(group,n){
		var cataHTML = '';
		//blogs字段
		var blogcount = group.blogcount;
	    var gtitle = group.title || "第 "+(n+1)+" 本书";
	    gtitle = toHTML(gtitle);
	    
	    cataHTML += ''
	    + '<div class="catalog hasblog hide">'
		  +'<h1>'
		    +'<a class="goto_catalog backtocatalog" style="text-decoration: none;color: #fff !important;" href="javascript:void(0)">'
		      +'<span>'+ gtitle +'</span>'
		    +'</a>'
		  +'</h1>'
		  +'<div class="catalist">'
		    +'<ul>';
		    
	    var blogs = group.blogs|| [];
		 $.each(blogs,function(i,b){
		 	if(!b){
		 		return;
		 	}
		 	//
		 	var blogId = b.blogId;
		 	var title = b.title;
		 	title = toHTML(title);
		 	var cls = '';
		 	if(blogcount == i+1){
		 		cls = 'last';
		 	} else if(0 == i){
		 		cls = 'first';
		 	}
		 	//
		 	var curCata = ''
		      +'<li class="'+ cls +'">'
		        +'<a class="fwdpage_'+ (i+1) +'" style="cursor:pointer;">'+ title +'</a>'
		      +'</li>';
		 	
		 	cataHTML += curCata;
		 });
		
	    cataHTML += ''
		    +'</ul>'
		    +'<div class="buttom_add hide" style="width:100%;height:66px;min-height:66px;">'
		      +'&nbsp;'
		    +'</div>'
		  +'</div>'
		+'</div>'
		;
		//
		return cataHTML;
	};
	// 仅仅生成详情的HTML
	function generateOnlyBlogHTML(group,gi){
		var allBlogHTML = '';
		
	    var blogs = group.blogs|| [];
		 $.each(blogs,function(i,b){
		 	if(!b){
		 		return;
		 	}
		 	//
		 	var blogId = b.blogId;
		 	var createTime = b.createTime;
		 	createTime = parseDate(createTime);
		 	
		 	var title = b.title;
		 	title = toHTML(title);
		 	
		 	var content = b.content;
		 	content = toHTML(content);
		 	//
		 	var curBlogHTML = ''
		 	+'<div class="diary1 hide">'
			    +'<div class="detail">'
			      +'<div class="top">'
				+'<div class="detail_title" style="word-break: break-all;">'+ title +'</div>'
				+'<span>'+ createTime +'</span>' 
			      +'</div>'
			      +'<div class="bottom">' + content +'</div>'
			      +'<div style="min-height:66px;width:100%;height:66px">&nbsp;</div>'
			    +'</div>'
			    +'<div class="borright">'
				+'<a class="prev_blog"><span>上一篇</span></a>'
				+'<a class="tobook_' + gi +'"><span>目录</span></a>'
				+'<a class="last next_blog"><span>下一篇</span></a>'
				+'<div class="cl"></div>'
			+'</div>'
			+'</div>'
			;
		 	//
		 	allBlogHTML += curBlogHTML;
		 });
		
		//
		return allBlogHTML;
	};
	
};

// 日期格式化
function parseDate(date){
	if(!date){
		return "0000-00-00 01:01";
	}
	var type = typeof date;
	if("string" === type){
		//var reg = /^\d+$/;
		date = Number(date);
		date = new Date(date);
	}
	if("number" === type){
		date = new Date(date);
	}
	//
	var year = date.getFullYear();
	var mon = 1+date.getMonth();
	var day = date.getDate();
	var hour = date.getHours();
	var minute = date.getMinutes();
	
	var res = "";
	res += year + "-";
	if(mon < 10){
		mon = "0"+mon;
	}
	res += mon + "-";
	if(day < 10){
		day = "0"+day;
	}
	res += day + " ";
	if(hour < 10){
		hour = "0"+hour;
	}
	res += hour + ":";
	if(minute < 10){
		minute = "0"+minute;
	}
	res += minute;
	//
	return res;
};

// 工具函数,去除特殊字符
function toHTML(html){
	html = html.replace(/\"/g,"&quot;");
	html = html.replace(/&/g,"&amp;");
	html = html.replace(/\'/g,"&#39;");
	html = html.replace(/</g,"&lt;");
	html = html.replace(/>/g,"&gt;");
	html = html.replace("\n","<br/>");
	//
	return html;
};
//计算MD5
window.md5=(function(){
	var hexcase=0;
	function md5(text){return hex_md5(""+text)};
	function hex_md5(a){ if(a=="") return a; return rstr2hex(rstr_md5(str2rstr_utf8(a)))}
	function hex_hmac_md5(a,b){return rstr2hex(rstr_hmac_md5(str2rstr_utf8(a),str2rstr_utf8(b)))}
	function md5_vm_test(){return hex_md5("abc").toLowerCase()=="900150983cd24fb0d6963f7d28e17f72"}
	function rstr_md5(a){return binl2rstr(binl_md5(rstr2binl(a),a.length*8))}
	function rstr_hmac_md5(c,f){var e=rstr2binl(c);if(e.length>16){e=binl_md5(e,c.length*8)}var a=Array(16),d=Array(16);for(var b=0;b<16;b++){a[b]=e[b]^909522486;d[b]=e[b]^1549556828}var g=binl_md5(a.concat(rstr2binl(f)),512+f.length*8);return binl2rstr(binl_md5(d.concat(g),512+128))}
	function rstr2hex(c){try{hexcase}catch(g){hexcase=0}var f=hexcase?"0123456789ABCDEF":"0123456789abcdef";var b="";var a;for(var d=0;d<c.length;d++){a=c.charCodeAt(d);b+=f.charAt((a>>>4)&15)+f.charAt(a&15)}return b}
	function str2rstr_utf8(c){var b="";var d=-1;var a,e;while(++d<c.length){a=c.charCodeAt(d);e=d+1<c.length?c.charCodeAt(d+1):0;if(55296<=a&&a<=56319&&56320<=e&&e<=57343){a=65536+((a&1023)<<10)+(e&1023);d++}if(a<=127){b+=String.fromCharCode(a)}else{if(a<=2047){b+=String.fromCharCode(192|((a>>>6)&31),128|(a&63))}else{if(a<=65535){b+=String.fromCharCode(224|((a>>>12)&15),128|((a>>>6)&63),128|(a&63))}else{if(a<=2097151){b+=String.fromCharCode(240|((a>>>18)&7),128|((a>>>12)&63),128|((a>>>6)&63),128|(a&63))}}}}}return b}
	function rstr2binl(b){var a=Array(b.length>>2);for(var c=0;c<a.length;c++){a[c]=0}for(var c=0;c<b.length*8;c+=8){a[c>>5]|=(b.charCodeAt(c/8)&255)<<(c%32)}return a}
	function binl2rstr(b){var a="";for(var c=0;c<b.length*32;c+=8){a+=String.fromCharCode((b[c>>5]>>>(c%32))&255)}return a}
	function binl_md5(p,k){p[k>>5]|=128<<((k)%32);p[(((k+64)>>>9)<<4)+14]=k;var o=1732584193;var n=-271733879;var m=-1732584194;var l=271733878;for(var g=0;g<p.length;g+=16){var j=o;var h=n;var f=m;var e=l;o=md5_ff(o,n,m,l,p[g+0],7,-680876936);l=md5_ff(l,o,n,m,p[g+1],12,-389564586);m=md5_ff(m,l,o,n,p[g+2],17,606105819);n=md5_ff(n,m,l,o,p[g+3],22,-1044525330);o=md5_ff(o,n,m,l,p[g+4],7,-176418897);l=md5_ff(l,o,n,m,p[g+5],12,1200080426);m=md5_ff(m,l,o,n,p[g+6],17,-1473231341);n=md5_ff(n,m,l,o,p[g+7],22,-45705983);o=md5_ff(o,n,m,l,p[g+8],7,1770035416);l=md5_ff(l,o,n,m,p[g+9],12,-1958414417);m=md5_ff(m,l,o,n,p[g+10],17,-42063);n=md5_ff(n,m,l,o,p[g+11],22,-1990404162);o=md5_ff(o,n,m,l,p[g+12],7,1804603682);l=md5_ff(l,o,n,m,p[g+13],12,-40341101);m=md5_ff(m,l,o,n,p[g+14],17,-1502002290);n=md5_ff(n,m,l,o,p[g+15],22,1236535329);o=md5_gg(o,n,m,l,p[g+1],5,-165796510);l=md5_gg(l,o,n,m,p[g+6],9,-1069501632);m=md5_gg(m,l,o,n,p[g+11],14,643717713);n=md5_gg(n,m,l,o,p[g+0],20,-373897302);o=md5_gg(o,n,m,l,p[g+5],5,-701558691);l=md5_gg(l,o,n,m,p[g+10],9,38016083);m=md5_gg(m,l,o,n,p[g+15],14,-660478335);n=md5_gg(n,m,l,o,p[g+4],20,-405537848);o=md5_gg(o,n,m,l,p[g+9],5,568446438);l=md5_gg(l,o,n,m,p[g+14],9,-1019803690);m=md5_gg(m,l,o,n,p[g+3],14,-187363961);n=md5_gg(n,m,l,o,p[g+8],20,1163531501);o=md5_gg(o,n,m,l,p[g+13],5,-1444681467);l=md5_gg(l,o,n,m,p[g+2],9,-51403784);m=md5_gg(m,l,o,n,p[g+7],14,1735328473);n=md5_gg(n,m,l,o,p[g+12],20,-1926607734);o=md5_hh(o,n,m,l,p[g+5],4,-378558);l=md5_hh(l,o,n,m,p[g+8],11,-2022574463);m=md5_hh(m,l,o,n,p[g+11],16,1839030562);n=md5_hh(n,m,l,o,p[g+14],23,-35309556);o=md5_hh(o,n,m,l,p[g+1],4,-1530992060);l=md5_hh(l,o,n,m,p[g+4],11,1272893353);m=md5_hh(m,l,o,n,p[g+7],16,-155497632);n=md5_hh(n,m,l,o,p[g+10],23,-1094730640);o=md5_hh(o,n,m,l,p[g+13],4,681279174);l=md5_hh(l,o,n,m,p[g+0],11,-358537222);m=md5_hh(m,l,o,n,p[g+3],16,-722521979);n=md5_hh(n,m,l,o,p[g+6],23,76029189);o=md5_hh(o,n,m,l,p[g+9],4,-640364487);l=md5_hh(l,o,n,m,p[g+12],11,-421815835);m=md5_hh(m,l,o,n,p[g+15],16,530742520);n=md5_hh(n,m,l,o,p[g+2],23,-995338651);o=md5_ii(o,n,m,l,p[g+0],6,-198630844);l=md5_ii(l,o,n,m,p[g+7],10,1126891415);m=md5_ii(m,l,o,n,p[g+14],15,-1416354905);n=md5_ii(n,m,l,o,p[g+5],21,-57434055);o=md5_ii(o,n,m,l,p[g+12],6,1700485571);l=md5_ii(l,o,n,m,p[g+3],10,-1894986606);m=md5_ii(m,l,o,n,p[g+10],15,-1051523);n=md5_ii(n,m,l,o,p[g+1],21,-2054922799);o=md5_ii(o,n,m,l,p[g+8],6,1873313359);l=md5_ii(l,o,n,m,p[g+15],10,-30611744);m=md5_ii(m,l,o,n,p[g+6],15,-1560198380);n=md5_ii(n,m,l,o,p[g+13],21,1309151649);o=md5_ii(o,n,m,l,p[g+4],6,-145523070);l=md5_ii(l,o,n,m,p[g+11],10,-1120210379);m=md5_ii(m,l,o,n,p[g+2],15,718787259);n=md5_ii(n,m,l,o,p[g+9],21,-343485551);o=safe_add(o,j);n=safe_add(n,h);m=safe_add(m,f);l=safe_add(l,e)}return Array(o,n,m,l)}
	function md5_cmn(h,e,d,c,g,f){return safe_add(bit_rol(safe_add(safe_add(e,h),safe_add(c,f)),g),d)}
	function md5_ff(g,f,k,j,e,i,h){return md5_cmn((f&k)|((~f)&j),g,f,e,i,h)}
	function md5_gg(g,f,k,j,e,i,h){return md5_cmn((f&j)|(k&(~j)),g,f,e,i,h)}
	function md5_hh(g,f,k,j,e,i,h){return md5_cmn(f^k^j,g,f,e,i,h)}
	function md5_ii(g,f,k,j,e,i,h){return md5_cmn(k^(f|(~j)),g,f,e,i,h)}
	function safe_add(a,d){var c=(a&65535)+(d&65535);var b=(a>>16)+(d>>16)+(c>>16);return(b<<16)|(c&65535)}
	function bit_rol(a,b){return(a<<b)|(a>>>(32-b))};
	return md5;
}());