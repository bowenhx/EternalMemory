// Garden Gnome Software - Skin
// Pano2VR pro 4.1.0/3405MS
// Filename: em.ggsk
// Generated Thu Jul 11 17:50:29 2013

function pano2vrSkin(player,base) {
	var me=this;
	var flag=false;
	var nodeMarker=new Array();
	var activeNodeMarker=new Array();
	this.player=player;
	this.player.skinObj=this;
	this.divSkin=player.divSkin;
	var basePath="";
	// auto detect base path
	if (base=='?') {
		var scripts = document.getElementsByTagName('script');
		for(var i=0;i<scripts.length;i++) {
			var src=scripts[i].src;
			if (src.indexOf('skin.js')>=0) {
				var p=src.lastIndexOf('/');
				if (p>=0) {
					basePath=src.substr(0,p+1);
				}
			}
		}
	} else
	if (base) {
		basePath=base;
	}
	this.elementMouseDown=new Array();
	this.elementMouseOver=new Array();
	var cssPrefix='';
	var domTransition='transition';
	var domTransform='transform';
	var prefixes='Webkit,Moz,O,ms,Ms'.split(',');
	var i;
	for(i=0;i<prefixes.length;i++) {
		if (typeof document.body.style[prefixes[i] + 'Transform'] !== 'undefined') {
			cssPrefix='-' + prefixes[i].toLowerCase() + '-';
			domTransition=prefixes[i] + 'Transition';
			domTransform=prefixes[i] + 'Transform';
		}
	}
	
	this.player.setMargins(0,0,0,0);
	
	this.updateSize=function(startElement) {
		var stack=new Array();
		stack.push(startElement);
		while(stack.length>0) {
			e=stack.pop();
			if (e.ggUpdatePosition) {
				e.ggUpdatePosition();
			}
			if (e.hasChildNodes()) {
				for(i=0;i<e.childNodes.length;i++) {
					stack.push(e.childNodes[i]);
				}
			}
		}
	}
	
	parameterToTransform=function(p) {
		return 'translate(' + p.rx + 'px,' + p.ry + 'px) rotate(' + p.a + 'deg) scale(' + p.sx + ',' + p.sy + ')';
	}
	
	this.findElements=function(id,regex) {
		var r=new Array();
		var stack=new Array();
		var pat=new RegExp(id,'');
		stack.push(me.divSkin);
		while(stack.length>0) {
			e=stack.pop();
			if (regex) {
				if (pat.test(e.ggId)) r.push(e);
			} else {
				if (e.ggId==id) r.push(e);
			}
			if (e.hasChildNodes()) {
				for(i=0;i<e.childNodes.length;i++) {
					stack.push(e.childNodes[i]);
				}
			}
		}
		return r;
	}
	
	this.addSkin=function() {
		this._loading=document.createElement('div');
		this._loading.ggId='loading';
		this._loading.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._loading.ggVisible=true;
		this._loading.className='ggskin ggskin_container loading';
		this._loading.ggUpdatePosition=function() {
			this.style[domTransition]='none';
			if (this.parentNode) {
				w=this.parentNode.offsetWidth;
				this.style.left=(-105 + w/2) + 'px';
				h=this.parentNode.offsetHeight;
				this.style.top=(-30 + h/2) + 'px';
			}
		}
		hs ='position:absolute;';
		hs+='left: -105px;';
		hs+='top:  -30px;';
		hs+='width: 210px;';
		hs+='height: 60px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		this._loading.setAttribute('style',hs);
		this._loading.onclick=function () {
			me._loading.style[domTransition]='none';
			me._loading.style.visibility='hidden';
			me._loading.ggVisible=false;
		}
		this._loadingbg=document.createElement('div');
		this._loadingbg.ggId='loadingbg';
		this._loadingbg.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._loadingbg.ggVisible=true;
		this._loadingbg.className='ggskin ggskin_rectangle loadingbg';
		hs ='position:absolute;';
		hs+='left: 0px;';
		hs+='top:  0px;';
		hs+='width: 210px;';
		hs+='height: 60px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='opacity: 0.5;';
		hs+='visibility: inherit;';
		hs+='background: #000000;';
		hs+='border: 0px solid #000000;';
		hs+='border-radius: 10px;';
		hs+=cssPrefix + 'border-radius: 10px;';
		this._loadingbg.setAttribute('style',hs);
		this._loading.appendChild(this._loadingbg);
		this._loadingbrd=document.createElement('div');
		this._loadingbrd.ggId='loadingbrd';
		this._loadingbrd.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._loadingbrd.ggVisible=true;
		this._loadingbrd.className='ggskin ggskin_rectangle loadingbrd';
		hs ='position:absolute;';
		hs+='left: -1px;';
		hs+='top:  -1px;';
		hs+='width: 208px;';
		hs+='height: 58px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='opacity: 0.5;';
		hs+='visibility: inherit;';
		hs+='border: 2px solid #ffffff;';
		hs+='border-radius: 10px;';
		hs+=cssPrefix + 'border-radius: 10px;';
		this._loadingbrd.setAttribute('style',hs);
		this._loading.appendChild(this._loadingbrd);
		this._loadingtext=document.createElement('div');
		this._loadingtext.ggId='loadingtext';
		this._loadingtext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._loadingtext.ggVisible=true;
		this._loadingtext.className='ggskin ggskin_text loadingtext';
		hs ='position:absolute;';
		hs+='left: 16px;';
		hs+='top:  12px;';
		hs+='width: auto;';
		hs+='height: auto;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='border: 0px solid #000000;';
		hs+='color: #ffffff;';
		hs+='text-align: left;';
		hs+='white-space: nowrap;';
		hs+='padding: 0px 1px 0px 1px;';
		hs+='overflow: hidden;';
		this._loadingtext.setAttribute('style',hs);
		this._loadingtext.ggUpdateText=function() {
			var percentLoaded= me.player.getPercentLoaded();
			var perc = (percentLoaded*100.0).toFixed(0);
			if(perc < 100){
			} else if(!window["percentLoaded"]){
				window["percentLoaded"] = 1;
			}
			var hs="进度... "+perc+"%";
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.innerHTML=hs;
			}
		}
		this._loadingtext.ggUpdateText();
		this._loading.appendChild(this._loadingtext);
		this._loadingbar=document.createElement('div');
		this._loadingbar.ggId='loadingbar';
		this._loadingbar.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._loadingbar.ggVisible=true;
		this._loadingbar.className='ggskin ggskin_rectangle loadingbar';
		hs ='position:absolute;';
		hs+='left: 15px;';
		hs+='top:  35px;';
		hs+='width: 181px;';
		hs+='height: 12px;';
		hs+=cssPrefix + 'transform-origin: 0% 50%;';
		hs+='visibility: inherit;';
		hs+='background: #ffffff;';
		hs+='border: 1px solid #808080;';
		hs+='border-radius: 5px;';
		hs+=cssPrefix + 'border-radius: 5px;';
		this._loadingbar.setAttribute('style',hs);
		this._loading.appendChild(this._loadingbar);
		this.divSkin.appendChild(this._loading);
		this.divSkin.ggUpdateSize=function(w,h) {
			me.updateSize(me.divSkin);
		}
		this.divSkin.ggViewerInit=function() {
		}
		this.divSkin.ggLoaded=function() {
			me._loading.style[domTransition]='none';
			me._loading.style.visibility='hidden';
			me._loading.ggVisible=false;
		}
		this.divSkin.ggReLoaded=function() {
			me._loading.style[domTransition]='none';
			me._loading.style.visibility='inherit';
			me._loading.ggVisible=true;
		}
		this.divSkin.ggEnterFullscreen=function() {
		}
		this.divSkin.ggExitFullscreen=function() {
		}
		this.skinTimerEvent();
	};
	this.hotspotProxyClick=function(id) {
	}
	this.hotspotProxyOver=function(id) {
	}
	this.hotspotProxyOut=function(id) {
	}
	this.changeActiveNode=function(id) {
		var newMarker=new Array();
		var i,j;
		var tags=me.player.userdata.tags;
		for (i=0;i<nodeMarker.length;i++) {
			var match=false;
			if (nodeMarker[i].ggMarkerNodeId==id) match=true;
			for(j=0;j<tags.length;j++) {
				if (nodeMarker[i].ggMarkerNodeId==tags[j]) match=true;
			}
			if (match) {
				newMarker.push(nodeMarker[i]);
			}
		}
		for(i=0;i<activeNodeMarker.length;i++) {
			if (newMarker.indexOf(activeNodeMarker[i])<0) {
				if (activeNodeMarker[i].ggMarkerNormal) {
					activeNodeMarker[i].ggMarkerNormal.style.visibility='inherit';
				}
				if (activeNodeMarker[i].ggMarkerActive) {
					activeNodeMarker[i].ggMarkerActive.style.visibility='hidden';
				}
				if (activeNodeMarker[i].ggDeactivate) {
					activeNodeMarker[i].ggDeactivate();
				}
			}
		}
		for(i=0;i<newMarker.length;i++) {
			if (activeNodeMarker.indexOf(newMarker[i])<0) {
				if (newMarker[i].ggMarkerNormal) {
					newMarker[i].ggMarkerNormal.style.visibility='hidden';
				}
				if (newMarker[i].ggMarkerActive) {
					newMarker[i].ggMarkerActive.style.visibility='inherit';
				}
				if (newMarker[i].ggActivate) {
					newMarker[i].ggActivate();
				}
			}
		}
		activeNodeMarker=newMarker;
	}
	this.skinTimerEvent=function() {
		setTimeout(function() { me.skinTimerEvent(); }, 10);
		if (me.elementMouseDown['up']) {
			me.player.changeTilt(1,true);
		}
		if (me.elementMouseDown['down']) {
			me.player.changeTilt(-1,true);
		}
		if (me.elementMouseDown['left']) {
			me.player.changePan(1,true);
		}
		if (me.elementMouseDown['right0']) {
			me.player.changePan(-1,true);
		}
		if (me.elementMouseDown['zoomin']) {
			me.player.changeFovLog(-1,true);
		}
		if (me.elementMouseDown['zoomout']) {
			me.player.changeFovLog(1,true);
		}
		this._loadingtext.ggUpdateText();
		var hs='';
		if (me._loadingbar.ggParameter) {
			hs+=parameterToTransform(me._loadingbar.ggParameter) + ' ';
		}
		hs+='scale(' + (1 * me.player.getPercentLoaded() + 0) + ',1.0) ';
		me._loadingbar.style[domTransform]=hs;
		//this._title.ggUpdateText();
		//this._description.ggUpdateText();
		//this._author.ggUpdateText();
		//this._datetime.ggUpdateText();
		//this._copyright.ggUpdateText();
	};
	function SkinHotspotClass(skinObj,hotspot) {
		var me=this;
		var flag=false;
		this.player=skinObj.player;
		this.skin=skinObj;
		this.hotspot=hotspot;
		this.elementMouseDown=new Array();
		this.elementMouseOver=new Array();
		this.__div=document.createElement('div');
		this.__div.setAttribute('style','position:absolute; left:0px;top:0px;visibility: inherit;');
		
		this.findElements=function(id,regex) {
			return me.skin.findElements(id,regex);
		}
		
		if (hotspot.skinid=='audio') {
			this.__div=document.createElement('div');
			this.__div.ggId='audio';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot audio';
			hs ='position:absolute;';
			hs+='left: 288px;';
			hs+='top:  72px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this._audio_pre=document.createElement('div');
			this._audio_pre.ggId='audio_pre';
			this._audio_pre.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._audio_pre.ggVisible=true;
			this._audio_pre.className='ggskin ggskin_image audio_pre';
			hs ='position:absolute;';
			hs+='left: -71px;';
			hs+='top:  -31px;';
			hs+='width: 40px;';
			hs+='height: 40px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='opacity: 0.5;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._audio_pre.setAttribute('style',hs);
			this._audio_pre__img=document.createElement('img');
			this._audio_pre__img.setAttribute('src',basePath + 'images/audio_pre.png');
			this._audio_pre__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._audio_pre__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._audio_pre__img);
			this._audio_pre.appendChild(this._audio_pre__img);
			this._audio_pre.onmouseover=function () {
				me.elementMouseOver['audio_pre']=true;
			}
			this._audio_pre.onmouseout=function () {
				if (me.player.transitionsDisabled) {
					me._audio_pre.style[domTransition]='none';
				} else {
					me._audio_pre.style[domTransition]='all 500ms ease-out 0ms';
				}
				me._audio_pre.style.opacity='0.5';
				me._audio_pre.style.visibility=me._audio_pre.ggVisible?'inherit':'hidden';
				me.elementMouseOver['audio_pre']=false;
			}
			this._audio_pre.ontouchend=function () {
				me.elementMouseOver['audio_pre']=false;
			}
			this.__div.appendChild(this._audio_pre);
			this._audio_next=document.createElement('div');
			this._audio_next.ggId='audio_next';
			this._audio_next.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._audio_next.ggVisible=true;
			this._audio_next.className='ggskin ggskin_image audio_next';
			hs ='position:absolute;';
			hs+='left: 11px;';
			hs+='top:  -32px;';
			hs+='width: 40px;';
			hs+='height: 40px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='opacity: 0.5;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._audio_next.setAttribute('style',hs);
			this._audio_next__img=document.createElement('img');
			this._audio_next__img.setAttribute('src',basePath + 'images/audio_next.png');
			this._audio_next__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._audio_next__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._audio_next__img);
			this._audio_next.appendChild(this._audio_next__img);
			this._audio_next.onmouseover=function () {
				me.elementMouseOver['audio_next']=true;
			}
			this._audio_next.onmouseout=function () {
				if (me.player.transitionsDisabled) {
					me._audio_next.style[domTransition]='none';
				} else {
					me._audio_next.style[domTransition]='all 500ms ease-out 0ms';
				}
				me._audio_next.style.opacity='0.5';
				me._audio_next.style.visibility=me._audio_next.ggVisible?'inherit':'hidden';
				me.elementMouseOver['audio_next']=false;
			}
			this._audio_next.ontouchend=function () {
				me.elementMouseOver['audio_next']=false;
			}
			this.__div.appendChild(this._audio_next);
			this._audio_off=document.createElement('div');
			this._audio_off.ggId='audio_off';
			this._audio_off.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._audio_off.ggVisible=false;
			this._audio_off.className='ggskin ggskin_image audio_off';
			hs ='position:absolute;';
			hs+='left: -31px;';
			hs+='top:  -31px;';
			hs+='width: 40px;';
			hs+='height: 40px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='cursor: pointer;';
			this._audio_off.setAttribute('style',hs);
			this._audio_off__img=document.createElement('img');
			this._audio_off__img.setAttribute('src',basePath + 'images/audio_off.png');
			this._audio_off__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._audio_off__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._audio_off__img);
			this._audio_off.appendChild(this._audio_off__img);
			this._audio_off.onclick=function () {
				// me.player.pauseSound("music");
				// me._audio0.style[domTransition]='none';
				// me._audio0.style.visibility='inherit';
				// me._audio0.ggVisible=true;
				// me._audio_off.style[domTransition]='none';
				// me._audio_off.style.visibility='hidden';
				// me._audio_off.ggVisible=false;
			}
			this._audio_off.onmouseover=function () {
				me.elementMouseOver['audio_off']=true;
			}
			this._audio_off.onmouseout=function () {
				if (me.player.transitionsDisabled) {
					me._audio_off.style[domTransition]='none';
				} else {
					me._audio_off.style[domTransition]='all 500ms ease-out 0ms';
				}
				me._audio_off.style.opacity='0.5';
				me._audio_off.style.visibility=me._audio_off.ggVisible?'inherit':'hidden';
				me.elementMouseOver['audio_off']=false;
			}
			this._audio_off.ontouchend=function () {
				me.elementMouseOver['audio_off']=false;
			}
			this.__div.appendChild(this._audio_off);
			this._audio0=document.createElement('div');
			this._audio0.ggId='audio';
			this._audio0.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._audio0.ggVisible=true;
			this._audio0.className='ggskin ggskin_image audio_on';
			hs ='position:absolute;';
			hs+='left: -30px;';
			hs+='top:  -30px;';
			hs+='width: 40px;';
			hs+='height: 40px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='opacity: 0.5;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._audio0.setAttribute('style',hs);
			this._audio0__img=document.createElement('img');
			this._audio0__img.setAttribute('src',basePath + 'images/audio0.png');
			this._audio0__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._audio0__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._audio0__img);
			this._audio0.appendChild(this._audio0__img);
			this._audio0.onclick=function () {
				// me._audio_off.style[domTransition]='none';
				// me._audio_off.style.visibility='inherit';
				// me._audio_off.ggVisible=true;
				// me.player.playSound("music","");
				// me._audio0.style[domTransition]='none';
				// me._audio0.style.visibility='hidden';
				// me._audio0.ggVisible=false;
			}
			this._audio0.onmouseover=function () {
				me._audio0.style[domTransition]='none';
				me._audio0.style.opacity='1';
				me._audio0.style.visibility=me._audio0.ggVisible?'inherit':'hidden';
			}
			this._audio0.onmouseout=function () {
				if (me.player.transitionsDisabled) {
					me._audio0.style[domTransition]='none';
				} else {
					me._audio0.style[domTransition]='all 500ms ease-out 0ms';
				}
				me._audio0.style.opacity='0.5';
				me._audio0.style.visibility=me._audio0.ggVisible?'inherit':'hidden';
			}
			this.__div.appendChild(this._audio0);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['audio_pre']) {
					if (me.player.transitionsDisabled) {
						me._audio_pre.style[domTransition]='none';
					} else {
						me._audio_pre.style[domTransition]='all 500ms ease-out 0ms';
					}
					me._audio_pre.style.opacity='1';
					me._audio_pre.style.visibility=me._audio_pre.ggVisible?'inherit':'hidden';
				}
				if (me.elementMouseOver['audio_next']) {
					if (me.player.transitionsDisabled) {
						me._audio_next.style[domTransition]='none';
					} else {
						me._audio_next.style[domTransition]='all 500ms ease-out 0ms';
					}
					me._audio_next.style.opacity='1';
					me._audio_next.style.visibility=me._audio_next.ggVisible?'inherit':'hidden';
				}
				if (me.elementMouseOver['audio_off']) {
					if (me.player.transitionsDisabled) {
						me._audio_off.style[domTransition]='none';
					} else {
						me._audio_off.style[domTransition]='all 500ms ease-out 0ms';
					}
					me._audio_off.style.opacity='1';
					me._audio_off.style.visibility=me._audio_off.ggVisible?'inherit':'hidden';
				}
			}
			this.hotspotTimerEvent();
		} else
		if (hotspot.skinid=='video') {
			this.__div=document.createElement('div');
			this.__div.ggId='video';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot video';
			hs ='position:absolute;';
			hs+='left: 113px;';
			hs+='top:  65px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this._video_play=document.createElement('div');
			this._video_play.ggId='video_play';
			this._video_play.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._video_play.ggVisible=true;
			this._video_play.className='ggskin ggskin_image video_play';
			hs ='position:absolute;';
			hs+='left: -20px;';
			hs+='top:  -21px;';
			hs+='width: 42px;';
			hs+='height: 42px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='opacity: 0.5;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._video_play.setAttribute('style',hs);
			this._video_play__img=document.createElement('img');
			this._video_play__img.setAttribute('src',basePath + 'images/video_play.png');
			this._video_play__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._video_play__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._video_play__img);
			this._video_play.appendChild(this._video_play__img);
			this._video_play.onmouseover=function () {
				me.elementMouseOver['video_play']=true;
			}
			this._video_play.onmouseout=function () {
				if (me.player.transitionsDisabled) {
					me._video_play.style[domTransition]='none';
				} else {
					me._video_play.style[domTransition]='all 500ms ease-out 0ms';
				}
				me._video_play.style.opacity='0.5';
				me._video_play.style.visibility=me._video_play.ggVisible?'inherit':'hidden';
				me.elementMouseOver['video_play']=false;
			}
			this._video_play.ontouchend=function () {
				me.elementMouseOver['video_play']=false;
			}
			this.__div.appendChild(this._video_play);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['video_play']) {
					if (me.player.transitionsDisabled) {
						me._video_play.style[domTransition]='none';
					} else {
						me._video_play.style[domTransition]='all 500ms ease-out 0ms';
					}
					me._video_play.style.opacity='1';
					me._video_play.style.visibility=me._video_play.ggVisible?'inherit':'hidden';
				}
			}
			this.hotspotTimerEvent();
		} else
		if (hotspot.skinid=='photo') {
			this.__div=document.createElement('div');
			this.__div.ggId='photo';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot photo';
			hs ='position:absolute;';
			hs+='left: 203px;';
			hs+='top:  25px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.elementMouseOver['_div']=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._phototext.style[domTransition]='none';
				me._phototext.style.visibility='hidden';
				me._phototext.ggVisible=false;
				me.elementMouseOver['_div']=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this.__div.ontouchend=function () {
				me.elementMouseOver['_div']=false;
			}
			this._phototext=document.createElement('div');
			this._phototext.ggId='phototext';
			this._phototext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._phototext.ggVisible=false;
			this._phototext.className='ggskin ggskin_text phototext';
			hs ='position:absolute;';
			hs+='left: 15px;';
			hs+='top:  -13px;';
			hs+='width: 99px;';
			hs+='height: 19px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._phototext.setAttribute('style',hs);
			this._phototext.innerHTML=me.hotspot.title;
			this.__div.appendChild(this._phototext);
			this._photos=document.createElement('div');
			this._photos.ggId='photos';
			this._photos.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._photos.ggVisible=true;
			this._photos.className='ggskin ggskin_image photos';
			hs ='position:absolute;';
			hs+='left: -11px;';
			hs+='top:  -12px;';
			hs+='width: 36px;';
			hs+='height: 36px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._photos.setAttribute('style',hs);
			this._photos__img=document.createElement('img');
			this._photos__img.setAttribute('src',basePath + 'images/photos.png');
			this._photos__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._photos__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._photos__img);
			this._photos.appendChild(this._photos__img);
			this.__div.appendChild(this._photos);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['_div']) {
					me._phototext.style[domTransition]='none';
					me._phototext.style.visibility='inherit';
					me._phototext.ggVisible=true;
				}
			}
			this.hotspotTimerEvent();
		}  else
		if (hotspot.skinid=='book') {
			this.__div=document.createElement('div');
			this.__div.ggId='book';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot book';
			hs ='position:absolute;';
			hs+='left: 203px;';
			hs+='top:  25px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.elementMouseOver['_div']=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._booktext.style[domTransition]='none';
				me._booktext.style.visibility='hidden';
				me._booktext.ggVisible=false;
				me.elementMouseOver['_div']=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this.__div.ontouchend=function () {
				me.elementMouseOver['_div']=false;
			}
			this._booktext=document.createElement('div');
			this._booktext.ggId='booktext';
			this._booktext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._booktext.ggVisible=false;
			this._booktext.className='ggskin ggskin_text booktext';
			hs ='position:absolute;';
			hs+='left: 15px;';
			hs+='top:  -13px;';
			hs+='width: 99px;';
			hs+='height: 19px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._booktext.setAttribute('style',hs);
			this._booktext.innerHTML=me.hotspot.title;
			this.__div.appendChild(this._booktext);
			this._books=document.createElement('div');
			this._books.ggId='books';
			this._books.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._books.ggVisible=true;
			this._books.className='ggskin ggskin_image books';
			hs ='position:absolute;';
			hs+='left: -11px;';
			hs+='top:  -12px;';
			hs+='width: 36px;';
			hs+='height: 36px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._books.setAttribute('style',hs);
			this._books__img=document.createElement('img');
			this._books__img.setAttribute('src',basePath + 'images/books.png');
			this._books__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._books__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._books__img);
			this._books.appendChild(this._books__img);
			this.__div.appendChild(this._books);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['_div']) {
					me._booktext.style[domTransition]='none';
					me._booktext.style.visibility='inherit';
					me._booktext.ggVisible=true;
				}
			}
			this.hotspotTimerEvent();
		}  else
		if (hotspot.skinid=='family') {
			this.__div=document.createElement('div');
			this.__div.ggId='family';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot family';
			hs ='position:absolute;';
			hs+='left: 203px;';
			hs+='top:  25px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.elementMouseOver['_div']=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._familytext.style[domTransition]='none';
				me._familytext.style.visibility='hidden';
				me._familytext.ggVisible=false;
				me.elementMouseOver['_div']=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this.__div.ontouchend=function () {
				me.elementMouseOver['_div']=false;
			}
			this._familytext=document.createElement('div');
			this._familytext.ggId='familytext';
			this._familytext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._familytext.ggVisible=false;
			this._familytext.className='ggskin ggskin_text familytext';
			hs ='position:absolute;';
			hs+='left: 15px;';
			hs+='top:  -13px;';
			hs+='width: 99px;';
			hs+='height: 19px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._familytext.setAttribute('style',hs);
			this._familytext.innerHTML=me.hotspot.title;
			this.__div.appendChild(this._familytext);
			this._familys=document.createElement('div');
			this._familys.ggId='familys';
			this._familys.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._familys.ggVisible=true;
			this._familys.className='ggskin ggskin_image familys';
			hs ='position:absolute;';
			hs+='left: -11px;';
			hs+='top:  -12px;';
			hs+='width: 36px;';
			hs+='height: 36px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._familys.setAttribute('style',hs);
			this._familys__img=document.createElement('img');
			this._familys__img.setAttribute('src',basePath + 'images/familys.png');
			this._familys__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._familys__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._familys__img);
			this._familys.appendChild(this._familys__img);
			this.__div.appendChild(this._familys);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['_div']) {
					me._familytext.style[domTransition]='none';
					me._familytext.style.visibility='inherit';
					me._familytext.ggVisible=true;
				}
			}
			this.hotspotTimerEvent();
		} else
		if (hotspot.skinid=='message') {
			this.__div=document.createElement('div');
			this.__div.ggId='message';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot message';
			hs ='position:absolute;';
			hs+='left: 257px;';
			hs+='top:  221px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.elementMouseOver['_div']=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._messagetext.style[domTransition]='none';
				me._messagetext.style.visibility='hidden';
				me._messagetext.ggVisible=false;
				me.elementMouseOver['_div']=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this.__div.ontouchend=function () {
				me.elementMouseOver['_div']=false;
			}
			this._messagetext=document.createElement('div');
			this._messagetext.ggId='messagetext';
			this._messagetext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._messagetext.ggVisible=false;
			this._messagetext.className='ggskin ggskin_text';
			hs ='position:absolute;';
			hs+='left: 28px;';
			hs+='top:  -10px;';
			hs+='width: 99px;';
			hs+='height: 19px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._messagetext.setAttribute('style',hs);
			this._messagetext.innerHTML=me.hotspot.title;
			this.__div.appendChild(this._messagetext);
			this._message0=document.createElement('div');
			this._message0.ggId='message';
			this._message0.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._message0.ggVisible=true;
			this._message0.className='ggskin ggskin_image messages';
			hs ='position:absolute;';
			hs+='left: -10px;';
			hs+='top:  -13px;';
			hs+='width: 40px;';
			hs+='height: 29px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._message0.setAttribute('style',hs);
			this._message0__img=document.createElement('img');
			this._message0__img.setAttribute('src',basePath + 'images/messages.png');
			this._message0__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._message0__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._message0__img);
			this._message0.appendChild(this._message0__img);
			this.__div.appendChild(this._message0);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['_div']) {
					me._messagetext.style[domTransition]='none';
					me._messagetext.style.visibility='inherit';
					me._messagetext.ggVisible=true;
				}
			}
			this.hotspotTimerEvent();
		} else 
		if(hotspot.skinid){
			var skinId = hotspot.skinid;
			this.__div=document.createElement('div');
			this.__div.ggId=skinId;
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot '+ skinId;
			hs ='position:absolute;';
			hs+='left: 340px;';
			hs+='top:  20px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me._hstext.style[domTransition]='none';
				me._hstext.style.visibility='inherit';
				me._hstext.ggVisible=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._hstext.style[domTransition]='none';
				me._hstext.style.visibility='hidden';
				me._hstext.ggVisible=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this._hsimage=document.createElement('div');
			this._hsimage.ggId='hsimage';
			this._hsimage.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._hsimage.ggVisible=true;
			this._hsimage.className='ggskin ggskin_svg hsimage';
			hs ='position:absolute;';
			hs+='left: -16px;';
			hs+='top:  -16px;';
			hs+='width: 32px;';
			hs+='height: 32px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._hsimage.setAttribute('style',hs);
			this._hsimage__img=document.createElement('img');
			this._hsimage__img.setAttribute('src',basePath + 'images/' + skinId + ".png");
			this._hsimage__img.setAttribute('style','position: absolute;top: 0px;left: 0px;width: 32px;height: 32px;-webkit-user-drag:none;');
			this._hsimage__img['ondragstart']=function() { return false; };
			this._hsimage.appendChild(this._hsimage__img);
			this.__div.appendChild(this._hsimage);
			this._hstext=document.createElement('div');
			this._hstext.ggId='hstext';
			this._hstext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._hstext.ggVisible=false;
			this._hstext.className='ggskin ggskin_text hstext';
			this._hstext.ggUpdatePosition=function() {
				this.style[domTransition]='none';
				this.style.left=(-50 + (101-this.offsetWidth)/2) + 'px';
			}
			hs ='position:absolute;';
			hs+='left: -50px;';
			hs+='top:  20px;';
			hs+='width: auto;';
			hs+='height: auto;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._hstext.setAttribute('style',hs);
			this._hstext.innerHTML=me.hotspot.title;
			this.__div.appendChild(this._hstext);
		}
	};
	this.addSkinHotspot=function(hotspot) {
		return new SkinHotspotClass(me,hotspot);
	}
	this.addSkin();
};