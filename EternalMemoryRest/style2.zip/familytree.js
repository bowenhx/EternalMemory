/**
 * familytree.js
 * www.ieternal.com
 * 2013年10月11日 任富飞 版本 v0.26
 */
(function($) {
	'use strict';// 使用严格模式的JS定义。必须放在起始位置

	// 默认选项
	var defaults = {
		// 成员,宽高
		memberWidth: 100
		,memberHeight: 40
		// 水平,垂直距离
		,horizonDistance: 36
		,horizonDistancePartner: 20
		,verticalDistance: 26
		// 整体距离顶部的margin.
		,marginLeft:80
		,marginTop:20
		// 最小宽高
		,minX:300
		,minY:240
		,debugMode : true // debug模式
		,display : "view" // 显示方式,view(只读) 和 edit(编辑)
		,onNodeClick : function(data,tree,e){} // 使用的是 [innerOptions.memberClass] DOM对象调用
		,onComplete : function(tree){} // 传入的参数是 tree
		,onAjax : function(){} // 
		,onError : function(){} // 
	};
	// 当前的全局设置,将被init方法生成，合并用户option与defaults
	// 浏览器厂商,内核
	//var vendor = '';
	// 判断是否支持触摸模式
	var isTouch = 'ontouchstart' in window;
	// 放置到 $ 对象上。
	//$.isTouch = isTouch;
	// 根据触摸模式决定事件
	var events = (isTouch) ? {click : "click touchstart", start : 'touchstart', move : 'touchmove',	end : 'touchend'} 
		: {	click : "click", start : 'mousedown', move : 'mousemove', end : 'mouseup'};
	
	// 内部选项
	var innerOptions = {
		//
		targetClass : "tree_target",
		treeClass : "tree_container",
		anchorClass : "tree_anchor",
		levelClass : "tree_level",
		nodeClass : "tree_node",
		memberClass : "tree_member",
		logoClass : "member_associate_logo",
		portraitClass : "member_portrait",
		portraitImgClass : "portrait_img",
		nameClass : "member_name",
		birthdayClass : "member_birthday",
		lineClass : "tree_line",
		hideClass : "hide",
		memIdPre : "tree_mem_",
		// 事件对象 {}
		when : null
	};
	
	
	// 线段(目标)
	function Line(context,title){
		//
		var lineTemplate = {
			title : null,
			context : null,
			x: 0,
			y: 0,
			width: 1,
			height: 1,
			dom: null
		};
		// 扩展自身
		$.extend(this,lineTemplate);
		if(title){
			this.title = title;
		}
		if(context){
			this.context = context;
		}
	};
	// 原型
	Line.prototype = {
		constructor : Line,
		init : function(force){
			// 判断是否初始化过,非强制
			if(!force && this.hasInit){
				return this;
			}
			// 初始化
			this.generateLineDOM();
			return this;
		},
		refresh : function(){
			// 刷新
			return this;
		},
		addOffset : function(x,y){
			this.x += x;
			this.y += y;
			return this;
		},
		render : function(target){
			// 渲染. 从 x,y 值取出来，设置为top,left值
			target = target || this.context.level.dom;
			
			if(!target){
				debug(this+"未能成功渲染,target="+target);
				return this;
			}
			if(this.dom){
				this.dom.css("left",this.x+"px")
				.css("top",this.y+"px")
				.css("width",this.width+"px")
				.css("height",this.height+"px")
				.removeClass(innerOptions.hideClass)
				.appendTo(target);
			}
			//
			return this;
		},
		show : function(target){
			var that = this;
			// 预防未初始化
			this.init();
			//
			this.render(target);
			// 
			return this;
		},
	 	generateLineDOM : function() {
			// 生成Line 的 dom
			var title = this.title || "unknown";
			
			////
			var $line = $("<span/>")
				.addClass(innerOptions.lineClass)
				.addClass(innerOptions.hideClass)
				.attr("title","line_"+(title))
				;
			this.dom = $line;
			return this;
		},
		toString : function(){
			return "Line[title="+ this.title +"]";
		}
	};
	
	// 树节点
	function TreeNode(data,tree,level){
		
		// family 的节点集合, node 的基本属性模板
		var nodeTemplate = {
			data : {} 		// 收到的原始成员数据,不应该修改
			,x : 0 			// 相对x坐标(相对本层中心点)
			,y : 0 			// 相对y坐标(相对本层中心点)
			,width : 0		// dom 节点的宽
			,height : 0		// dom 节点的高
			,level : null 	// 总的层级
			,id : ""		// id
			,childNode:[]	// 子节点
			,childCount : 0 	// 孩子数量?
			,partnerNode:[]	// 配偶节点
			,tree : null 	// 上下文
			,dom : null		// DOM 集合,都是jQuery对象
			,main : null	// main-DOM 集合,属于主要的显示单元
			,logo : null	// 关联标志
			,upLine : null	// 上线(DOM)
			,downLine : null	// 下线(DOM)
			,leftLine : null	// 左线(DOM)
			,partnerLine : null	// 左线,多个配偶线(DOM)
			,rightLine : null	// 右线(DOM)
			,subLevel : null	// 子level,只有level=1的元素有此对象
			,subWidth : 0	// 子level的width,只有level=1的元素有意义
		};
		// 扩展自身
		$.extend(this,nodeTemplate);
		// 原始数据
		if(data){
			this.data = data;
			this.id = this.data.memberId;
		}
		if(tree){
			this.tree = tree;
			this.width = tree.options.memberWidth;
			this.height = tree.options.memberHeight;
		}
		if(level){
			this.level = level;
		}
	};
	// MARK  树节点原型方法集合
	TreeNode.prototype = {
		constructor : TreeNode,
		init : function(force){
			// 判断是否初始化过,非强制
			if(!force && this.hasInit){
				return this;
			}
			this.hasInit = true;
			$.each(this.partnerNode,function(i,node){
				if(node){
					node.init();
				}
			});
			// 排序
			this.partnerNode.sort(function (p1,p2){return p1.data.birthDate - p2.data.birthDate});
			this.generateNodeDOM();
			
			this.generateAssociateLogo();
			//
			this.createMemberDOM();
			this.createLeftLine();
			this.createPartnerLine();
			this.createRightLine();
			this.createUpLine();
			this.createDownLine();
			// init 完毕 、设置内部的offset
			this.settingOffset();
			//
			return this;
		},
		refresh : function(){
			$.each(this.partnerNode,function(i,node){
				if(node){
					node.refresh();
				}
			});
		},
		hackSubLevel : function(){
			// TODO 232行，修正子Level
			if(this.subLevel){
				this.subLevel.tree = this.tree;
				this.subLevel.init();
				
				//
				this.createDownLine();
				
			}
			var vd = this.tree.options.verticalDistance;
			var mh = this.tree.options.memberHeight;
			var level = this.level;
			//
			var levelHeight = level.height;
			
			if(this.subLevel){
				this.subLevel.addOffset(this.x,this.y);// 自身
				this.subLevel.addOffset(0,levelHeight/2);// 本层的一半高
				//this.subLevel.addOffset(0,(vd+mh)); // 间距?
			}
		},
		addOffset : function(x,y){
			this.x += x;
			this.y += y;
			//循环处理
			// 
			$.each(this.partnerNode, function(i,partner){
				// 遍历levels,初始化
				partner.addOffset(x,y);
			});
			if(this.subLevel){
				this.subLevel.addOffset(x,y);
			}
			
			if(this.leftLine){
				//this.leftLine.addOffset(x,y);
			}
			if(this.partnerLine){
				//this.partnerLine.addOffset(x,y);
			}
			if(this.rightLine){
				//this.rightLine.addOffset(x,y);
			}
			if(this.upLine){
				//this.upLine.addOffset(x,y);
			}
			if(this.downLine){
				//this.downLine.addOffset(x,y);
			}
			return this;
		},
		addPartner : function(partner){
			var ps = this.partnerNode;
			ps.push(partner);
			//
			var options = this.tree.options;
			//var horizonDistance = options.horizonDistance;
			var horizonDistancePartner = options.horizonDistancePartner;
			var memberWidth = options.memberWidth;
			// 一个宽度 + 一个水平距离(配偶)
			var x = -1 * (memberWidth + horizonDistancePartner);
			// 第 0 个
			var y = 0; 
			partner.addOffset(x,y);
		},
		
		createLeftLine : function(){
			//
			var data = this.data;
			var partnerNode = this.partnerNode;
			if(partnerNode.length > 0){
				// 有配偶
				var options = this.tree.options;
				var verticalDistance = options.verticalDistance;
				//var horizonDistance = options.horizonDistance;
				var horizonDistancePartner = options.horizonDistancePartner;
				var memberHeight = options.memberHeight;
				var memberWidth = options.memberWidth;
				////
				var leftLine = new Line(this,"left_"+(data.name|| data.nickName));
				//
				var width = horizonDistancePartner/2
				leftLine.width = width;
				
				//
				// x = 半个成员宽 + 半个水平宽度,相对布局
				var x = -1 * width;
				// y = (高度) /-2
				var y = (memberHeight) /2;
				leftLine.addOffset(x,y);
				this.leftLine = leftLine;
			}
			
			return this;
		},
		createPartnerLine : function(){
			// 多个配偶的竖线
			var data = this.data;
			var partnerNode = this.partnerNode;
			var size = partnerNode.length;
			if(size > 1){
				// 有配偶
				var options = this.tree.options;
				var verticalDistance = options.verticalDistance;
				//var horizonDistance = options.horizonDistance;
				var horizonDistancePartner = options.horizonDistancePartner;
				var memberHeight = options.memberHeight;
				var memberWidth = options.memberWidth;
				////
				var partnerLine = new Line(this,"partner_"+(data.name|| data.nickName));
				//
				partnerLine.width = 1;
				partnerLine.height = (size - 1) * (verticalDistance + memberHeight) + 1;
				// x = 半个成员宽 + 半个水平宽度
				var x = (horizonDistancePartner) / -2;
				// y = (高度 - 间距) /-2
				//var y = (partnerLine.height - verticalDistance)/-2;
				var y = (partnerLine.height)/-2 + memberHeight/2;
				partnerLine.addOffset(x,y);
				this.partnerLine = partnerLine;
			}
			
			return this;
		},
		createRightLine : function(){
			//
			var data = this.data;
			//
			var partnerId = data.partnerId;
			if(partnerId.length > 0){
				// 是别人的配偶
				var options = this.tree.options;
				//var horizonDistance = options.horizonDistance;
				var horizonDistancePartner = options.horizonDistancePartner;
				var memberWidth = options.memberWidth;
				var memberHeight = options.memberHeight;
				////
				var rightLine = new Line(this,"right_"+(data.name|| data.nickName));
				//
				rightLine.width = horizonDistancePartner/2;
				var x = memberWidth;// 自己的宽度
				var y = memberHeight/2; // 半个成员高度
				rightLine.addOffset(x,y);
				this.rightLine = rightLine;
			}
			
			return this;
		},
		createUpLine : function(){
			//
			var data = this.data;
			//
			var parentId = data.parentId;
			if(parentId.length > 0){
				// 是别人的孩子
				var levelHeight = this.level.height;
				var options = this.tree.options;
				var memberHeight = options.memberHeight;
				var memberWidth = options.memberWidth;
				// 上线高度 = (层高-元素高度)/2,取整数
				var height = (levelHeight - memberHeight)/2;
				height= parseInt(height);
				////
				var upLine = new Line(this,"up_"+(data.name|| data.nickName));
				//
				upLine.height = height;
				//
				var x = memberWidth/2; // 半个成员宽度
				var y = -1 * height;
				upLine.addOffset(x,y);
				this.upLine = upLine;
			}
			
			return this;
		},
		createDownLine : function(){
			//
			var hasDownLine = false;
			//
			var data = this.data;
			// 主线成员
			var directLine = data.directLine;
			var lev = data.level;
			
			// 如果没有有下一层,则屏蔽
			var nextLev = lev + 1;
			var nextLevel = this.tree.getLevel(nextLev);
			if(!nextLevel && lev != 1){ // 不是level=1层
				return this;
			}
			
			if(1 == directLine && lev < 1){
				// 0层以上主线成员，有下一层
				hasDownLine = true;
			} else if(false && directLine  && lev == 1){
				var hasChild = false;
				var currentid = data.memberId;
				// 画下线还需要判断,是别人的父亲,遍历
				var ndata = nextLevel.data;
				if(ndata){
					$.each(ndata, function(i,cdata){
						//
						var cparentId = cdata.parentId;
						if(currentid == cparentId){
							hasChild = true;
							return false;
						}
					});
				}
				//
				if(hasChild){
					hasDownLine = true;
				}
			} else if(lev == 1){
				//
				if(this.subLevel){
					hasDownLine = true;
				}
			} else if((this == this.level.center ) &&(lev != 1)){
				hasDownLine = true;
			}
			
			// 创建
			if(true === hasDownLine){
				// 是主线成员，并且不是最底上的一层
				var levelHeight = this.level.height;
				var options = this.tree.options;
				var memberHeight = options.memberHeight;
				var memberWidth = options.memberWidth;
				// 下线高度 = (层高-元素高度)/2,取整数
				var height = (levelHeight - memberHeight)/2;
				var downLine = new Line(this,"down_"+(data.name || data.nickName));
				//
				downLine.height = height;
				//
				var x = memberWidth/2;
				var y = memberHeight;
				downLine.addOffset(x,y);
				this.downLine = downLine;
			}
			
			return this;
		},
		
		settingOffset : function(){
			// 设置自己层内部offset
			
			var vd = this.tree.options.verticalDistance;
			var mh = this.tree.options.memberHeight;
			// 复制 配偶
			var allPartner = this.partnerNode.slice(0);
			var size = allPartner.length;
			if(size > 1){
				// 逆序
				allPartner.sort(function (p1,p2){return p2.data.birthDate - p1.data.birthDate});
				// 是否是奇数
				var isOdd = size % 2;
				// 遍历
				$.each(allPartner, function(i,partner){
					
					var y = 0;
					var sym = 1;
					
					if(0 == (i % 2)){
						sym = -1;
					}
					
					if(isOdd){
						// 第一个不动，余下的依次上移+1,下移+1
						// i = 1不动, i=2,4,6 往下移动,3,5,往上移动
						//
						if(0 == i){
							y += 0;
						} else {
							var index = i+1; // 实际的数字
							//y += sym * ((i/2) -2 +1) * (vd + mh) + 5000;
							var curOdd = index % 2;
							if(0 == curOdd){
								sym = 1;
							} else {
								sym = -1;
							}
							//
							var offset = (index - curOdd)/2;
							y += sym * (offset) * (vd + mh) ;
						}
						
					} else {
						// 偶数个,第一个上移 0.5 ,第二个下移,余下的+1
						var curOdd = i %2;
						var num =  (i - curOdd) / 2;
						y += sym * (num + 0.5)*(vd + mh);
					}
					//
					partner.addOffset(0,y);
				});
			}
			//
			return this;
		},
		render : function(target){
			// 渲染. 从 x,y 值取出来，设置为top,left值
			target = target || this.level.dom;
			
			if(!target){
				debug(this+"未能成功渲染,target="+target);
				return this;
			}
			if(this.dom){
				var left = this.x - (this.width/2);
				var top = this.y - (this.height/2);
				this.dom.css("left",left+"px")
				.css("top",top+"px")
				.removeClass(innerOptions.hideClass)
				.appendTo(target);
				//
				if(this.main){
					this.main
					.removeClass(innerOptions.hideClass)
					.appendTo(this.dom);
				}
				if(this.logo){
					this.logo
					.removeClass(innerOptions.hideClass)
					.appendTo(this.dom);
				}
			}
			//
			return this;
		},
		show : function(target){
			var that = this;
			// 预防未初始化
			this.init();
			//
			this.render(target);
			
			if(this.subLevel){
				this.subLevel.show(this.tree.dom);
			}
			if(this.leftLine){
				this.leftLine.show(this.dom);
			}
			if(this.partnerLine){
				this.partnerLine.show(this.dom);
			}
			if(this.rightLine){
				this.rightLine.show(this.dom);
			}
			if(this.upLine){
				this.upLine.show(this.dom);
			}
			if(this.downLine){
				this.downLine.show(this.dom);
			}
			$.each(this.partnerNode, function(i,partner){
				// 遍历partner,显示
				partner.show(target);
			});
			// 
			return this;
		},
	 	generateNodeDOM : function() {
			// 生成Node容器
			var data = this.data;
			var nodeClass = innerOptions.nodeClass;
			var nodeId = innerOptions.memIdPre + "node_" + data.memberId;
			////
			var $dom = $("<div/>")
				.attr("id", nodeId)
				.addClass(nodeClass)
				;
			this.dom = $dom;
			return this;
		},
	 	generateAssociateLogo : function() {
			// 生成标识
			var data = this.data;
			var associated = data.associated;
			var userId = data.userId;
			var memberId = data.memberId;
			if(userId == memberId){
				// 不显示
			} else if(1 == associated){
				var logoClass = innerOptions.logoClass;
				////
				var $logo = $("<div/>")
					.addClass(logoClass)
					;
				this.logo = $logo;
			}
			return this;
		},
		createMemberDOM : function(){
			// 生成 Member 部分
			//
			var data = this.data;
			var memClass = innerOptions.memberClass;
			var nameClass = innerOptions.nameClass;
			var birthdayClass = innerOptions.birthdayClass;
			var portraitClass = innerOptions.portraitClass;
			var portraitImgClass = innerOptions.portraitImgClass;
			var memId = innerOptions.memIdPre + "" + data.memberId;
			var memName = data.name|| data.nickName || "?";
			var birthday = date2String(data.birthDate) || "0000-00-00";
			if(data.birthDateStr!=undefined && data.birthDateStr!=null && data.birthDateStr!="" && data.birthDateStr!="null"){
				birthday = data.birthDateStr;
			}
			var srcImg = data.headPortrait || "";
			var sex = data["sex"];
			var memColorClass = "tree_member_unknown";
			var memAssociatedClass = "";
			if (data.userId && (data.userId == data.memberId)) {
				memColorClass = ("tree_member_me");
			} else if (1 == sex) {
				memColorClass = ("tree_member_male");
			} else if (2 == sex) {
				memColorClass = ("tree_member_female");
			} else {
				//
			}
			if(1 == data.associated){
				memAssociatedClass = ("tree_member_associated");
			}
			//// member
			var $member = $("<div/>")
				.attr("id", memId)
				.addClass(memClass)
				.addClass(memAssociatedClass)
				.addClass(memColorClass);
			// 生成name
			var $name = $("<span/>")
				.addClass(nameClass)
				.text(memName)
				.appendTo($member);
			// 生成肖像
			var $portrait = $("<span/>")
				.addClass(portraitClass)
				.appendTo($member);
			// 图片
			if(srcImg){
				var $img = $("<img/>")
					.addClass(portraitImgClass)
					.attr("src",srcImg) // TODO 
					.appendTo($portrait);
			}
			// 生成birthday
			var $birthday = $("<span/>")
				.addClass(birthdayClass)
				.text(birthday)
				.appendTo($member);
			
			this.main = $member;
			return this;
		},
		getId : function(){
			var id = this.id || "unknow id";
			return id;
		},
		getWidth : function(){ // 获取自身(+内部)的宽度
			//
			return this.getLeftWidth() + this.getRightWidth();
		},
		getLeftWidth : function(){ // 获取自身左侧的宽度
			var leftWidth = 0;
			
			var that = this;
			var options = that.tree.options ;
			var vd = options.verticalDistance;
			var vh = options.memberHeight;
			// 
			var hd = options.horizonDistance;
			var hdp = options.horizonDistancePartner;
			var hw = options.memberWidth;
			leftWidth += hw/2; // 自身的半个成员宽
			
			
			var p = that.partnerNode;
			// 有配偶
			if(p && p.length > 0){
				leftWidth += hdp; // 配偶间距
				leftWidth += hw;  // 配偶的宽度
			}
			
			var level = that.level.level;
			// 如果不是level1，那么，就直接是leftWidth
			if(1 != level){
				return leftWidth;
			} else {
				// Level 1 分几种情况
				var nLeftWidth = 0;
				if(that.subLevel){
					//nLeftWidth = that.subLevel.leftWidth;
					nLeftWidth = that.subLevel.getLevelLeftWidth();
					if(nLeftWidth < leftWidth){
						nLeftWidth = leftWidth;
					}
				} else {
					nLeftWidth = leftWidth;
				}
				//
				return nLeftWidth;
			}
		},
		getRightWidth : function(){// 获取自身右侧的宽度
			//
			var rightWidth = 0;
			
			var that = this;
			var options = that.tree.options ;
			var vd = options.verticalDistance;
			var vh = options.memberHeight;
			// 
			var hd = options.horizonDistance;
			var hdp = options.horizonDistancePartner;
			var hw = options.memberWidth;
			rightWidth += hw/2; // 自身的半个成员宽
			
			// 有没有配偶，右边的无所谓
			
			var level = that.level.level;
			// 如果不是level1，那么，就直接是rightWidth
			if(1 != level){
				return rightWidth;
			} else {
				// Level 1 分几种情况
				var nRightWidth = 0;
				if(that.subLevel){
					//nRightWidth = that.subLevel.rightWidth;
					nRightWidth = that.subLevel.getLevelRightWidth();
					if(nRightWidth < rightWidth){
						nRightWidth = rightWidth;
					}
				} else {
					nRightWidth = rightWidth;
				}
				//
				return nRightWidth;
			}
		},
		getHeight : function(){// 获取自身的高度
			//
			//
			var height = 0;
			
			var that = this;
			var options = that.tree.options ;
			var vd = options.verticalDistance;
			var vh = options.memberHeight;
			// 
			var hd = options.horizonDistance;
			var hdp = options.horizonDistancePartner;
			var hw = options.memberWidth;
			
			
			var p = that.partnerNode;
			// 有配偶
			if(p && p.length > 0){
				// 配偶个数+ (个数-1)间距 
				height += (p.length)*vh; // 配偶个数
				height += (p.length -1 )*vd; // 间距
			} else {
				height += vh; // 自身的高
			}
			//
			return height;
		},
		toString : function(){
			
			return "TreeNode[id="+ this.getId() +"]";
		}
	};
	
	
	// 树的层级
	function TreeLevel(index,tree,data,parentNode){
		// family 的level集合, 逻辑上的level 的基本属性模板
		var levelTemplate = {
			data : [],		// 原始数据
			x : 0, 			// 相对x坐标(相对中心点)
			y : 0, 			// 相对y坐标(相对中心点)
			leftWidth : 0,  // 左宽
			rightWidth : 0, // 右宽
			width : 0, 		// 宽(画上边线)
			height : 0, 	// 高(本层占位)
			upLineLeftWidth : 0, 	// 上划线,左侧的宽度
			upLineRightWidth : 0, 	// 上划线,右侧的宽度
			level : 0, 		// 第n层
			members:[],		// 子节点
			maxPartner:0,	// 本层最多的配偶数量
			center: null,	// 本层中心节点
			maleCount:0,	// 男性数量
			maleHasPartnerCount:0,	// 男性有配偶的数量
			femaleCount:0,	// 女性数量
			femaleHasPartnerCount:0,	// 女性有配偶的数量
			tree: null,		// tree 对象
			dom : null,		// DOM(一个容器$(div))
			upLine : null	// 上线(DOM)
			,parentNode:null// 父节点,如果有...
		};
		// 扩展自身
		$.extend(this,levelTemplate);
		this.level = index;
		this.tree = tree;
		this.parentNode = parentNode;
		// 扩展数据
		if(data){
			$.extend(this.data,data);
		}
	};
	// MARK 树层级 的 proto方法集合
	TreeLevel.prototype = {
		constructor : TreeLevel,
		init : function(force){
			// 判断是否初始化过,非强制
			if(!force && this.hasInit){
				return this;
			}
			//debug(this+".init()");
			this.hasInit = true;
			// 生成成员对象
			this.generateMembers();
			// 计算关系
			this.calculateRelation();
			// 遍历
			$.each(this.members,function(i,member){
				if(member){
					//
					member.init();
				}
			});
			this.generateLevelDOM();
			this.generateUpLine();
			// 初始化完成以后.计算并设置offset
			this.settingOffset();
			//
			return this;
		},
		isLevelAt : function(index){
			if(this.level == index){
				return true;
			} else {
				return false;
			}
		},
		addData : function (data){
			// 添加数据
			if(!this.data){
				this.data = [];
			}
			this.data.push(data);
			return this;
		},
		generateMembers : function(){
			var that = this;
			var datas = that.data;
			// 临时成员
			var tempMembers = [];
			$.each(datas,function(i,mdata){
				//
				if(mdata){
					var member = new TreeNode(mdata,that.tree,that);
					//that.addMember(member);
					tempMembers.push(member);
				} else {
					debug(this+".generateMembers() : index="+i + ",mdata="+mdata);
				}
			});
			// 分拣members
			this.pickMembers(tempMembers);
		},
		addMember : function(member) {
			if(!member){
				return this;
			}
			if(!this.members){
				this.members = [];
			}
			//
			this.members.push(member);
			return this;
		},
		pickMembers : function(tempMembers){
			if(!tempMembers){
				return this;
			}
			// 整理,分拣members数据
			var that = this;
			var partners = [];
			// 遍历 ,分拣
			$.each(tempMembers,function(i,member){
				if(!member){
					return;
				}
				// 根据是否主成员分拣到两个子数组
				var mdata = member.data;
				if(!mdata){
					return;
				}
				var partnerId = mdata.partnerId;
				if(partnerId && partnerId.length > 1){
					partners.push(member);
				} else {
					// 添加主成员
					that.addMember(member);
				}
			});
			// 设定成员
			// 组合 partner
			// 遍历 ,分拣
			$.each(partners,function(i,partner){
				if(!partner){ return; }
				// 根据是否主成员分拣到两个子数组
				var pdata = partner.data;
				if(!pdata){
					return;
				}
				var partnerId = pdata.partnerId;
				if(partnerId && partnerId.length > 1){
					// 找出
					var mem = that.getMemberById(partnerId);
					if(mem){
						mem.addPartner(partner);
					} else {
						debug(partner+"未找到配偶,脏数据,丢弃!!!");
					}
				} else {
					debug("程序异常:partnerId="+partnerId);
				}
			});
			
			return this;
		},
		getMemberById : function(id){
			if(!id || ("string" !== typeof id) || !this.members){
				return null;
			}
			var result = null;
			// 遍历 主成员
			$.each(this.members, function(i,member){
				if(!member){
					return;
				}
				if(member.getId() == id){
					// 找到需要的元素
					result = member;
					return false;
				}
			});
			return result;
		},
		calculateRelation : function(){
			// 计算互相之间的关系
			
			// 1. 计算中心点
			// 2. 计算男性个数
			// 3. 计算女性个数
			// 4. 计算本层最大的配偶数量
			// 5. 计算逻辑高度
			// 6. 计算逻辑宽度
			// 7. 计算x偏移
			var that = this;
			var members = that.members;
			var level = that.level;
			//
			var level2tempCenter = null;
			$.each(members, function(i,member){
				if(!member){
					return;
				}
				var partnerNode = member.partnerNode || {length: 0};
				var pcount = partnerNode.length;
				var isCenter = false;
				var data = member.data || {};
				var sex = data.sex;
				var directLine = data.directLine;
				var memberId = data.memberId;
				var userId = data.userId;
				//  计算中心点
				if(0 === level){
					// 0 层。中心点就是树的中心点
					if(memberId == userId){
						isCenter = true;
					}
				} else if(level < 0){
					// 小于0的,前代，主线关系
					if(1 == directLine){
						isCenter = true;
					} else {
						//debug("level="+level+",directLine="+directLine);
					}
				} else if(level > 0){
					// 大于0的，后代,主线关系
					if(1 == directLine){
						isCenter = true;
					} else {
						//debug("level="+level+",directLine="+directLine);
					}
				} else {
					debug(this+".calculateRelation():数据错误.level="+level);
				}
				
				// 中心点
				if(isCenter){
					that.center = member;
					member.isCenter = isCenter;
				}
				// 计算男性女性个数
				if(2 == sex){
					that.femaleCount += 1;
					if(pcount > 0){
						// 女性,有配偶的数量
						that.femaleHasPartnerCount += 1;
					}
				} else {
					that.maleCount += 1;
					if(pcount > 0){
						that.maleHasPartnerCount += 1;
					}
					level2tempCenter = member;
				}
				// 本层最大配偶个数
				if(pcount > that.maxPartner){
					that.maxPartner = pcount;
				}
			});
			
			// level2 hack,修正没有中心点的BUG
			if(!that.center && that.level == 2){
				that.center = level2tempCenter;
			}
			if(!that.center){
				that.center = level2tempCenter;
			}
			
			// 计算逻辑高度
			var height = 0;
			var mpc = that.maxPartner;
			if(mpc < 1){
				mpc = 1;
			}
			// TODO 计算高度
			var options = that.tree.options ;
			var vd = options.verticalDistance;
			var vh = options.memberHeight;
			// 加上固定个数元素的高度
			height += mpc * vh;
			// 间距
			height += (mpc+1) * vd;
			that.height = height;
			
			// TODO 计算宽度
			var hd = options.horizonDistance;
			var hdp = options.horizonDistancePartner;
			var hw = options.memberWidth;
			var mc = that.femaleCount + that.maleCount;
			
			var leftWidth = 0;
			var rightWidth = 0;
			var width = 0;
			
			var leftMemCount = that.femaleCount; // 左侧成员数量 = 女性数量 +-中心点
			var rightMemCount = that.maleCount;   // 右侧成员数量 = 男性数量 +-中心点
			var leftPc = that.femaleHasPartnerCount;   // 左侧的配偶数量 = 女性有配偶  - 中心点
			var rightPc = that.maleHasPartnerCount;   // 右侧配偶数量 = 男性 - 中心点
			
			var center = that.center;
			var centerSex  = 0;
			var centerhasPartner  = 0; // 中心点有配偶?
			if(center){
				centerSex = center.data.sex;
				centerhasPartner = !!center.partnerNode.length;
			}
			if(2 == centerSex){
				// 女性,则左边宽度减少,右边不动,左侧有配偶数量+-中心点
				leftMemCount -= 1;
				if(centerhasPartner){
					leftPc -= 1;
				}
			}else if(1 == centerSex){
				//男性,则左边成员数量不变,右侧减一,右侧有配偶数量+-中心点
				rightMemCount -= 1;
				if(centerhasPartner){
					rightPc -= 1;
				}
			} else {
				// 中心点没有成员
			}
			if(centerhasPartner){
				// 左侧需要加上一个配偶宽度 = (中心点)配偶成员宽 + 配偶间距
				leftWidth += 1 * hw + 1 * hdp;
			}
			// 左侧+= 中心点
			leftWidth += 1 * hw + 2 * hd;
			//leftWidth += 1/2 * hw;// + 1 * hd;
			//rightWidth += 1 * hd;
			
			leftWidth += 1*leftMemCount * (hw + hdp) ; // 每个左侧成员 = 1成员宽度+1个间距
			leftWidth += (leftMemCount-1) * (hw+hdp) ; // 左侧每个配偶 = 1个配偶宽度+1配偶间距 - 最左侧成员是否有配偶 // 
			
			rightWidth += 1*rightMemCount * hw ; // 每个右侧成员 = 1成员宽度+1个间距
			rightWidth += 2*(rightMemCount-1) * (hd+hdp) ;// 右侧每个配偶 = 1个配偶宽度+1配偶间距 - 最右侧成员是否有配偶 
			
			width += leftWidth + rightWidth ; //
			//width +=  (that.femaleCount + that.maleCount -1 )* (hw + hd) + hw// 宽度 += 成员.. =  n * 成员宽 + + (n-1)* 间距
			//width +=  (that.femaleHasPartnerCount + that.maleHasPartnerCount)* (hw + hdp)// 宽度  += 配偶。。 +  m*配偶宽 + m*配偶间距
			
			that.width = width;
			that.leftWidth = leftWidth;
			that.rightWidth = rightWidth;
			return this;
		},
		settingOffsetLevel1 : function(){
			var level = this.level;
			if(1 != level){
				return this;	// 打补丁
			}
			var hasSettingOffsetLevel1 = this.hasSettingOffsetLevel1;
			if(hasSettingOffsetLevel1){
				return this;
			}
			this.hasSettingOffsetLevel1 = true;
			//
			var that = this;
			//
			var options = that.tree.options ;
			var vd = options.verticalDistance;
			var vh = options.memberHeight;
			var hd = options.horizonDistance;
			var hdp = options.horizonDistancePartner;
			var hw = options.memberWidth;
			
			var centerNode = that.center;
			if(!centerNode){
				debug(this+",center="+that.center);
				//return this;
			}
			
			var males = [];
			var females = [];
			//遍历成员,筛检
			$.each(this.members, function(i,member){
				// 中心点不进入计算
				if(centerNode == member){
					return;
				}
				//
				var sex = member.data.sex;
				if(2 == sex){// 女
					females.push(member);
				} else {
					males.push(member);
				}
			});
			
			// 左侧成员偏移量,像素
			var leftMemberOffset= 0;
			var rightMemberOffset= 0;
			var levelHeight= 2 * vd;
			
			// 先计算中心点的偏移,中心点,不需要偏移
			if(centerNode){
				//
				leftMemberOffset += centerNode.getLeftWidth();
				rightMemberOffset += centerNode.getRightWidth();
				// 节点高,加上 上下间距
				var tempHeight = centerNode.getHeight();
				tempHeight += 2 * vd;
				if(levelHeight < tempHeight){
					levelHeight = tempHeight;
				}
			} else {
				// 添加 默认的距离
				// 严格来说,应该 +0, 然后下一个自己加间距,但是为了与上面得出的getLeftWidth保持兼容
				leftMemberOffset += hw / 2;
				rightMemberOffset += hw / 2;
			}
			
			// 男性
			$.each(males, function(i,member){
				if(!member){return;}
				// 男性,右侧加上一个间距
				rightMemberOffset += hd;
				// 加上自己的左宽
				rightMemberOffset += member.getLeftWidth();
				
				// 设置上线的右宽
				that.upLineRightWidth = rightMemberOffset;
				// 设置当前元素的偏移
				member.addOffset(rightMemberOffset,0);
				
				// 如果有下一个,则会使用到自己的右宽
				rightMemberOffset += member.getRightWidth();
				
				// 节点高,加上 上下间距
				var tempHeight = member.getHeight();
				tempHeight += 2 * vd;
				if(levelHeight < tempHeight){
					levelHeight = tempHeight;
				}
			});
			// 女性
			$.each(females, function(i,member){
				if(!member){return;}
				// 女性,右侧加上一个间距
				leftMemberOffset += hd;
				// 加上自己的右宽
				leftMemberOffset += member.getRightWidth();
				
				// 设置上线的右宽
				that.upLineLeftWidth = leftMemberOffset;
				// 设置当前元素的偏移
				member.addOffset(-1 * leftMemberOffset,0);
				
				// 如果有下一个,则会使用到自己的右宽
				leftMemberOffset += member.getLeftWidth();
				
				// 节点高,加上 上下间距
				var tempHeight = member.getHeight();
				tempHeight += 2 * vd;
				if(levelHeight < tempHeight){
					levelHeight = tempHeight;
				}
			});
			that.height = levelHeight;
			that.leftWidth = leftMemberOffset;
			that.rightWidth = rightMemberOffset;
			that.width = leftMemberOffset + rightMemberOffset;
			// level上线
			if(that.upLine){
				// 左移,上移
				//this.upLine.width = (size - 1) * 2*(hd + hw);
				that.upLine.width = that.upLineLeftWidth + that.upLineRightWidth;
				var ux = -1 * that.upLineLeftWidth;
				var uy = (that.height/-2);
				// TODO 偏移需要计算
				that.upLine.addOffset(ux,uy);
			}
			
			// 统一的加上半个层高
			this.addOffset(0,(that.height/2));
			//
			return this;
			
		},
		settingOffset : function(){
			// 设置自己层内部offset
			var that = this;
			
			var level = this.level;
			if(1 == level){
				return this;	// 打补丁
			}
			//
			var options = that.tree.options ;
			var hd = options.horizonDistance;
			var hdp = options.horizonDistancePartner;
			var hw = options.memberWidth;
			var size = that.members.length;
			var centerSex = 0;
			var centerHasPartner = 0;
			
			
			var centerNode = that.center;
			if(!centerNode){
				debug(this+",center="+that.center);
				//return this;
			} else {
				centerSex = centerNode.data.sex;
				centerHasPartner = centerNode.partnerNode.length;
			}
			
			var males = [];
			var females = [];
			//遍历成员,筛检
			$.each(this.members, function(i,member){
				//
				var sex = member.data.sex;
				if(2 == sex){// 女
					females.push(member);
				} else {
					males.push(member);
				}
			});
			
			if(2 != centerSex){
				// 左侧的配偶偏移
				var leftPartnerOffset= 0;
				var rightPartnerOffset= 0;
				// 男性
				var mi = 0;// male index
				$.each(males, function(i,member){
					if(!member){return;}
					//// 中心点,不需要偏移
					if(member == centerNode){
						// 中心点,有配偶
						if(member.partnerNode.length > 0){
							leftPartnerOffset += 1;	// 必须先遍历男性，再遍历女性
						}
						return;
					}
					// 
					var x = 0;
					var y = 0;
					if(2 == centerSex){
						// 女性在中心点
						// // 有配偶。
						var hasPartner = member.partnerNode.length;
						// 
						// 遍历计算level上线 的右宽度;男性，右侧的 = 配偶的加上自身的
						that.upLineRightWidth += (hd + hw); // 一个元素偏移
						if(hasPartner > 0){
							rightPartnerOffset += 1;
							//  男性,有则加上配偶的偏移
							that.upLineRightWidth += (hdp + hw);
						}
						// 偏移 = 配偶数量 * (宽度 + 配偶距离)
						x += 1 * rightPartnerOffset * (hdp + hw);
						// 已遍历成员数量 + 自身
						x += 1 * (1+mi) * (hd + hw);
					} else {
						
						// // 有配偶。
						var hasPartner = member.partnerNode.length;
						// 
						// 遍历计算level上线 的右宽度;男性，右侧的 = 配偶的加上自身的
						that.upLineRightWidth += (hd + hw); // 一个元素偏移
						if(hasPartner > 0){
							rightPartnerOffset += 1;
							//  男性,有则加上配偶的偏移
							that.upLineRightWidth += (hdp + hw);
						}
						// 偏移 = 配偶数量 * (宽度 + 配偶距离)
						x += 1 * rightPartnerOffset * (hdp + hw);
						// 已遍历成员数量 + 自身
						x += 1 * (1+mi) * (hd + hw);
					}
					//
					member.addOffset(x,y);
					mi ++;
				});
				// 女性
				var fi = 0; // female index
				$.each(females, function(i,member){
					if(!member){return;}
					//// 中心点,不需要偏移
					if(member == centerNode){
						return;
					}
					// 
					var x = 0;
					var y = 0;
					if(2 == centerSex){
						// 女性在中心点
					} else {
						// 偏移 = 配偶数量 * (宽度 + 配偶距离)
						x += -1 * leftPartnerOffset * (hdp + hw);
						// 已遍历成员数量 + 自身
						x += -1 * (1+fi) * (hd + hw);
						//
						
						// // 有配偶。
						var hasPartner = member.partnerNode.length;
						
						// 遍历计算level上线 的右宽度;女性，左侧的 = 先加上自身的一个元素偏移
						that.upLineLeftWidth += (hd + hw); 
						// 
						if(hasPartner > 0){
							leftPartnerOffset += 1;	// 有配偶。
							//  女性,不是最后一个元素,则加上配偶的偏移
							if(females.length - 1 != i){
								// 设置线条的
								that.upLineLeftWidth += (hdp + hw);
							}
						}
					}
					//
					member.addOffset(x,y);
					fi ++;
				});
				
				//
				if(centerHasPartner && females.length > 0){
					// 加上一个(中心点)配偶的宽度
					that.upLineLeftWidth += (hdp + hw);
				}
			} else {
				// 女性在中心点
				
				// 左侧的配偶偏移
				var leftPartnerOffset= 0;
				var rightPartnerOffset= 0;
				
				// 男性
				var mi = 0;// male index
				$.each(males, function(i,member){
					if(!member){return;}
					//// 中心点,不需要偏移
					if(member == centerNode){
						// 中心点,有配偶
						if(member.partnerNode.length > 0){
							leftPartnerOffset += 1;	// 必须先遍历男性，再遍历女性
						}
						return;
					}
					// 
					var x = 0;
					var y = 0;
					if(2 == centerSex){
						// 女性在中心点
						// // 有配偶。
						var hasPartner = member.partnerNode.length;
						// 
						// 遍历计算level上线 的右宽度;男性，右侧的 = 配偶的加上自身的
						that.upLineRightWidth += (hd + hw); // 一个元素偏移
						if(hasPartner > 0){
							rightPartnerOffset += 1;
							//  男性,有则加上配偶的偏移
							that.upLineRightWidth += (hdp + hw);
						}
						// 偏移 = 配偶数量 * (宽度 + 配偶距离)
						x += 1 * rightPartnerOffset * (hdp + hw);
						// 已遍历成员数量 + 自身
						x += 1 * (1+mi) * (hd + hw);
					} else {
						
						// // 有配偶。
						var hasPartner = member.partnerNode.length;
						// 
						// 遍历计算level上线 的右宽度;男性，右侧的 = 配偶的加上自身的
						that.upLineRightWidth += (hd + hw); // 一个元素偏移
						if(hasPartner > 0){
							rightPartnerOffset += 1;
							//  男性,有则加上配偶的偏移
							that.upLineRightWidth += (hdp + hw);
						}
						// 偏移 = 配偶数量 * (宽度 + 配偶距离)
						x += 1 * rightPartnerOffset * (hdp + hw);
						// 已遍历成员数量 + 自身
						x += 1 * (1+mi) * (hd + hw);
					}
					//
					member.addOffset(x,y);
					mi ++;
				});
				
				// 女性
				var fi = 0; // female index
				$.each(females, function(i,member){
					if(!member){return;}
					//// 中心点,不需要偏移
					if(member == centerNode){
						// 中心点,有配偶
						if(member.partnerNode.length > 0){
							leftPartnerOffset += 1;	// 必须先遍历男性，再遍历女性
						}
						return;
					}
					// 
					var x = 0;
					var y = 0;
					if(2 == centerSex){
						// 偏移 = 配偶数量 * (宽度 + 配偶距离)
						x += -1 * leftPartnerOffset * (hdp + hw);
						// 已遍历成员数量 + 自身
						x += -1 * (1+fi) * (hd + hw);
						//
						
						// // 有配偶。
						var hasPartner = member.partnerNode.length;
						
						// 遍历计算level上线 的右宽度;女性，左侧的 = 先加上自身的一个元素偏移
						that.upLineLeftWidth += (hd + hw); 
						// 
						if(hasPartner > 0){
							leftPartnerOffset += 1;	// 有配偶。
							//  女性,不是最后一个元素,则加上配偶的偏移
							if(females.length - 1 != i){
								// 设置线条的
								that.upLineLeftWidth += (hdp + hw);
							}
						}
					}
					//
					member.addOffset(x,y);
					fi ++;
				});
				// 女性的时候,>1是才增加
				if(centerHasPartner && females.length > 1){
					// 加上一个(中心点)配偶的宽度
					that.upLineLeftWidth += (hdp + hw);
				}
			}
			// level上线
			if(that.upLine){
				// 左移,上移
				//this.upLine.width = (size - 1) * 2*(hd + hw);
				that.upLine.width = that.upLineLeftWidth + that.upLineRightWidth;
				var ux = -1 * that.upLineLeftWidth;
				var uy = (that.height/-2);
				// TODO 偏移需要计算
				this.upLine.addOffset(ux,uy);
			}
			
			// 统一的加上半个层高
			this.addOffset(0,(this.height/2));
			//
			return this;
		},
		refresh : function(){
			//循环处理

			if(this.upLine){
				this.upLine.refresh();
			}
			// 
			$.each(this.members, function(i,member){
				// 遍历levels,初始化
				member.refresh();
			});
			// 刷新
			return this;
		},
		addOffset : function(x,y){
			this.x += x;
			this.y += y;
			//循环处理

			if(this.upLine){
				this.upLine.addOffset(x,y);
			}
			// 
			$.each(this.members, function(i,member){
				// 遍历levels,初始化
				member.addOffset(x,y);
			});
			return this;
		},
		render : function(target){
			// 渲染
			target = target || this.target;
			if(!target){
				debug(this+"未能成功渲染,target="+target);
				return this;
			}
			
			this.dom.appendTo(target)
			.removeClass(innerOptions.hideClass);
			return this;
		},
		show : function(target){
			var that = this;
			// 预防未初始化
			this.init();
			// 设置Level1 的
			this.settingOffsetLevel1();	// 打补丁
			
			//
			this.render(target);
			if(this.upLine){
				this.upLine.show(that.dom);
			}
			// 
			$.each(this.members, function(i,member){
				// 遍历levels,初始化
				member.show(that.dom);
			});
			// 
			return this;
		},
	 	generateLevelDOM : function() {
	 		var pid = "";
	 		if(this.parentNode){
	 			var pid = "_"+this.parentNode.id;
	 		}
			// 生成Level容器
			var $level = $("<div />")
				.attr("id","level_"+this.level + pid)
				.addClass(innerOptions.levelClass)
				.addClass(innerOptions.hideClass);
			this.dom = $level;
			return this;
		},
	 	generateUpLine : function() {
			// TODO 上方的线,需要根据元素个数，中心点性别等来决定长度,偏移
			var that = this;
			var data = that.data;
			var hasCenter = false;
			var memberCount = 0;
			$.each(data,function(i,d){
				if(!d){
					return;
				}
				//
				if(1 == d.directLine){
					hasCenter = true;
					//
				}
				if(1 == d.kinRelation){
					memberCount += 1;
				}
			});
			if((1 == memberCount) && hasCenter){
				// 有中心点，主成员只有1个
				return this;
			} else {
				var upLine = new Line(this,"level_"+ this.level);
				this.upLine = upLine;
			}
			return this;
		},
		getLevelLeftWidth : function(){// 获取Level自身左侧的宽度
			var leftWidth = 0;
			var rightWidth = 0;
			//
			var that = this;
			//
			var options = that.tree.options ;
			var vd = options.verticalDistance;
			var vh = options.memberHeight;
			var hd = options.horizonDistance;
			var hdp = options.horizonDistancePartner;
			var hw = options.memberWidth;
			
			var centerNode = that.center;
			var males = [];
			var females = [];
			//遍历成员,筛检
			$.each(this.members, function(i,member){
				// 中心点不进入计算
				if(centerNode == member){
					return;
				}
				//
				var sex = member.data.sex;
				if(2 == sex){// 女
					females.push(member);
				} else {
					males.push(member);
				}
			});
			
			// 先计算中心点的偏移,中心点,不需要偏移
			if(centerNode){
				//
				leftWidth += centerNode.getLeftWidth();
				rightWidth += centerNode.getRightWidth();
			} else {
				// 添加 默认的距离
				leftWidth += hw / 2;
				rightWidth += hw / 2;
			}
			
			// 男性
			$.each(males, function(i,member){
				if(!member){return;}
				// 男性,加上一个间距
				rightWidth += hd;
				// 加上自己的左宽
				rightWidth += member.getLeftWidth();
				// 自己的右宽
				rightWidth += member.getRightWidth();
			});
			// 女性
			$.each(females, function(i,member){
				if(!member){return;}
				// 女性,加上一个间距
				leftWidth += hd;
				// 加上自己的右宽
				leftWidth += member.getRightWidth();
				// 自己的左宽
				leftWidth += member.getLeftWidth();
			});
			//
			return leftWidth;
		},
		getLevelRightWidth : function(){ // 获取Level自身右侧的宽度
			var leftWidth = 0;
			var rightWidth = 0;
			//
			var that = this;
			//
			var options = that.tree.options ;
			var vd = options.verticalDistance;
			var vh = options.memberHeight;
			var hd = options.horizonDistance;
			var hdp = options.horizonDistancePartner;
			var hw = options.memberWidth;
			
			var centerNode = that.center;
			var males = [];
			var females = [];
			//遍历成员,筛检
			$.each(this.members, function(i,member){
				// 中心点不进入计算
				if(centerNode == member){
					return;
				}
				//
				var sex = member.data.sex;
				if(2 == sex){// 女
					females.push(member);
				} else {
					males.push(member);
				}
			});
			
			// 先计算中心点的偏移,中心点,不需要偏移
			if(centerNode){
				//
				leftWidth += centerNode.getLeftWidth();
				rightWidth += centerNode.getRightWidth();
			} else {
				// 添加 默认的距离
				leftWidth += hw / 2;
				rightWidth += hw / 2;
			}
			
			// 男性
			$.each(males, function(i,member){
				if(!member){return;}
				// 男性,加上一个间距
				rightWidth += hd;
				// 加上自己的左宽
				rightWidth += member.getLeftWidth();
				// 自己的右宽
				rightWidth += member.getRightWidth();
			});
			// 女性
			$.each(females, function(i,member){
				if(!member){return;}
				// 女性,加上一个间距
				leftWidth += hd;
				// 加上自己的右宽
				leftWidth += member.getRightWidth();
				// 自己的左宽
				leftWidth += member.getLeftWidth();
			});
			//
			return rightWidth;
		},
		getLevelWidth : function(){ // 获取Level自身的宽度
			return this.getLevelLeftWidth() + this.getLevelRightWidth();
		},
		clear : function(){
			// 清除所有数据
			debug(arguments.callee + ",清除所有数据!");
			return this;
		},
		toString : function(){
			return "TreeLevel[level="+ this.level +"]";
		}
	};
	
	// 构造函数 new FamilyTree();
	function FamilyTree(options){
		// 处理window的情况
		if(this === window){
			return new FamilyTree(options);
		}
		// family 的集合,tree 的基本属性模板
		var treeTemplate = {
			data : [], 		// 收到的原始成员数据,不应该修改
			hasInit : false,// 标志是否初始化
			levels : [],	// 所有级别
			level2s : [],	// 所有Level2级别
			totalLevel : 0, // 总的层级
			maxLevel : 0,	// 最大级别
			minLevel : 0,	// 最小级别
			maxLeftWidth : 0,// 最大左宽
			maxRightWidth : 0,// 最大右宽
			height : 0,		// 高度
			options : {},	// 配置信息
			anchor : null,  // 锚点，用于右边的留白
			dom : null
		};
		//扩展自身
		$.extend(this,treeTemplate);
		// 扩展 this.options
		this.options =$.extend({},defaults); 
		this.options =$.extend(this.options,options); 
	};
	
	// MARK Tree 的 proto方法集合
	FamilyTree.prototype = {
		constructor : FamilyTree,
		init : function(force) {
			// 判断是否初始化过,非强制
			if(!force && this.hasInit){
				return this;
			}
			//debug(this.toString()+".init()");
			this.hasInit = true;
			// 清空缓存的数据,以及自身dom
			this.clear();
			// 生成 树的根容器
			this.generateTreeDOM();
			// 生成层级
			if(this.data){
				this.generateLevels();
				this.levels.sort(function(level1,level2){
					return level1.level - level2.level; 
				});
			} else {
				debug("FamilyTree.init() : data is " + this.data);
			}
			// 分拣,level2
			var level2 = this.splitLevel2();
			
			// 
			$.each(this.levels, function(i,level){
				// 遍历levels,初始化
				level.init();
			});
			if(level2){
				this.hackLevel1(level2);
			}
			
			// 
			$.each(this.levels, function(i,level){
				// 遍历levels,计算HackLevel1
				level.settingOffsetLevel1();
			});
			
			// 初始化结束,设置偏移
			this.settingOffset();
			//
			return this;
		},
		splitLevel2 : function(){
			// 拆分level2
			var level2 = this.getLevel(2);
			if(!level2){
				return null;
			}
			//
			this.levels.pop(level2);
			return level2;
		},
		hackLevel1 : function(level2){// 修正level1
			if(!level2){
				return this;
			}
			var that = this;
			//
			var level1 = this.getLevel(1);
			if(!level1){
				return this;
			}
			var subLevels = [];
			function getSubLevel(parentId,index,parentNode){
				//
				var lv = null;
				$.each(subLevels, function(i,le){
					//
					if(parentId == le.parentId){
						lv = le;
						return false;// 不在继续往下遍历
					};
				});
				
				if(!lv){
					lv = new TreeLevel(index,this,null,parentNode);
					lv.parentId = parentId; // 附加值
					subLevels.push(lv);
					that.level2s.push(lv);
				}
				//
				return lv;
			};
			function getSubLevelByPartnerId(partnerId){
				if(!partnerId){
					return null;
				}
				//
				var lv = null;
				$.each(subLevels, function(i,le){
					if(!le){return;}
					//
					var datas = le.data || [];
					//
					$.each(datas,function(index,data){
						if(!data){return;}
						var memberId = data.memberId;
						if(partnerId == memberId){
							lv = le;
							return false;// 不在继续往下遍历
						}
					});
					if(lv){
						return false;// 不在继续往下遍历
					}
				});
				//
				return lv;
			};
			// 遍历生成
			var data2 = level2.data || [];
			var partner2data = []; // 配偶数据
			$.each(data2,function(i,v){
				if(!v){ return; }
				//
				var lev = v.level;
				var parentId = v.parentId;
				if(2 != lev){ return; }
				// 非主成员,配偶
				if(!parentId){
					partner2data.push(v);
					return; 
				}
				// 添加Level
				var subLev = getSubLevel(parentId,2);
				subLev.addData(v);
			});
			// 遍历配偶
			$.each(partner2data,function(i,v){
				//
				if(!v){ return; }
				//
				var partnerId = v.partnerId;
				if(!partnerId){ return; }
				//
				var subL = getSubLevelByPartnerId(partnerId);
				if(subL){
					subL.addData(v); // 添加到对应的层
				} else {
					debug("partnerId="+partnerId+",没有配偶subLevel.");
				}
			});
			// 根据parentId获取Level1之中的节点
			function getLevel1Node(level1,parentId){
				if(!parentId || !level1){
					return null;
				}
				//
				var node = null;
				var members = level1.members || [];
				$.each(members, function(i,mem){
					if(!mem){return;}
					//
					var data = mem.data || {};
					//
					var memberId = data.memberId;
					if(memberId && memberId==parentId){
						node = mem;
						return false;// 不在继续往下遍历
					}
				});
				//
				return node;
			};
			// 分配到Level1的Node之下
			$.each(subLevels, function(i,le){
				if(!le){return;}
				//
				var parentId = le.parentId;
				// 
				var lv1ParentNode = getLevel1Node(level1,parentId);
				if(lv1ParentNode){
					lv1ParentNode.subLevel = le;
					le.parentNode = lv1ParentNode;
				}
			});
			
			// hackSub
			var members = level1.members || [];
			$.each(members, function(i,mem){
				if(!mem){return;}
				// 适配 subLevel
				mem.hackSubLevel();
			});
		},
		setData : function (data){
			// 设置数据
			this.data = data;
			return this;
		},
		setTarget : function (target){
			// 设置容器
			this.target = target;
			return this;
		},
		generateLevels : function(){
			var that = this;
			var data = that.data;
			var offTime = 8 * 60 * 60 * 1000;// 8小时
			$.each(data,function(i,member){
				//
				if(member){
					var birthDate = member.birthDate;
					if(birthDate){
						member.birthDate = birthDate + offTime;
					}
					var le = member.level;
					var level = that.getOrNewLevel(le);
					level.addData(member);
					// 计算最大最小的level
					if(le > that.maxLevel){
						that.maxLevel = le;
					}
					if(le < that.minLevel){
						that.minLevel = le;
					}
				} else {
					debug("FamilyTree.generateLevels() : index="+i + ",member="+member);
				}
			});
		},
		getOrNewLevel : function(index){
			//
			var level = this.getLevel(index);
			if(!level){
				level = new TreeLevel(index,this);
				this.addLevel(level);
			}
			//
			return level;
		},
		getLevel : function(index){
			var that = this;
			//
			var level = null;
			$.each(that.levels, function(i,le){
				//
				if(le.isLevelAt(index)){
					level = le;
					return false;// 不在继续往下遍历
				};
			});
			//
			return level;
		},
		addLevel : function(level) {
			if(!level){
				return this;
			}
			if(!this.levels){
				this.levels = [];
			}
			this.levels.push(level);
			this.totalLevel = this.levels.length;
			return this;
		},
		getDataById : function(id){
			if(!id || ("string" !== typeof id) || !this.data){
				return null;
			}
			var result = null;
			// 遍历 主成员
			$.each(this.data, function(i,d){
				if(!d){
					return;
				}
				if(d.memberId == id){
					// 找到需要的元素
					result = d;
					return false;
				}
			});
			return result;
		},
		refresh : function(){
			//循环处理
			$.each(this.levels, function(i,level){
				// 遍历levels,初始化
				level.refresh();
			});
			// 刷新
			return this;
		},
		addOffset : function(x,y){
			this.x += x;
			this.y += y;
			//循环处理
			$.each(this.levels, function(i,level){
				// 遍历levels,初始化
				level.addOffset(x,y);
			});
			return this;
		},
		settingOffset : function(){
			// 设置自己内部一级元素offset
			var x = 0;
			var y = 0;
			var minLevel = this.minLevel;
			var maxLevel = this.maxLevel;
			
			// 先计算最大左宽
			var maxLeft = 0;
			var maxRight = 0;
			var maxWidth = 0;
			$.each(this.levels, function(i,level){
				// 遍历levels,初始化
				if(level){
					var leftWidth = level.leftWidth;
					var rightWidth = level.rightWidth;
					var width = level.width;
					if(leftWidth > maxLeft){
						maxLeft = leftWidth;
					}
					if(rightWidth > maxRight){
						maxRight = rightWidth;
					}
					if(width > maxWidth){
						maxWidth = width;
					}
				}
			});
			//
			var maxLevel2Width = 0;
			var maxLevel2Height = 0;
			$.each(this.level2s, function(i,level2){
				// 遍历levels,初始化
				if(level2){
					var leftWidth = level2.leftWidth;
					var rightWidth = level2.rightWidth;
					var width = level2.width;
					var height = level2.height;
					//
					maxLevel2Width += width;
					maxLevel2Width += width;
					// if(leftWidth > maxLeft){
						// maxLeft = leftWidth;
					// }
					// if(rightWidth > maxRight){
						// maxRight = rightWidth;
					// }
					// if(width > maxWidth){
						// maxWidth = width;
					// }
				}
			});
			this.maxLeftWidth = maxLeft;
			this.maxRightWidth = maxRight;
			this.maxLeftWidth = maxLeft;
			//
			if(maxWidth < 2 * maxLeft){
				maxWidth = 2 * maxLeft;
			}
			if(maxWidth < 2 * maxRight){
				maxWidth = 2 * maxRight;
			}
			//
			var minX = this.options.minX;
			if(maxWidth < minX){
				maxWidth = minX ;
			}
			if(this.maxRightWidth < minX/2){
				this.maxRightWidth = minX/2;
			}
			if(this.maxLefttWidth < minX/2){
				this.maxLefttWidth = minX/2;
			}
			
			//x = maxWidth/2 + this.options.marginLeft;
			x = maxLeft + this.options.marginLeft;
			y = this.options.marginTop;
			for(var ai = this.levels.length; ai < 3; ai++){
				y += this.options.marginTop;
			}
			//debug("x="+x+",minX="+minX+",maxWidth="+maxWidth+",maxLeft="+maxLeft);
			for(var index = minLevel; index <= maxLevel; index++){
				var level = this.getLevel(index);
				if(level){
					// 遍历levels,初始化
					level.addOffset(x,y);
					//debug(level+"x="+x+",level.y="+level.y)
					y += level.height;
				}
			}
			var lv2Height = 0;
			$.each(this.level2s, function(i,level2){
				// 遍历levels,初始化
				if(level2){
					//level2.addOffset(x,y); // 此处不处理，由Node自己决定
					var h = level2.height;
					if(h > lv2Height){
						lv2Height = h;
					}
				}
			});
			
			y += lv2Height;
			//
			this.height = y + this.options.marginTop;
			return this;
		},
		render : function(target){
			// 渲染
			target = target || this.target;
			if(target){
				this.dom.appendTo(target);
			} else {
				debug(this+"未能成功渲染,target="+target);
			}
			if(this.anchor){
				this.anchor.css("top",(this.height+this.options.marginTop)+"px")
				.css("left", (this.maxLeftWidth + this.maxRightWidth+this.options.marginLeft)+"px");
				this.anchor.appendTo(this.dom);
			}
			this.dom.removeClass(innerOptions.hideClass);
			return this;
		},
		show : function(target){
			var that = this;
			// 预防未初始化
			this.init();
			//
			this.render(target);
			// 
			$.each(this.levels, function(i,level){
				// 遍历levels,初始化
				level.show(that.dom);
			});
			// 
			return this;
		},
	 	generateTreeDOM : function(data) {
			// 生成Tree容器
			var $container = $("<div/>")
				.addClass(innerOptions.treeClass)
				.addClass(innerOptions.hideClass);
			this.dom = $container;
			//
			var $anchor = $("<div/>")
				.text(" ")
				.addClass(innerOptions.anchorClass);
			this.anchor = $anchor;
			return this;
		},
		clear : function(){
			// 清除DOM
			if("empty" in this){
				this.empty();
			}
			this.levels = [];
			return this;
		},
		toString : function(){
			
			return "FamilyTree[target="+ this.target +"]";
		}
	};
	
	
	// 主要函数,扩展,使用方式  $("#id").familytree(options || {});
	// 和 $.fn.extend({}) 效果一致，都是扩展到$.fn.init.prototype上面,即 $("#id")的原型$.fn上
	// $.fn.init.prototype.familytree
	$.fn.familytree = function(options) {
		var startTime = new Date().getTime();
		if(!options){
			return this;
		}
		var force = options.force;
		var tree = this.data("tree");
		if(tree && (tree.constructor === FamilyTree) && !force){
			return this;
		} else {
			this.empty();
		}
		
		
		function buildTree(options,data,target){
			var tree = new FamilyTree(options);
			// 需要持有一个引用
			that.data("tree",tree);
			// 获取数据,不跨域
			tree.setData(data);
			// 设置需要添加到的目标
			tree.setTarget(target);
			// 初始化
			tree.init();
			// 显示
			tree.show();
			
			tree.options.onComplete.call(tree,tree);
			//
			return tree;
		};
		// 
		var that = this;
		that.addClass(innerOptions.targetClass);
		var data = options.data;
		if(!data){
			var onAjax = options.onAjax;
			if("function" === typeof onAjax){
				onAjax.call(this);
			}
			// ajax 请求数据
			ajaxData.call(this,options,function(data){
				var ajaxTime = new Date().getTime();
				tree = buildTree(options,data,that);
				
				debug(that.data("tree"));
				var endTime = new Date().getTime();
				debug("All:"+(endTime-startTime)+"ms(Ajax: "+(ajaxTime-startTime)+"; Tree: "+(endTime-ajaxTime)+";)");
			});
		} else {
				tree = buildTree(options,data,that);
		}
		
		//debug(tree);
		// 添加事件 XXX
		$(that).delegate("."+innerOptions.memberClass, events.click,function(e){
			var prefix = innerOptions.memIdPre;
			//
			var allData = tree.data;
			var $this = $(this);
			var id = $this.attr("id");
			id = id.replace(prefix,"");
			
			var d = tree.getDataById(id);
			//
			
			return tree.options.onNodeClick.call(this,d,tree,e);
		});
		if(!isTouch){
			$(that).bind("swipemove",function(e,gesture){
				var con = that.find(".tree_container");
				var delta = gesture.delta;
				if(delta.length > 0){
					var d = delta[0];
					var lastX = d.lastX;
					var lastY = d.lastY;
					var div = con.get(0);
					if(!div){
						return;
					}
					//
					var scrollTop = document.body.scrollTop - lastY;
					var scrollTop2 = div.scrollTop - lastY;
					var scrollLeft = div.scrollLeft - lastX;
					if(scrollTop < 0){
						scrollTop = 0;
					}
					if(scrollTop2 < 0){
						scrollTop2 = 0;
					}
					if(scrollLeft < 0){
						scrollLeft = 0;
					}
					con.scrollLeft(scrollLeft);
					$("body").scrollTop(scrollTop);
					con.scrollTop(scrollTop2);
					//
					//div.scrollTop = scrollTop;
					//div.scrollLeft = scrollLeft;
					//
					//debug(scrollTop);
				}
			});
		}
		// 最后返回自身
		return this;
	};
	
	// 获取数据,不跨域
	function ajaxData(option,nextStep){
		var url = option["url"];
		var params = option["params"];
		var method = option["method"];
		// 获取参数，并异步赋值
		ajax(method,url,params,function(resObj){
			if(resObj && 1 == resObj["success"]){
				nextStep.call(nextStep,resObj.data);
			} else {
				debug("ajax请求失败:"+JSON.stringify(resObj));
			}
		});
		
		return this;
	};
	// 工具方法,post
	function post(url,params,recall,obj){
		var method = "POST";
		return ajax(method,url,params,recall,obj);
	};
	function get(url,params,recall,obj){
		var method = "GET";
		return ajax(method,url,params,recall,obj);
	};
	function ajax(method,url,params,recall,obj){
		$.ajax( {
			url : url,
			data : params || {},
			type : method || "POST",
			dataType: "json",
			complete : function(xhr,result) {
				var res = xhr.responseText;
				if(res){
					obj = obj || window;
					var resultObj = JSON.parse(res);
					if("function" === (typeof recall)){
						recall.call(obj,resultObj);
					} else {
						debug("recall is not a function !!!");
						return resultObj;
					}
				}
			}
		});
	};
	//var trace;
	function debug(obj){
		if(! defaults.debugMode ){
			return ;
		}
		var isObject = false;
		if("object" === (typeof obj)){
			isObject = true;
		}
		//
		if(false && isTouch){
			// 采用 tip的方式输出
			var $tip = $(".tip");
			if(0 === $tip.length){
				$tip = $('<div class="tip"></div>');
				$tip.appendTo("body");
			}
			var p = $("<p></p>").text(obj);
			$tip.append(p).removeClass("hide");
			$tip.unbind("click").bind("click",function(){
				$(".tip").addClass("hide");
			});
		} else if("console" in window){
			if(isObject){
				console.dir(obj);
			} else {
				console.log(obj);
			}
		} else {
			alert(obj);
		}
	};
	if(defaults.debugMode ){
		window.debug = debug;
	}
	
	// init, 处理参数,构建环境
	// load, 载入具体的数据,或者 string类型的URL地址
	// show, 显示DOM以及界面
	// hide, 隐藏
	// start,开始
	// edit, 编辑
	// save, 保存某个节点,具体方法可能需要外部书写,比如ajax。
	// 


})(jQuery); 

// 日期格式化
function date2String(date,separator){
	separator = separator || {
		yearsep : "-"
		,monsep : "-"
		,daysep : ""
	};
	if(!date){
		return "0000"+separator.yearsep+"00"+separator.monsep+"00"+separator.daysep;
	}
	var type = typeof date;
	if("string" === type){
		//var reg = /^\d+$/;
		date = Number(date);
		date = new Date(date);
	}
	if("number" === type){
		date = new Date(date);
	}
	//
	var year = date.getFullYear();
	var mon = 1+date.getMonth();
	var day = date.getDate();
	
	var res = "";
	res += year + separator.yearsep;
	if(mon < 10){
		mon = "0"+mon;
	}
	res += mon + separator.monsep;
	if(day < 10){
		day = "0"+day;
	}
	res += day + separator.daysep;
	//
	return res;
};

// 每个成员，4根线，上下左右. 有部分是不显示的。
// 属于某人的配偶的，则只有右边界线,竖线，是配偶数组所决定的.
// 1. 先计算中心点(家谱主人,(0,0))，然后计算其他的member 的层次相对位置，然后计算单个成员的相对位置
// tree --> level(line) --> node(lines) --> partner --> line