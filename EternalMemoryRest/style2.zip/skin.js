// Garden Gnome Software - Skin
// Pano2VR pro 4.1.0/3405MS
// Filename: em.ggsk
// Generated 周六 十二月 28 20:43:28 2013

function pano2vrSkin(player,base) {
	var me=this;
	var flag=false;
	var nodeMarker=new Array();
	var activeNodeMarker=new Array();
	this.player=player;
	this.player.skinObj=this;
	this.divSkin=player.divSkin;
	var basePath="";
	// auto detect base path
	if (base=='?') {
		var scripts = document.getElementsByTagName('script');
		for(var i=0;i<scripts.length;i++) {
			var src=scripts[i].src;
			if (src.indexOf('skin.js')>=0) {
				var p=src.lastIndexOf('/');
				if (p>=0) {
					basePath=src.substr(0,p+1);
				}
			}
		}
	} else
	if (base) {
		basePath=base;
	}
	this.elementMouseDown=new Array();
	this.elementMouseOver=new Array();
	var cssPrefix='';
	var domTransition='transition';
	var domTransform='transform';
	var prefixes='Webkit,Moz,O,ms,Ms'.split(',');
	var i;
	for(i=0;i<prefixes.length;i++) {
		if (typeof document.body.style[prefixes[i] + 'Transform'] !== 'undefined') {
			cssPrefix='-' + prefixes[i].toLowerCase() + '-';
			domTransition=prefixes[i] + 'Transition';
			domTransform=prefixes[i] + 'Transform';
		}
	}
	
	this.player.setMargins(0,0,0,0);
	
	this.updateSize=function(startElement) {
		var stack=new Array();
		stack.push(startElement);
		while(stack.length>0) {
			e=stack.pop();
			if (e.ggUpdatePosition) {
				e.ggUpdatePosition();
			}
			if (e.hasChildNodes()) {
				for(i=0;i<e.childNodes.length;i++) {
					stack.push(e.childNodes[i]);
				}
			}
		}
	}
	
	parameterToTransform=function(p) {
		return 'translate(' + p.rx + 'px,' + p.ry + 'px) rotate(' + p.a + 'deg) scale(' + p.sx + ',' + p.sy + ')';
	}
	
	this.findElements=function(id,regex) {
		var r=new Array();
		var stack=new Array();
		var pat=new RegExp(id,'');
		stack.push(me.divSkin);
		while(stack.length>0) {
			e=stack.pop();
			if (regex) {
				if (pat.test(e.ggId)) r.push(e);
			} else {
				if (e.ggId==id) r.push(e);
			}
			if (e.hasChildNodes()) {
				for(i=0;i<e.childNodes.length;i++) {
					stack.push(e.childNodes[i]);
				}
			}
		}
		return r;
	}
	
	this.addSkin=function() {
		this._controller=document.createElement('div');
		this._controller.ggId='controller';
		this._controller.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._controller.ggVisible=true;
		this._controller.className='ggskin ggskin_container';
		this._controller.ggUpdatePosition=function() {
			this.style[domTransition]='none';
			if (this.parentNode) {
				w=this.parentNode.offsetWidth;
				this.style.left=(-142 + w/2) + 'px';
				h=this.parentNode.offsetHeight;
				this.style.top=(-65 + h) + 'px';
			}
		}
		hs ='position:absolute;';
		hs+='left: -142px;';
		hs+='top:  -65px;';
		hs+='width: 286px;';
		hs+='height: 50px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		this._controller.setAttribute('style',hs);
		this._up=document.createElement('div');
		this._up.ggId='up';
		this._up.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._up.ggVisible=true;
		this._up.className='ggskin ggskin_svg';
		hs ='position:absolute;';
		hs+='left: 25px;';
		hs+='top:  -5px;';
		hs+='width: 32px;';
		hs+='height: 32px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='cursor: pointer;';
		this._up.setAttribute('style',hs);
		this._up__img=document.createElement('img');
		this._up__img.setAttribute('src',basePath + 'images/up.svg');
		this._up__img.setAttribute('style','position: absolute;top: 0px;left: 0px;width: 32px;height: 32px;-webkit-user-drag:none;');
		this._up__img['ondragstart']=function() { return false; };
		this._up.appendChild(this._up__img);
		this._up.onmouseover=function () {
			me._up__img.src=basePath + 'images/up__o.svg';
		}
		this._up.onmouseout=function () {
			me._up__img.src=basePath + 'images/up.svg';
			me.elementMouseDown['up']=false;
		}
		this._up.onmousedown=function () {
			me.elementMouseDown['up']=true;
		}
		this._up.onmouseup=function () {
			me.elementMouseDown['up']=false;
		}
		this._up.ontouchend=function () {
			me.elementMouseDown['up']=false;
		}
		this._controller.appendChild(this._up);
		this._down=document.createElement('div');
		this._down.ggId='down';
		this._down.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._down.ggVisible=true;
		this._down.className='ggskin ggskin_svg';
		hs ='position:absolute;';
		hs+='left: 25px;';
		hs+='top:  25px;';
		hs+='width: 32px;';
		hs+='height: 32px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='cursor: pointer;';
		this._down.setAttribute('style',hs);
		this._down__img=document.createElement('img');
		this._down__img.setAttribute('src',basePath + 'images/down.svg');
		this._down__img.setAttribute('style','position: absolute;top: 0px;left: 0px;width: 32px;height: 32px;-webkit-user-drag:none;');
		this._down__img['ondragstart']=function() { return false; };
		this._down.appendChild(this._down__img);
		this._down.onmouseover=function () {
			me._down__img.src=basePath + 'images/down__o.svg';
		}
		this._down.onmouseout=function () {
			me._down__img.src=basePath + 'images/down.svg';
			me.elementMouseDown['down']=false;
		}
		this._down.onmousedown=function () {
			me.elementMouseDown['down']=true;
		}
		this._down.onmouseup=function () {
			me.elementMouseDown['down']=false;
		}
		this._down.ontouchend=function () {
			me.elementMouseDown['down']=false;
		}
		this._controller.appendChild(this._down);
		this._left0=document.createElement('div');
		this._left0.ggId='left';
		this._left0.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._left0.ggVisible=true;
		this._left0.className='ggskin ggskin_svg';
		hs ='position:absolute;';
		hs+='left: 0px;';
		hs+='top:  10px;';
		hs+='width: 32px;';
		hs+='height: 32px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='cursor: pointer;';
		this._left0.setAttribute('style',hs);
		this._left0__img=document.createElement('img');
		this._left0__img.setAttribute('src',basePath + 'images/left0.svg');
		this._left0__img.setAttribute('style','position: absolute;top: 0px;left: 0px;width: 32px;height: 32px;-webkit-user-drag:none;');
		this._left0__img['ondragstart']=function() { return false; };
		this._left0.appendChild(this._left0__img);
		this._left0.onmouseover=function () {
			me._left0__img.src=basePath + 'images/left0__o.svg';
		}
		this._left0.onmouseout=function () {
			me._left0__img.src=basePath + 'images/left0.svg';
			me.elementMouseDown['left0']=false;
		}
		this._left0.onmousedown=function () {
			me.elementMouseDown['left0']=true;
		}
		this._left0.onmouseup=function () {
			me.elementMouseDown['left0']=false;
		}
		this._left0.ontouchend=function () {
			me.elementMouseDown['left0']=false;
		}
		this._controller.appendChild(this._left0);
		this._right0=document.createElement('div');
		this._right0.ggId='right';
		this._right0.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._right0.ggVisible=true;
		this._right0.className='ggskin ggskin_svg';
		hs ='position:absolute;';
		hs+='left: 50px;';
		hs+='top:  10px;';
		hs+='width: 32px;';
		hs+='height: 32px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='cursor: pointer;';
		this._right0.setAttribute('style',hs);
		this._right0__img=document.createElement('img');
		this._right0__img.setAttribute('src',basePath + 'images/right0.svg');
		this._right0__img.setAttribute('style','position: absolute;top: 0px;left: 0px;width: 32px;height: 32px;-webkit-user-drag:none;');
		this._right0__img['ondragstart']=function() { return false; };
		this._right0.appendChild(this._right0__img);
		this._right0.onmouseover=function () {
			me._right0__img.src=basePath + 'images/right0__o.svg';
		}
		this._right0.onmouseout=function () {
			me._right0__img.src=basePath + 'images/right0.svg';
			me.elementMouseDown['right0']=false;
		}
		this._right0.onmousedown=function () {
			me.elementMouseDown['right0']=true;
		}
		this._right0.onmouseup=function () {
			me.elementMouseDown['right0']=false;
		}
		this._right0.ontouchend=function () {
			me.elementMouseDown['right0']=false;
		}
		this._controller.appendChild(this._right0);
		this._zoomin=document.createElement('div');
		this._zoomin.ggId='zoomin';
		this._zoomin.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._zoomin.ggVisible=true;
		this._zoomin.className='ggskin ggskin_svg';
		hs ='position:absolute;';
		hs+='left: 90px;';
		hs+='top:  10px;';
		hs+='width: 32px;';
		hs+='height: 32px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='cursor: pointer;';
		this._zoomin.setAttribute('style',hs);
		this._zoomin__img=document.createElement('img');
		this._zoomin__img.setAttribute('src',basePath + 'images/zoomin.svg');
		this._zoomin__img.setAttribute('style','position: absolute;top: 0px;left: 0px;width: 32px;height: 32px;-webkit-user-drag:none;');
		this._zoomin__img['ondragstart']=function() { return false; };
		this._zoomin.appendChild(this._zoomin__img);
		this._zoomin.onmouseover=function () {
			me._zoomin__img.src=basePath + 'images/zoomin__o.svg';
		}
		this._zoomin.onmouseout=function () {
			me._zoomin__img.src=basePath + 'images/zoomin.svg';
			me.elementMouseDown['zoomin']=false;
		}
		this._zoomin.onmousedown=function () {
			me.elementMouseDown['zoomin']=true;
		}
		this._zoomin.onmouseup=function () {
			me.elementMouseDown['zoomin']=false;
		}
		this._zoomin.ontouchend=function () {
			me.elementMouseDown['zoomin']=false;
		}
		this._controller.appendChild(this._zoomin);
		this._zoomout=document.createElement('div');
		this._zoomout.ggId='zoomout';
		this._zoomout.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._zoomout.ggVisible=true;
		this._zoomout.className='ggskin ggskin_svg';
		hs ='position:absolute;';
		hs+='left: 120px;';
		hs+='top:  10px;';
		hs+='width: 32px;';
		hs+='height: 32px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='cursor: pointer;';
		this._zoomout.setAttribute('style',hs);
		this._zoomout__img=document.createElement('img');
		this._zoomout__img.setAttribute('src',basePath + 'images/zoomout.svg');
		this._zoomout__img.setAttribute('style','position: absolute;top: 0px;left: 0px;width: 32px;height: 32px;-webkit-user-drag:none;');
		this._zoomout__img['ondragstart']=function() { return false; };
		this._zoomout.appendChild(this._zoomout__img);
		this._zoomout.onmouseover=function () {
			me._zoomout__img.src=basePath + 'images/zoomout__o.svg';
		}
		this._zoomout.onmouseout=function () {
			me._zoomout__img.src=basePath + 'images/zoomout.svg';
			me.elementMouseDown['zoomout']=false;
		}
		this._zoomout.onmousedown=function () {
			me.elementMouseDown['zoomout']=true;
		}
		this._zoomout.onmouseup=function () {
			me.elementMouseDown['zoomout']=false;
		}
		this._zoomout.ontouchend=function () {
			me.elementMouseDown['zoomout']=false;
		}
		this._controller.appendChild(this._zoomout);
		this._autorotate=document.createElement('div');
		this._autorotate.ggId='autorotate';
		this._autorotate.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._autorotate.ggVisible=true;
		this._autorotate.className='ggskin ggskin_svg';
		hs ='position:absolute;';
		hs+='left: 160px;';
		hs+='top:  10px;';
		hs+='width: 32px;';
		hs+='height: 32px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='cursor: pointer;';
		this._autorotate.setAttribute('style',hs);
		this._autorotate__img=document.createElement('img');
		this._autorotate__img.setAttribute('src',basePath + 'images/autorotate.svg');
		this._autorotate__img.setAttribute('style','position: absolute;top: 0px;left: 0px;width: 32px;height: 32px;-webkit-user-drag:none;');
		this._autorotate__img['ondragstart']=function() { return false; };
		this._autorotate.appendChild(this._autorotate__img);
		this._autorotate.onclick=function () {
			me.player.toggleAutorotate();
		}
		this._autorotate.onmouseover=function () {
			me._autorotate__img.src=basePath + 'images/autorotate__o.svg';
		}
		this._autorotate.onmouseout=function () {
			me._autorotate__img.src=basePath + 'images/autorotate.svg';
		}
		this._controller.appendChild(this._autorotate);
		this._info=document.createElement('div');
		this._info.ggId='info';
		this._info.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._info.ggVisible=true;
		this._info.className='ggskin ggskin_svg';
		hs ='position:absolute;';
		hs+='left: 190px;';
		hs+='top:  10px;';
		hs+='width: 32px;';
		hs+='height: 32px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='cursor: pointer;';
		this._info.setAttribute('style',hs);
		this._info__img=document.createElement('img');
		this._info__img.setAttribute('src',basePath + 'images/info.svg');
		this._info__img.setAttribute('style','position: absolute;top: 0px;left: 0px;width: 32px;height: 32px;-webkit-user-drag:none;');
		this._info__img['ondragstart']=function() { return false; };
		this._info.appendChild(this._info__img);
		this._info.onclick=function () {
			flag=(me._userdata.style.visibility=='hidden');
			me._userdata.style[domTransition]='none';
			me._userdata.style.visibility=flag?'inherit':'hidden';
			me._userdata.ggVisible=flag;
		}
		this._info.onmouseover=function () {
			me._info__img.src=basePath + 'images/info__o.svg';
		}
		this._info.onmouseout=function () {
			me._info__img.src=basePath + 'images/info.svg';
		}
		this._controller.appendChild(this._info);
		this._movemode=document.createElement('div');
		this._movemode.ggId='movemode';
		this._movemode.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._movemode.ggVisible=true;
		this._movemode.className='ggskin ggskin_svg';
		hs ='position:absolute;';
		hs+='left: 220px;';
		hs+='top:  10px;';
		hs+='width: 32px;';
		hs+='height: 32px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='cursor: pointer;';
		this._movemode.setAttribute('style',hs);
		this._movemode__img=document.createElement('img');
		this._movemode__img.setAttribute('src',basePath + 'images/movemode.svg');
		this._movemode__img.setAttribute('style','position: absolute;top: 0px;left: 0px;width: 32px;height: 32px;-webkit-user-drag:none;');
		this._movemode__img['ondragstart']=function() { return false; };
		this._movemode.appendChild(this._movemode__img);
		this._movemode.onclick=function () {
			me.player.changeViewMode(2);
		}
		this._movemode.onmouseover=function () {
			me._movemode__img.src=basePath + 'images/movemode__o.svg';
		}
		this._movemode.onmouseout=function () {
			me._movemode__img.src=basePath + 'images/movemode.svg';
		}
		this._controller.appendChild(this._movemode);
		this._fullscreen=document.createElement('div');
		this._fullscreen.ggId='fullscreen';
		this._fullscreen.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._fullscreen.ggVisible=true;
		this._fullscreen.className='ggskin ggskin_svg';
		hs ='position:absolute;';
		hs+='left: 250px;';
		hs+='top:  10px;';
		hs+='width: 32px;';
		hs+='height: 32px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='cursor: pointer;';
		this._fullscreen.setAttribute('style',hs);
		this._fullscreen__img=document.createElement('img');
		this._fullscreen__img.setAttribute('src',basePath + 'images/fullscreen.svg');
		this._fullscreen__img.setAttribute('style','position: absolute;top: 0px;left: 0px;width: 32px;height: 32px;-webkit-user-drag:none;');
		this._fullscreen__img['ondragstart']=function() { return false; };
		this._fullscreen.appendChild(this._fullscreen__img);
		this._fullscreen.onclick=function () {
			me.player.toggleFullscreen();
		}
		this._fullscreen.onmouseover=function () {
			me._fullscreen__img.src=basePath + 'images/fullscreen__o.svg';
		}
		this._fullscreen.onmouseout=function () {
			me._fullscreen__img.src=basePath + 'images/fullscreen.svg';
		}
		this._controller.appendChild(this._fullscreen);
		this.divSkin.appendChild(this._controller);
		this._loading=document.createElement('div');
		this._loading.ggId='loading';
		this._loading.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._loading.ggVisible=true;
		this._loading.className='ggskin ggskin_container';
		this._loading.ggUpdatePosition=function() {
			this.style[domTransition]='none';
			if (this.parentNode) {
				w=this.parentNode.offsetWidth;
				this.style.left=(-105 + w/2) + 'px';
				h=this.parentNode.offsetHeight;
				this.style.top=(-30 + h/2) + 'px';
			}
		}
		hs ='position:absolute;';
		hs+='left: -105px;';
		hs+='top:  -30px;';
		hs+='width: 210px;';
		hs+='height: 60px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		this._loading.setAttribute('style',hs);
		this._loading.onclick=function () {
			me._loading.style[domTransition]='none';
			me._loading.style.visibility='hidden';
			me._loading.ggVisible=false;
		}
		this._loadingbg=document.createElement('div');
		this._loadingbg.ggId='loadingbg';
		this._loadingbg.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._loadingbg.ggVisible=true;
		this._loadingbg.className='ggskin ggskin_rectangle';
		hs ='position:absolute;';
		hs+='left: 0px;';
		hs+='top:  0px;';
		hs+='width: 210px;';
		hs+='height: 60px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='opacity: 0.5;';
		hs+='visibility: inherit;';
		hs+='background: #000000;';
		hs+='border: 0px solid #000000;';
		hs+='border-radius: 10px;';
		hs+=cssPrefix + 'border-radius: 10px;';
		this._loadingbg.setAttribute('style',hs);
		this._loading.appendChild(this._loadingbg);
		this._loadingbrd=document.createElement('div');
		this._loadingbrd.ggId='loadingbrd';
		this._loadingbrd.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._loadingbrd.ggVisible=true;
		this._loadingbrd.className='ggskin ggskin_rectangle';
		hs ='position:absolute;';
		hs+='left: -1px;';
		hs+='top:  -1px;';
		hs+='width: 208px;';
		hs+='height: 58px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='opacity: 0.5;';
		hs+='visibility: inherit;';
		hs+='border: 2px solid #ffffff;';
		hs+='border-radius: 10px;';
		hs+=cssPrefix + 'border-radius: 10px;';
		this._loadingbrd.setAttribute('style',hs);
		this._loading.appendChild(this._loadingbrd);
		this._loadingtext=document.createElement('div');
		this._loadingtext.ggId='loadingtext';
		this._loadingtext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._loadingtext.ggVisible=true;
		this._loadingtext.className='ggskin ggskin_text';
		hs ='position:absolute;';
		hs+='left: 16px;';
		hs+='top:  12px;';
		hs+='width: auto;';
		hs+='height: auto;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='border: 0px solid #000000;';
		hs+='color: #ffffff;';
		hs+='text-align: left;';
		hs+='white-space: nowrap;';
		hs+='padding: 0px 1px 0px 1px;';
		hs+='overflow: hidden;';
		this._loadingtext.setAttribute('style',hs);
		this._loadingtext.ggUpdateText=function() {
			var hs="Loading... "+(me.player.getPercentLoaded()*100.0).toFixed(0)+"%";
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.innerHTML=hs;
			}
		}
		this._loadingtext.ggUpdateText();
		this._loading.appendChild(this._loadingtext);
		this._loadingbar=document.createElement('div');
		this._loadingbar.ggId='loadingbar';
		this._loadingbar.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._loadingbar.ggVisible=true;
		this._loadingbar.className='ggskin ggskin_rectangle';
		hs ='position:absolute;';
		hs+='left: 15px;';
		hs+='top:  35px;';
		hs+='width: 181px;';
		hs+='height: 12px;';
		hs+=cssPrefix + 'transform-origin: 0% 50%;';
		hs+='visibility: inherit;';
		hs+='background: #ffffff;';
		hs+='border: 1px solid #808080;';
		hs+='border-radius: 5px;';
		hs+=cssPrefix + 'border-radius: 5px;';
		this._loadingbar.setAttribute('style',hs);
		this._loading.appendChild(this._loadingbar);
		this.divSkin.appendChild(this._loading);
		this._userdata=document.createElement('div');
		this._userdata.ggId='userdata';
		this._userdata.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._userdata.ggVisible=false;
		this._userdata.className='ggskin ggskin_container';
		this._userdata.ggUpdatePosition=function() {
			this.style[domTransition]='none';
			if (this.parentNode) {
				w=this.parentNode.offsetWidth;
				this.style.left=(-120 + w/2) + 'px';
				h=this.parentNode.offsetHeight;
				this.style.top=(-80 + h/2) + 'px';
			}
		}
		hs ='position:absolute;';
		hs+='left: -120px;';
		hs+='top:  -80px;';
		hs+='width: 240px;';
		hs+='height: 140px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: hidden;';
		this._userdata.setAttribute('style',hs);
		this._userdata.onclick=function () {
			me._userdata.style[domTransition]='none';
			me._userdata.style.visibility='hidden';
			me._userdata.ggVisible=false;
		}
		this._userdatabg=document.createElement('div');
		this._userdatabg.ggId='userdatabg';
		this._userdatabg.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._userdatabg.ggVisible=true;
		this._userdatabg.className='ggskin ggskin_rectangle';
		hs ='position:absolute;';
		hs+='left: 0px;';
		hs+='top:  0px;';
		hs+='width: 240px;';
		hs+='height: 140px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='opacity: 0.5;';
		hs+='visibility: inherit;';
		hs+='background: #000000;';
		hs+='border: 0px solid #000000;';
		hs+='border-radius: 10px;';
		hs+=cssPrefix + 'border-radius: 10px;';
		this._userdatabg.setAttribute('style',hs);
		this._userdata.appendChild(this._userdatabg);
		this._userdatabrd=document.createElement('div');
		this._userdatabrd.ggId='userdatabrd';
		this._userdatabrd.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._userdatabrd.ggVisible=true;
		this._userdatabrd.className='ggskin ggskin_rectangle';
		hs ='position:absolute;';
		hs+='left: -1px;';
		hs+='top:  -1px;';
		hs+='width: 238px;';
		hs+='height: 138px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='opacity: 0.5;';
		hs+='visibility: inherit;';
		hs+='border: 2px solid #ffffff;';
		hs+='border-radius: 10px;';
		hs+=cssPrefix + 'border-radius: 10px;';
		this._userdatabrd.setAttribute('style',hs);
		this._userdata.appendChild(this._userdatabrd);
		this._title=document.createElement('div');
		this._title.ggId='title';
		this._title.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._title.ggVisible=true;
		this._title.className='ggskin ggskin_text';
		hs ='position:absolute;';
		hs+='left: 10px;';
		hs+='top:  10px;';
		hs+='width: 220px;';
		hs+='height: 20px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='border: 0px solid #000000;';
		hs+='color: #ffffff;';
		hs+='text-align: left;';
		hs+='white-space: nowrap;';
		hs+='padding: 0px 1px 0px 1px;';
		hs+='overflow: hidden;';
		this._title.setAttribute('style',hs);
		this._title.ggUpdateText=function() {
			var hs="<b>"+me.player.userdata.title+"<\/b>";
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.innerHTML=hs;
			}
		}
		this._title.ggUpdateText();
		this._userdata.appendChild(this._title);
		this._description=document.createElement('div');
		this._description.ggId='description';
		this._description.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._description.ggVisible=true;
		this._description.className='ggskin ggskin_text';
		hs ='position:absolute;';
		hs+='left: 10px;';
		hs+='top:  30px;';
		hs+='width: 220px;';
		hs+='height: 20px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='border: 0px solid #000000;';
		hs+='color: #ffffff;';
		hs+='text-align: left;';
		hs+='white-space: nowrap;';
		hs+='padding: 0px 1px 0px 1px;';
		hs+='overflow: hidden;';
		this._description.setAttribute('style',hs);
		this._description.ggUpdateText=function() {
			var hs=me.player.userdata.description;
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.innerHTML=hs;
			}
		}
		this._description.ggUpdateText();
		this._userdata.appendChild(this._description);
		this._author=document.createElement('div');
		this._author.ggId='author';
		this._author.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._author.ggVisible=true;
		this._author.className='ggskin ggskin_text';
		hs ='position:absolute;';
		hs+='left: 10px;';
		hs+='top:  50px;';
		hs+='width: 220px;';
		hs+='height: 20px;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='border: 0px solid #000000;';
		hs+='color: #ffffff;';
		hs+='text-align: left;';
		hs+='white-space: nowrap;';
		hs+='padding: 0px 1px 0px 1px;';
		hs+='overflow: hidden;';
		this._author.setAttribute('style',hs);
		this._author.ggUpdateText=function() {
			var hs=me.player.userdata.author;
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.innerHTML=hs;
			}
		}
		this._author.ggUpdateText();
		this._userdata.appendChild(this._author);
		this._datetime=document.createElement('div');
		this._datetime.ggId='datetime';
		this._datetime.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._datetime.ggVisible=true;
		this._datetime.className='ggskin ggskin_text';
		hs ='position:absolute;';
		hs+='left: 10px;';
		hs+='top:  70px;';
		hs+='width: auto;';
		hs+='height: auto;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='border: 0px solid #000000;';
		hs+='color: #ffffff;';
		hs+='text-align: left;';
		hs+='white-space: nowrap;';
		hs+='padding: 0px 1px 0px 1px;';
		hs+='overflow: hidden;';
		this._datetime.setAttribute('style',hs);
		this._datetime.ggUpdateText=function() {
			var hs=me.player.userdata.datetime;
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.innerHTML=hs;
			}
		}
		this._datetime.ggUpdateText();
		this._userdata.appendChild(this._datetime);
		this._copyright=document.createElement('div');
		this._copyright.ggId='copyright';
		this._copyright.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
		this._copyright.ggVisible=true;
		this._copyright.className='ggskin ggskin_text';
		hs ='position:absolute;';
		hs+='left: 10px;';
		hs+='top:  110px;';
		hs+='width: auto;';
		hs+='height: auto;';
		hs+=cssPrefix + 'transform-origin: 50% 50%;';
		hs+='visibility: inherit;';
		hs+='border: 0px solid #000000;';
		hs+='color: #ffffff;';
		hs+='text-align: left;';
		hs+='white-space: nowrap;';
		hs+='padding: 0px 1px 0px 1px;';
		hs+='overflow: hidden;';
		this._copyright.setAttribute('style',hs);
		this._copyright.ggUpdateText=function() {
			var hs="&#169; "+me.player.userdata.copyright;
			if (hs!=this.ggText) {
				this.ggText=hs;
				this.innerHTML=hs;
			}
		}
		this._copyright.ggUpdateText();
		this._userdata.appendChild(this._copyright);
		this.divSkin.appendChild(this._userdata);
		this.divSkin.ggUpdateSize=function(w,h) {
			me.updateSize(me.divSkin);
		}
		this.divSkin.ggViewerInit=function() {
		}
		this.divSkin.ggLoaded=function() {
			me._loading.style[domTransition]='none';
			me._loading.style.visibility='hidden';
			me._loading.ggVisible=false;
		}
		this.divSkin.ggReLoaded=function() {
			me._loading.style[domTransition]='none';
			me._loading.style.visibility='inherit';
			me._loading.ggVisible=true;
		}
		this.divSkin.ggEnterFullscreen=function() {
		}
		this.divSkin.ggExitFullscreen=function() {
		}
		this.skinTimerEvent();
	};
	this.hotspotProxyClick=function(id) {
	}
	this.hotspotProxyOver=function(id) {
	}
	this.hotspotProxyOut=function(id) {
	}
	this.changeActiveNode=function(id) {
		var newMarker=new Array();
		var i,j;
		var tags=me.player.userdata.tags;
		for (i=0;i<nodeMarker.length;i++) {
			var match=false;
			if (nodeMarker[i].ggMarkerNodeId==id) match=true;
			for(j=0;j<tags.length;j++) {
				if (nodeMarker[i].ggMarkerNodeId==tags[j]) match=true;
			}
			if (match) {
				newMarker.push(nodeMarker[i]);
			}
		}
		for(i=0;i<activeNodeMarker.length;i++) {
			if (newMarker.indexOf(activeNodeMarker[i])<0) {
				if (activeNodeMarker[i].ggMarkerNormal) {
					activeNodeMarker[i].ggMarkerNormal.style.visibility='inherit';
				}
				if (activeNodeMarker[i].ggMarkerActive) {
					activeNodeMarker[i].ggMarkerActive.style.visibility='hidden';
				}
				if (activeNodeMarker[i].ggDeactivate) {
					activeNodeMarker[i].ggDeactivate();
				}
			}
		}
		for(i=0;i<newMarker.length;i++) {
			if (activeNodeMarker.indexOf(newMarker[i])<0) {
				if (newMarker[i].ggMarkerNormal) {
					newMarker[i].ggMarkerNormal.style.visibility='hidden';
				}
				if (newMarker[i].ggMarkerActive) {
					newMarker[i].ggMarkerActive.style.visibility='inherit';
				}
				if (newMarker[i].ggActivate) {
					newMarker[i].ggActivate();
				}
			}
		}
		activeNodeMarker=newMarker;
	}
	this.skinTimerEvent=function() {
		setTimeout(function() { me.skinTimerEvent(); }, 10);
		if (me.elementMouseDown['up']) {
			me.player.changeTilt(1,true);
		}
		if (me.elementMouseDown['down']) {
			me.player.changeTilt(-1,true);
		}
		if (me.elementMouseDown['left0']) {
			me.player.changePan(1,true);
		}
		if (me.elementMouseDown['right0']) {
			me.player.changePan(-1,true);
		}
		if (me.elementMouseDown['zoomin']) {
			me.player.changeFovLog(-1,true);
		}
		if (me.elementMouseDown['zoomout']) {
			me.player.changeFovLog(1,true);
		}
		this._loadingtext.ggUpdateText();
		var hs='';
		if (me._loadingbar.ggParameter) {
			hs+=parameterToTransform(me._loadingbar.ggParameter) + ' ';
		}
		hs+='scale(' + (1 * me.player.getPercentLoaded() + 0) + ',1.0) ';
		me._loadingbar.style[domTransform]=hs;
		this._title.ggUpdateText();
		this._description.ggUpdateText();
		this._author.ggUpdateText();
		this._datetime.ggUpdateText();
		this._copyright.ggUpdateText();
	};
	function SkinHotspotClass(skinObj,hotspot) {
		var me=this;
		var flag=false;
		this.player=skinObj.player;
		this.skin=skinObj;
		this.hotspot=hotspot;
		this.elementMouseDown=new Array();
		this.elementMouseOver=new Array();
		this.__div=document.createElement('div');
		this.__div.setAttribute('style','position:absolute; left:0px;top:0px;visibility: inherit;');
		
		this.findElements=function(id,regex) {
			return me.skin.findElements(id,regex);
		}
		
		if (hotspot.skinid=='hotspot') {
			this.__div=document.createElement('div');
			this.__div.ggId='hotspot';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot';
			hs ='position:absolute;';
			hs+='left: 340px;';
			hs+='top:  20px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me._hstext.style[domTransition]='none';
				me._hstext.style.visibility='inherit';
				me._hstext.ggVisible=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._hstext.style[domTransition]='none';
				me._hstext.style.visibility='hidden';
				me._hstext.ggVisible=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this._hsimage=document.createElement('div');
			this._hsimage.ggId='hsimage';
			this._hsimage.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._hsimage.ggVisible=true;
			this._hsimage.className='ggskin ggskin_svg';
			hs ='position:absolute;';
			hs+='left: -16px;';
			hs+='top:  -16px;';
			hs+='width: 32px;';
			hs+='height: 32px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._hsimage.setAttribute('style',hs);
			this._hsimage__img=document.createElement('img');
			this._hsimage__img.setAttribute('src',basePath + 'images/hsimage.svg');
			this._hsimage__img.setAttribute('style','position: absolute;top: 0px;left: 0px;width: 32px;height: 32px;-webkit-user-drag:none;');
			this._hsimage__img['ondragstart']=function() { return false; };
			this._hsimage.appendChild(this._hsimage__img);
			this.__div.appendChild(this._hsimage);
			this._hstext=document.createElement('div');
			this._hstext.ggId='hstext';
			this._hstext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._hstext.ggVisible=false;
			this._hstext.className='ggskin ggskin_text';
			this._hstext.ggUpdatePosition=function() {
				this.style[domTransition]='none';
				this.style.left=(-50 + (101-this.offsetWidth)/2) + 'px';
			}
			hs ='position:absolute;';
			hs+='left: -50px;';
			hs+='top:  20px;';
			hs+='width: auto;';
			hs+='height: auto;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._hstext.setAttribute('style',hs);
			this._hstext.innerHTML=me.hotspot.title;
			this.__div.appendChild(this._hstext);
		} else
		if (hotspot.skinid=='audio') {
			this.__div=document.createElement('div');
			this.__div.ggId='audio';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot';
			hs ='position:absolute;';
			hs+='left: 288px;';
			hs+='top:  72px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this._audio_pre=document.createElement('div');
			this._audio_pre.ggId='audio_pre';
			this._audio_pre.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._audio_pre.ggVisible=true;
			this._audio_pre.className='ggskin ggskin_image';
			hs ='position:absolute;';
			hs+='left: -71px;';
			hs+='top:  -31px;';
			hs+='width: 40px;';
			hs+='height: 40px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='opacity: 0.5;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._audio_pre.setAttribute('style',hs);
			this._audio_pre__img=document.createElement('img');
			this._audio_pre__img.setAttribute('src',basePath + 'images/audio_pre.png');
			this._audio_pre__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._audio_pre__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._audio_pre__img);
			this._audio_pre.appendChild(this._audio_pre__img);
			this._audio_pre.onmouseover=function () {
				me.elementMouseOver['audio_pre']=true;
			}
			this._audio_pre.onmouseout=function () {
				if (me.player.transitionsDisabled) {
					me._audio_pre.style[domTransition]='none';
				} else {
					me._audio_pre.style[domTransition]='all 500ms ease-out 0ms';
				}
				me._audio_pre.style.opacity='0.5';
				me._audio_pre.style.visibility=me._audio_pre.ggVisible?'inherit':'hidden';
				me.elementMouseOver['audio_pre']=false;
			}
			this._audio_pre.ontouchend=function () {
				me.elementMouseOver['audio_pre']=false;
			}
			this.__div.appendChild(this._audio_pre);
			this._audio_next=document.createElement('div');
			this._audio_next.ggId='audio_next';
			this._audio_next.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._audio_next.ggVisible=true;
			this._audio_next.className='ggskin ggskin_image';
			hs ='position:absolute;';
			hs+='left: 11px;';
			hs+='top:  -32px;';
			hs+='width: 40px;';
			hs+='height: 40px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='opacity: 0.5;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._audio_next.setAttribute('style',hs);
			this._audio_next__img=document.createElement('img');
			this._audio_next__img.setAttribute('src',basePath + 'images/audio_next.png');
			this._audio_next__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._audio_next__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._audio_next__img);
			this._audio_next.appendChild(this._audio_next__img);
			this._audio_next.onmouseover=function () {
				me.elementMouseOver['audio_next']=true;
			}
			this._audio_next.onmouseout=function () {
				if (me.player.transitionsDisabled) {
					me._audio_next.style[domTransition]='none';
				} else {
					me._audio_next.style[domTransition]='all 500ms ease-out 0ms';
				}
				me._audio_next.style.opacity='0.5';
				me._audio_next.style.visibility=me._audio_next.ggVisible?'inherit':'hidden';
				me.elementMouseOver['audio_next']=false;
			}
			this._audio_next.ontouchend=function () {
				me.elementMouseOver['audio_next']=false;
			}
			this.__div.appendChild(this._audio_next);
			this._audio_off=document.createElement('div');
			this._audio_off.ggId='audio_off';
			this._audio_off.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._audio_off.ggVisible=false;
			this._audio_off.className='ggskin ggskin_image';
			hs ='position:absolute;';
			hs+='left: -31px;';
			hs+='top:  -31px;';
			hs+='width: 40px;';
			hs+='height: 40px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='cursor: pointer;';
			this._audio_off.setAttribute('style',hs);
			this._audio_off__img=document.createElement('img');
			this._audio_off__img.setAttribute('src',basePath + 'images/audio_off.png');
			this._audio_off__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._audio_off__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._audio_off__img);
			this._audio_off.appendChild(this._audio_off__img);
			this._audio_off.onclick=function () {
				me.player.pauseSound("music");
				me._audio0.style[domTransition]='none';
				me._audio0.style.visibility='inherit';
				me._audio0.ggVisible=true;
				me._audio_off.style[domTransition]='none';
				me._audio_off.style.visibility='hidden';
				me._audio_off.ggVisible=false;
			}
			this._audio_off.onmouseover=function () {
				me.elementMouseOver['audio_off']=true;
			}
			this._audio_off.onmouseout=function () {
				if (me.player.transitionsDisabled) {
					me._audio_off.style[domTransition]='none';
				} else {
					me._audio_off.style[domTransition]='all 500ms ease-out 0ms';
				}
				me._audio_off.style.opacity='0.5';
				me._audio_off.style.visibility=me._audio_off.ggVisible?'inherit':'hidden';
				me.elementMouseOver['audio_off']=false;
			}
			this._audio_off.ontouchend=function () {
				me.elementMouseOver['audio_off']=false;
			}
			this.__div.appendChild(this._audio_off);
			this._audio0=document.createElement('div');
			this._audio0.ggId='audio';
			this._audio0.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._audio0.ggVisible=true;
			this._audio0.className='ggskin ggskin_image';
			hs ='position:absolute;';
			hs+='left: -30px;';
			hs+='top:  -30px;';
			hs+='width: 40px;';
			hs+='height: 40px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='opacity: 0.5;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._audio0.setAttribute('style',hs);
			this._audio0__img=document.createElement('img');
			this._audio0__img.setAttribute('src',basePath + 'images/audio0.png');
			this._audio0__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._audio0__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._audio0__img);
			this._audio0.appendChild(this._audio0__img);
			this._audio0.onclick=function () {
				me._audio_off.style[domTransition]='none';
				me._audio_off.style.visibility='inherit';
				me._audio_off.ggVisible=true;
				me.player.playSound("music","");
				me._audio0.style[domTransition]='none';
				me._audio0.style.visibility='hidden';
				me._audio0.ggVisible=false;
			}
			this._audio0.onmouseover=function () {
				me._audio0.style[domTransition]='none';
				me._audio0.style.opacity='1';
				me._audio0.style.visibility=me._audio0.ggVisible?'inherit':'hidden';
			}
			this._audio0.onmouseout=function () {
				if (me.player.transitionsDisabled) {
					me._audio0.style[domTransition]='none';
				} else {
					me._audio0.style[domTransition]='all 500ms ease-out 0ms';
				}
				me._audio0.style.opacity='0.5';
				me._audio0.style.visibility=me._audio0.ggVisible?'inherit':'hidden';
			}
			this.__div.appendChild(this._audio0);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['audio_pre']) {
					if (me.player.transitionsDisabled) {
						me._audio_pre.style[domTransition]='none';
					} else {
						me._audio_pre.style[domTransition]='all 500ms ease-out 0ms';
					}
					me._audio_pre.style.opacity='1';
					me._audio_pre.style.visibility=me._audio_pre.ggVisible?'inherit':'hidden';
				}
				if (me.elementMouseOver['audio_next']) {
					if (me.player.transitionsDisabled) {
						me._audio_next.style[domTransition]='none';
					} else {
						me._audio_next.style[domTransition]='all 500ms ease-out 0ms';
					}
					me._audio_next.style.opacity='1';
					me._audio_next.style.visibility=me._audio_next.ggVisible?'inherit':'hidden';
				}
				if (me.elementMouseOver['audio_off']) {
					if (me.player.transitionsDisabled) {
						me._audio_off.style[domTransition]='none';
					} else {
						me._audio_off.style[domTransition]='all 500ms ease-out 0ms';
					}
					me._audio_off.style.opacity='1';
					me._audio_off.style.visibility=me._audio_off.ggVisible?'inherit':'hidden';
				}
			}
			this.hotspotTimerEvent();
		} else
		if (hotspot.skinid=='video') {
			this.__div=document.createElement('div');
			this.__div.ggId='video';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot';
			hs ='position:absolute;';
			hs+='left: 113px;';
			hs+='top:  65px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this._video_play=document.createElement('div');
			this._video_play.ggId='video_play';
			this._video_play.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._video_play.ggVisible=true;
			this._video_play.className='ggskin ggskin_image';
			hs ='position:absolute;';
			hs+='left: -20px;';
			hs+='top:  -21px;';
			hs+='width: 42px;';
			hs+='height: 42px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='opacity: 0.5;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._video_play.setAttribute('style',hs);
			this._video_play__img=document.createElement('img');
			this._video_play__img.setAttribute('src',basePath + 'images/video_play.png');
			this._video_play__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._video_play__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._video_play__img);
			this._video_play.appendChild(this._video_play__img);
			this._video_play.onmouseover=function () {
				me.elementMouseOver['video_play']=true;
			}
			this._video_play.onmouseout=function () {
				if (me.player.transitionsDisabled) {
					me._video_play.style[domTransition]='none';
				} else {
					me._video_play.style[domTransition]='all 500ms ease-out 0ms';
				}
				me._video_play.style.opacity='0.5';
				me._video_play.style.visibility=me._video_play.ggVisible?'inherit':'hidden';
				me.elementMouseOver['video_play']=false;
			}
			this._video_play.ontouchend=function () {
				me.elementMouseOver['video_play']=false;
			}
			this.__div.appendChild(this._video_play);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['video_play']) {
					if (me.player.transitionsDisabled) {
						me._video_play.style[domTransition]='none';
					} else {
						me._video_play.style[domTransition]='all 500ms ease-out 0ms';
					}
					me._video_play.style.opacity='1';
					me._video_play.style.visibility=me._video_play.ggVisible?'inherit':'hidden';
				}
			}
			this.hotspotTimerEvent();
		} else
		if (hotspot.skinid=='book') {
			this.__div=document.createElement('div');
			this.__div.ggId='book';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot';
			hs ='position:absolute;';
			hs+='left: 197px;';
			hs+='top:  25px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.elementMouseOver['_div']=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._booktext.style[domTransition]='none';
				me._booktext.style.visibility='hidden';
				me._booktext.ggVisible=false;
				me.elementMouseOver['_div']=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this.__div.ontouchend=function () {
				me.elementMouseOver['_div']=false;
			}
			this._booktext=document.createElement('div');
			this._booktext.ggId='booktext';
			this._booktext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._booktext.ggVisible=false;
			this._booktext.className='ggskin ggskin_text';
			hs ='position:absolute;';
			hs+='left: 24px;';
			hs+='top:  -13px;';
			hs+='width: 99px;';
			hs+='height: 19px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._booktext.setAttribute('style',hs);
			this._booktext.innerHTML=me.hotspot.title;
			this.__div.appendChild(this._booktext);
			this._books=document.createElement('div');
			this._books.ggId='books';
			this._books.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._books.ggVisible=true;
			this._books.className='ggskin ggskin_image';
			hs ='position:absolute;';
			hs+='left: -11px;';
			hs+='top:  -12px;';
			hs+='width: 36px;';
			hs+='height: 25px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='opacity: 0.9;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._books.setAttribute('style',hs);
			this._books__img=document.createElement('img');
			this._books__img.setAttribute('src',basePath + 'images/books.png');
			this._books__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._books__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._books__img);
			this._books.appendChild(this._books__img);
			this.__div.appendChild(this._books);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['_div']) {
					me._booktext.style[domTransition]='none';
					me._booktext.style.visibility='inherit';
					me._booktext.ggVisible=true;
				}
			}
			this.hotspotTimerEvent();
		} else
		if (hotspot.skinid=='go') {
			this.__div=document.createElement('div');
			this.__div.ggId='go';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot';
			hs ='position:absolute;';
			hs+='left: 173px;';
			hs+='top:  102px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.elementMouseOver['_div']=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._gotext.style[domTransition]='none';
				me._gotext.style.visibility='hidden';
				me._gotext.ggVisible=false;
				me.elementMouseOver['_div']=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this.__div.ontouchend=function () {
				me.elementMouseOver['_div']=false;
			}
			this._gotext=document.createElement('div');
			this._gotext.ggId='gotext';
			this._gotext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._gotext.ggVisible=false;
			this._gotext.className='ggskin ggskin_text';
			hs ='position:absolute;';
			hs+='left: -44px;';
			hs+='top:  54px;';
			hs+='width: 99px;';
			hs+='height: 19px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._gotext.setAttribute('style',hs);
			this._gotext.innerHTML=me.hotspot.title;
			this.__div.appendChild(this._gotext);
			this._gogogo=document.createElement('div');
			this._gogogo.ggId='gogogo';
			this._gogogo.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._gogogo.ggVisible=true;
			this._gogogo.className='ggskin ggskin_image';
			hs ='position:absolute;';
			hs+='left: -18px;';
			hs+='top:  11px;';
			hs+='width: 34px;';
			hs+='height: 36px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._gogogo.setAttribute('style',hs);
			this._gogogo__img=document.createElement('img');
			this._gogogo__img.setAttribute('src',basePath + 'images/gogogo.png');
			this._gogogo__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._gogogo__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._gogogo__img);
			this._gogogo.appendChild(this._gogogo__img);
			this.__div.appendChild(this._gogogo);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['_div']) {
					me._gotext.style[domTransition]='none';
					me._gotext.style.visibility='inherit';
					me._gotext.ggVisible=true;
				}
			}
			this.hotspotTimerEvent();
		} else
		if (hotspot.skinid=='right') {
			this.__div=document.createElement('div');
			this.__div.ggId='right';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot';
			hs ='position:absolute;';
			hs+='left: 45px;';
			hs+='top:  186px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='opacity: 0.8;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.elementMouseOver['_div']=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._righttext.style[domTransition]='none';
				me._righttext.style.visibility='hidden';
				me._righttext.ggVisible=false;
				me.elementMouseOver['_div']=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this.__div.ontouchend=function () {
				me.elementMouseOver['_div']=false;
			}
			this._righttext=document.createElement('div');
			this._righttext.ggId='righttext';
			this._righttext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._righttext.ggVisible=false;
			this._righttext.className='ggskin ggskin_text';
			hs ='position:absolute;';
			hs+='left: -9px;';
			hs+='top:  45px;';
			hs+='width: 99px;';
			hs+='height: 19px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._righttext.setAttribute('style',hs);
			this._righttext.innerHTML=me.hotspot.title;
			this.__div.appendChild(this._righttext);
			this._t_right=document.createElement('div');
			this._t_right.ggId='t_right';
			this._t_right.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._t_right.ggVisible=true;
			this._t_right.className='ggskin ggskin_image';
			hs ='position:absolute;';
			hs+='left: -34px;';
			hs+='top:  9px;';
			hs+='width: 57px;';
			hs+='height: 57px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._t_right.setAttribute('style',hs);
			this._t_right__img=document.createElement('img');
			this._t_right__img.setAttribute('src',basePath + 'images/t_right.png');
			this._t_right__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._t_right__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._t_right__img);
			this._t_right.appendChild(this._t_right__img);
			this.__div.appendChild(this._t_right);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['_div']) {
					me._righttext.style[domTransition]='none';
					me._righttext.style.visibility='inherit';
					me._righttext.ggVisible=true;
				}
			}
			this.hotspotTimerEvent();
		} else
		if (hotspot.skinid=='family') {
			this.__div=document.createElement('div');
			this.__div.ggId='family';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot';
			hs ='position:absolute;';
			hs+='left: 223px;';
			hs+='top:  114px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.elementMouseOver['_div']=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._familystext.style[domTransition]='none';
				me._familystext.style.visibility='hidden';
				me._familystext.ggVisible=false;
				me.elementMouseOver['_div']=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this.__div.ontouchend=function () {
				me.elementMouseOver['_div']=false;
			}
			this._familystext=document.createElement('div');
			this._familystext.ggId='familystext';
			this._familystext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._familystext.ggVisible=false;
			this._familystext.className='ggskin ggskin_text';
			hs ='position:absolute;';
			hs+='left: 27px;';
			hs+='top:  -11px;';
			hs+='width: 99px;';
			hs+='height: 19px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._familystext.setAttribute('style',hs);
			this._familystext.innerHTML=me.hotspot.title;
			this.__div.appendChild(this._familystext);
			this._familys=document.createElement('div');
			this._familys.ggId='familys';
			this._familys.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._familys.ggVisible=true;
			this._familys.className='ggskin ggskin_image';
			this._familys.ggUpdatePosition=function() {
				this.style[domTransition]='none';
				if (this.parentNode) {
					w=this.parentNode.offsetWidth;
					this.style.left=(-11 + w/2) + 'px';
					h=this.parentNode.offsetHeight;
					this.style.top=(-13 + h/2) + 'px';
				}
			}
			hs ='position:absolute;';
			hs+='left: -11px;';
			hs+='top:  -13px;';
			hs+='width: 36px;';
			hs+='height: 25px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._familys.setAttribute('style',hs);
			this._familys__img=document.createElement('img');
			this._familys__img.setAttribute('src',basePath + 'images/familys.png');
			this._familys__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._familys__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._familys__img);
			this._familys.appendChild(this._familys__img);
			this.__div.appendChild(this._familys);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['_div']) {
					me._familystext.style[domTransition]='none';
					me._familystext.style.visibility='inherit';
					me._familystext.ggVisible=true;
				}
			}
			this.hotspotTimerEvent();
		} else
		if (hotspot.skinid=='photo') {
			this.__div=document.createElement('div');
			this.__div.ggId='photo';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot';
			hs ='position:absolute;';
			hs+='left: 262px;';
			hs+='top:  161px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.elementMouseOver['_div']=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._photostext.style[domTransition]='none';
				me._photostext.style.visibility='hidden';
				me._photostext.ggVisible=false;
				me.elementMouseOver['_div']=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this.__div.ontouchend=function () {
				me.elementMouseOver['_div']=false;
			}
			this._photostext=document.createElement('div');
			this._photostext.ggId='photostext';
			this._photostext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._photostext.ggVisible=false;
			this._photostext.className='ggskin ggskin_text';
			hs ='position:absolute;';
			hs+='left: 25px;';
			hs+='top:  -10px;';
			hs+='width: 99px;';
			hs+='height: 19px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._photostext.setAttribute('style',hs);
			this._photostext.innerHTML=me.hotspot.title;
			this._photostext.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
			}
			this._photostext.onmouseover=function () {
				me.elementMouseOver['photostext']=true;
			}
			this._photostext.onmouseout=function () {
				me._photostext.style[domTransition]='none';
				me._photostext.style.visibility='hidden';
				me._photostext.ggVisible=false;
				me.elementMouseOver['photostext']=false;
			}
			this._photostext.ontouchend=function () {
				me.elementMouseOver['photostext']=false;
			}
			this.__div.appendChild(this._photostext);
			this._photos=document.createElement('div');
			this._photos.ggId='photos';
			this._photos.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._photos.ggVisible=true;
			this._photos.className='ggskin ggskin_image';
			hs ='position:absolute;';
			hs+='left: -10px;';
			hs+='top:  -11px;';
			hs+='width: 36px;';
			hs+='height: 25px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._photos.setAttribute('style',hs);
			this._photos__img=document.createElement('img');
			this._photos__img.setAttribute('src',basePath + 'images/photos.png');
			this._photos__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._photos__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._photos__img);
			this._photos.appendChild(this._photos__img);
			this.__div.appendChild(this._photos);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['_div']) {
					me._photostext.style[domTransition]='none';
					me._photostext.style.visibility='inherit';
					me._photostext.ggVisible=true;
				}
				if (me.elementMouseOver['photostext']) {
					me._photostext.style[domTransition]='none';
					me._photostext.style.visibility='inherit';
					me._photostext.ggVisible=true;
				}
			}
			this.hotspotTimerEvent();
		} else
		if (hotspot.skinid=='message') {
			this.__div=document.createElement('div');
			this.__div.ggId='message';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot';
			hs ='position:absolute;';
			hs+='left: 257px;';
			hs+='top:  221px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.elementMouseOver['_div']=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._messagetext.style[domTransition]='none';
				me._messagetext.style.visibility='hidden';
				me._messagetext.ggVisible=false;
				me.elementMouseOver['_div']=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this.__div.ontouchend=function () {
				me.elementMouseOver['_div']=false;
			}
			this._messagetext=document.createElement('div');
			this._messagetext.ggId='messagetext';
			this._messagetext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._messagetext.ggVisible=false;
			this._messagetext.className='ggskin ggskin_text';
			hs ='position:absolute;';
			hs+='left: 28px;';
			hs+='top:  -10px;';
			hs+='width: 99px;';
			hs+='height: 19px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._messagetext.setAttribute('style',hs);
			this._messagetext.innerHTML=me.hotspot.title;
			this.__div.appendChild(this._messagetext);
			this._message0=document.createElement('div');
			this._message0.ggId='message';
			this._message0.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._message0.ggVisible=true;
			this._message0.className='ggskin ggskin_image';
			hs ='position:absolute;';
			hs+='left: -10px;';
			hs+='top:  -13px;';
			hs+='width: 40px;';
			hs+='height: 29px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._message0.setAttribute('style',hs);
			this._message0__img=document.createElement('img');
			this._message0__img.setAttribute('src',basePath + 'images/message0.png');
			this._message0__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._message0__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._message0__img);
			this._message0.appendChild(this._message0__img);
			this.__div.appendChild(this._message0);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['_div']) {
					me._messagetext.style[domTransition]='none';
					me._messagetext.style.visibility='inherit';
					me._messagetext.ggVisible=true;
				}
			}
			this.hotspotTimerEvent();
		} else
		{
			this.__div=document.createElement('div');
			this.__div.ggId='left';
			this.__div.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this.__div.ggVisible=true;
			this.__div.className='ggskin ggskin_hotspot';
			hs ='position:absolute;';
			hs+='left: 160px;';
			hs+='top:  222px;';
			hs+='width: 5px;';
			hs+='height: 5px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			this.__div.setAttribute('style',hs);
			this.__div.onclick=function () {
				me.player.openUrl(me.hotspot.url,me.hotspot.target);
				me.skin.hotspotProxyClick(me.hotspot.id);
			}
			this.__div.onmouseover=function () {
				me.player.hotspot=me.hotspot;
				me.elementMouseOver['_div']=true;
				me.skin.hotspotProxyOver(me.hotspot.id);
			}
			this.__div.onmouseout=function () {
				me.player.hotspot=me.player.emptyHotspot;
				me._lefttext.style[domTransition]='none';
				me._lefttext.style.visibility='hidden';
				me._lefttext.ggVisible=false;
				me.elementMouseOver['_div']=false;
				me.skin.hotspotProxyOut(me.hotspot.id);
			}
			this.__div.ontouchend=function () {
				me.elementMouseOver['_div']=false;
			}
			this._lefttext=document.createElement('div');
			this._lefttext.ggId='lefttext';
			this._lefttext.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._lefttext.ggVisible=false;
			this._lefttext.className='ggskin ggskin_text';
			hs ='position:absolute;';
			hs+='left: 53px;';
			hs+='top:  42px;';
			hs+='width: 99px;';
			hs+='height: 19px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: hidden;';
			hs+='background: #ffffff;';
			hs+='border: 1px solid #000000;';
			hs+='color: #000000;';
			hs+='text-align: center;';
			hs+='white-space: nowrap;';
			hs+='padding: 0px 1px 0px 1px;';
			hs+='overflow: hidden;';
			this._lefttext.setAttribute('style',hs);
			this._lefttext.innerHTML=me.hotspot.title;
			this.__div.appendChild(this._lefttext);
			this._t_left=document.createElement('div');
			this._t_left.ggId='t_left';
			this._t_left.ggParameter={ rx:0,ry:0,a:0,sx:1,sy:1 };
			this._t_left.ggVisible=true;
			this._t_left.className='ggskin ggskin_image';
			hs ='position:absolute;';
			hs+='left: 2px;';
			hs+='top:  13px;';
			hs+='width: 57px;';
			hs+='height: 57px;';
			hs+=cssPrefix + 'transform-origin: 50% 50%;';
			hs+='visibility: inherit;';
			hs+='cursor: pointer;';
			this._t_left.setAttribute('style',hs);
			this._t_left__img=document.createElement('img');
			this._t_left__img.setAttribute('src',basePath + 'images/t_left.png');
			this._t_left__img.setAttribute('style','position: absolute;top: 0px;left: 0px;-webkit-user-drag:none;');
			this._t_left__img['ondragstart']=function() { return false; };
			me.player.checkLoaded.push(this._t_left__img);
			this._t_left.appendChild(this._t_left__img);
			this.__div.appendChild(this._t_left);
			this.hotspotTimerEvent=function() {
				setTimeout(function() { me.hotspotTimerEvent(); }, 10);
				if (me.elementMouseOver['_div']) {
					me._lefttext.style[domTransition]='none';
					me._lefttext.style.visibility='inherit';
					me._lefttext.ggVisible=true;
				}
			}
			this.hotspotTimerEvent();
		}
	};
	this.addSkinHotspot=function(hotspot) {
		return new SkinHotspotClass(me,hotspot);
	}
	this.addSkin();
};